-- ============================================================================
-- Anvaya CRM for Supabase — 00 helpers
-- Run this first, in the Supabase SQL editor.
-- ============================================================================

-- pgcrypto is present on Supabase. gen_random_uuid() is built into PostgreSQL 13+,
-- so the extension is a belt-and-braces line for older instances.
do $$ begin
  create extension if not exists pgcrypto;
exception when others then
  raise notice 'pgcrypto unavailable — gen_random_uuid() is built in, continuing';
end $$;

create schema if not exists app;

-- The helpers below read from `members`, which 01_schema.sql creates. Turning
-- body checking off lets this file run first; the bodies are exercised the
-- moment a policy touches a table.
set check_function_bodies = off;

-- ---------------------------------------------------------------- identity --
-- Two ways to identify the caller, in priority order:
--   1. app.user_id — set by the Express backend for each transaction
--      (select set_config('app.user_id', '<uuid>', true))
--   2. auth.uid()  — the Supabase Auth JWT, when the app talks to Supabase
--      directly from the browser.
-- Supporting both means the same policies serve both deployment shapes.

create or replace function app.uid() returns uuid
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(
      nullif(current_setting('app.user_id', true), '')::uuid,
      auth.uid()
    )
$$;

-- The organisation in play: an explicit setting first (backend), then a JWT
-- claim, then the caller's first active membership.
create or replace function app.current_org() returns uuid
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(
      nullif(current_setting('app.org_id', true), '')::uuid,
      nullif(current_setting('request.jwt.claim.org_id', true), '')::uuid,
      (select m.org_id
         from members m
        where m.user_id = app.uid() and m.status = 'active'
        order by m.created_at
        limit 1)
    )
$$;

create or replace function app.current_user() returns uuid
  language sql stable security definer set search_path = public, auth as $$
    select app.uid()
$$;

-- Permissions come from the caller's role row, not from a session variable.
-- A backend that sets app.perms still wins, so nothing breaks in that mode.
create or replace function app.perms() returns text[]
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(
      string_to_array(nullif(current_setting('app.perms', true), ''), ','),
      (select r.permissions
         from members m
         join roles r on r.id = m.role_id
        where m.user_id = app.uid()
          and m.org_id = app.current_org()
          and m.status = 'active'
        limit 1),
      '{}'::text[]
    )
$$;

create or replace function app.has_perm(p text) returns boolean
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(p = any(app.perms()) or '*' = any(app.perms()), false)
$$;

create or replace function app.is_member() returns boolean
  language sql stable security definer set search_path = public, auth as $$
    select exists (
      select 1 from members m
       where m.user_id = app.uid()
         and m.org_id = app.current_org()
         and m.status = 'active'
    )
$$;

create or replace function app.touch() returns trigger
  language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ---------------------------------------------------------------- grants ----
grant usage on schema app to authenticated, anon, service_role;
grant execute on all functions in schema app to authenticated, anon, service_role;
grant usage on schema public to authenticated, anon, service_role;
grant select, insert, update, delete on all tables in schema public to authenticated;
alter default privileges in schema public grant select, insert, update, delete on tables to authenticated;

reset check_function_bodies;
