-- ============================================================================
-- ANVAYA CRM — Supabase Database (Without RLS Policies for Development)
--
-- One file. Paste it into Supabase → SQL Editor → Run.
-- ============================================================================

-- ============================================================================
-- 00_helpers.sql
-- ============================================================================

do $$ begin
  create extension if not exists pgcrypto;
exception when others then
  raise notice 'pgcrypto unavailable — gen_random_uuid() is built in, continuing';
end $$;

create schema if not exists app;
set check_function_bodies = off;

create or replace function app.uid() returns uuid
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(
      nullif(current_setting('app.user_id', true), '')::uuid,
      auth.uid()
    )
$$;

create or replace function app.current_org() returns uuid
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(
      nullif(current_setting('app.org_id', true), '')::uuid,
      nullif(current_setting('request.jwt.claim.org_id', true), '')::uuid,
      (select m.org_id
         from members m
        where m.user_id = app.uid() and m.status = 'active'
        order by m.created_at
        limit 1)
    )
$$;

create or replace function app.current_user() returns uuid
  language sql stable security definer set search_path = public, auth as $$
    select app.uid()
$$;

create or replace function app.perms() returns text[]
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(
      string_to_array(nullif(current_setting('app.perms', true), ''), ','),
      (select r.permissions
         from members m
         join roles r on r.id = m.role_id
        where m.user_id = app.uid()
          and m.org_id = app.current_org()
          and m.status = 'active'
        limit 1),
      '{}'::text[]
    )
$$;

create or replace function app.has_perm(p text) returns boolean
  language sql stable security definer set search_path = public, auth as $$
    select coalesce(p = any(app.perms()) or '*' = any(app.perms()), false)
$$;

create or replace function app.is_member() returns boolean
  language sql stable security definer set search_path = public, auth as $$
    select exists (
      select 1 from members m
       where m.user_id = app.uid()
         and m.org_id = app.current_org()
         and m.status = 'active'
    )
$$;

create or replace function app.touch() returns trigger
  language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

grant usage on schema app to authenticated, anon, service_role;
grant execute on all functions in schema app to authenticated, anon, service_role;
grant usage on schema public to authenticated, anon, service_role;
grant select, insert, update, delete on all tables in schema public to authenticated;
alter default privileges in schema public grant select, insert, update, delete on tables to authenticated;

reset check_function_bodies;

-- ============================================================================
-- 01_schema.sql (All 51 Tables & Schema)
-- ============================================================================

create table if not exists organisations (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  slug          text not null unique,
  industry      text,
  currency      char(3) not null default 'INR',
  timezone      text not null default 'Asia/Kolkata',
  locale        text not null default 'en-IN',
  fiscal_start_month int not null default 4 check (fiscal_start_month between 1 and 12),
  working_hours jsonb not null default '{"days":[1,2,3,4,5,6],"start":"09:30","end":"18:30"}',
  logo_url      text,
  plan          text not null default 'professional',
  status        text not null default 'active' check (status in ('active','suspended','deleted')),
  settings      jsonb not null default '{}',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz
);

create table if not exists users (
  id            uuid primary key default gen_random_uuid(),
  email         text not null unique,
  password_hash text not null default '',
  full_name     text not null,
  avatar_url    text,
  status        text not null default 'active' check (status in ('active','suspended')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists workspaces (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  name          text not null,
  slug          text not null,
  is_default    boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, slug)
);

create table if not exists roles (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  key           text not null,
  name          text not null,
  description   text,
  permissions   text[] not null default '{}',
  is_system     boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, key)
);

create table if not exists members (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  user_id       uuid not null references users(id) on delete cascade,
  role_id       uuid not null references roles(id) on delete restrict,
  status        text not null default 'active' check (status in ('invited','active','suspended')),
  title         text,
  manager_id    uuid references members(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (org_id, user_id)
);
create index if not exists members_user on members (user_id);
create index if not exists members_org on members (org_id);

create table if not exists pipelines (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  name          text not null,
  is_default    boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists stages (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  pipeline_id   uuid not null references pipelines(id) on delete cascade,
  name          text not null,
  position      int not null default 0,
  probability   int not null default 10 check (probability between 0 and 100),
  is_won        boolean not null default false,
  is_lost       boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists stages_pipeline on stages (pipeline_id, position);

create table if not exists companies (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null references organisations(id) on delete cascade,
  name            text not null,
  domain          text,
  industry        text,
  size_band       text,
  annual_revenue  numeric(16,2),
  phone           text,
  website         text,
  city            text,
  owner_id        uuid references members(id) on delete set null,
  health_score    int not null default 60 check (health_score between 0 and 100),
  tags            text[] not null default '{}',
  custom          jsonb not null default '{}',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists companies_org on companies (org_id);

create table if not exists contacts (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  company_id    uuid references companies(id) on delete set null,
  first_name    text not null,
  last_name     text,
  email         text,
  phone         text,
  title         text,
  city          text,
  owner_id      uuid references members(id) on delete set null,
  tags          text[] not null default '{}',
  consent       jsonb not null default '{"email":true,"whatsapp":false,"calls":true}',
  health_score  int not null default 60 check (health_score between 0 and 100),
  custom        jsonb not null default '{}',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists contacts_org on contacts (org_id);

create table if not exists leads (
  id                    uuid primary key default gen_random_uuid(),
  org_id                uuid not null references organisations(id) on delete cascade,
  name                  text not null,
  company_name          text,
  email                 text,
  phone                 text,
  source                text not null default 'website',
  status                text not null default 'new',
  score                 int check (score between 0 and 100),
  score_reason          text,
  owner_id              uuid references members(id) on delete set null,
  estimated_value       numeric(16,2) not null default 0,
  currency              char(3) not null default 'INR',
  notes                 text,
  lost_reason           text,
  converted_contact_id  uuid references contacts(id) on delete set null,
  converted_deal_id     uuid,
  last_contacted_at     timestamptz,
  custom                jsonb not null default '{}',
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);
create index if not exists leads_org on leads (org_id);

create table if not exists deals (
  id                  uuid primary key default gen_random_uuid(),
  org_id              uuid not null references organisations(id) on delete cascade,
  pipeline_id         uuid not null references pipelines(id) on delete restrict,
  stage_id            uuid not null references stages(id) on delete restrict,
  company_id          uuid references companies(id) on delete set null,
  contact_id          uuid references contacts(id) on delete set null,
  owner_id            uuid references members(id) on delete set null,
  title               text not null,
  value               numeric(16,2) not null default 0,
  currency            char(3) not null default 'INR',
  probability         int check (probability between 0 and 100),
  expected_close_date date,
  status              text not null default 'open' check (status in ('open','won','lost')),
  lost_reason         text,
  competitor          text,
  stage_changed_at    timestamptz not null default now(),
  source_lead_id      uuid references leads(id) on delete set null,
  custom              jsonb not null default '{}',
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create index if not exists deals_org on deals (org_id);

-- Additional CRM tables
create table if not exists activities (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  type          text not null,
  subject       text not null,
  body          text,
  contact_id    uuid references contacts(id) on delete cascade,
  company_id    uuid references companies(id) on delete cascade,
  deal_id       uuid references deals(id) on delete cascade,
  owner_id      uuid references members(id) on delete set null,
  duration_min  int,
  occurred_at   timestamptz not null default now(),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists tasks (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  title          text not null,
  notes          text,
  due_date       date,
  priority       text not null default 'medium',
  status         text not null default 'open',
  assignee_id    uuid references members(id) on delete set null,
  related_type   text not null default 'general',
  related_id     uuid,
  completed_at   timestamptz,
  created_by     uuid references members(id) on delete set null,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table if not exists tickets (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  number       text not null,
  subject      text not null,
  description  text,
  contact_id   uuid references contacts(id) on delete set null,
  company_id   uuid references companies(id) on delete set null,
  deal_id      uuid references deals(id) on delete set null,
  priority     text not null default 'medium',
  status       text not null default 'open',
  category     text,
  assignee_id  uuid references members(id) on delete set null,
  sla_due_at   timestamptz,
  resolved_at  timestamptz,
  csat         int,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists products (
  id             uuid primary key default gen_random_uuid(),
  org_id         uuid not null references organisations(id) on delete cascade,
  sku            text,
  name           text not null,
  category       text,
  unit_price     numeric(12,2) not null default 0,
  tax_rate       numeric(5,2) not null default 18,
  stock_qty      int not null default 0,
  reorder_point  int not null default 0,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table if not exists quotations (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  number       text not null,
  company_id   uuid references companies(id) on delete set null,
  deal_id      uuid references deals(id) on delete set null,
  status       text not null default 'draft',
  issue_date   date not null default current_date,
  valid_until  date,
  subtotal     numeric(16,2) not null default 0,
  tax_total    numeric(16,2) not null default 0,
  total        numeric(16,2) not null default 0,
  terms        text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists quotation_items (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  quotation_id  uuid not null references quotations(id) on delete cascade,
  product_id    uuid references products(id) on delete set null,
  description   text not null,
  quantity      numeric(12,2) not null default 1,
  unit_price    numeric(12,2) not null default 0,
  tax_rate      numeric(5,2) not null default 18,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists invoices (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  number       text not null,
  company_id   uuid references companies(id) on delete set null,
  contact_id   uuid references contacts(id) on delete set null,
  deal_id      uuid references deals(id) on delete set null,
  status       text not null default 'draft',
  currency     char(3) not null default 'INR',
  issue_date   date not null default current_date,
  due_date     date,
  subtotal     numeric(16,2) not null default 0,
  tax_total    numeric(16,2) not null default 0,
  total        numeric(16,2) not null default 0,
  amount_paid  numeric(16,2) not null default 0,
  paid_at      timestamptz,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists invoice_items (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid not null references invoices(id) on delete cascade,
  product_id  uuid references products(id) on delete set null,
  description text not null,
  quantity    numeric(12,2) not null default 1,
  unit_price  numeric(12,2) not null default 0,
  tax_rate    numeric(5,2) not null default 18,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists payments (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  invoice_id    uuid references invoices(id) on delete restrict,
  amount        numeric(16,2) not null,
  method        text not null default 'upi',
  reference     text,
  provider      text not null default 'manual',
  notes         text,
  received_at   timestamptz not null default now(),
  recorded_by   uuid references users(id),
  created_at    timestamptz not null default now()
);

create table if not exists projects (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  name        text not null,
  company_id  uuid references companies(id) on delete set null,
  deal_id     uuid references deals(id) on delete set null,
  manager_id  uuid references members(id) on delete set null,
  status      text not null default 'planned',
  start_date  date,
  end_date    date,
  budget      numeric(16,2) not null default 0,
  spent       numeric(16,2) not null default 0,
  progress    int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists workflows (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null references organisations(id) on delete cascade,
  name            text not null,
  description     text,
  status          text not null default 'draft',
  version         int not null default 1,
  run_count       int not null default 0,
  last_run_at     timestamptz,
  trigger         jsonb not null default '{}',
  conditions      jsonb not null default '[]',
  actions         jsonb not null default '[]',
  created_by      uuid references members(id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create table if not exists workflow_runs (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  workflow_id   uuid references workflows(id) on delete set null,
  workflow_name text not null,
  status        text not null default 'running',
  context       jsonb not null default '{}',
  started_at    timestamptz not null default now(),
  finished_at   timestamptz,
  created_at    timestamptz not null default now()
);

create table if not exists notifications (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  user_id     uuid references users(id) on delete cascade,
  type        text not null default 'info',
  title       text not null,
  body        text,
  read_at     timestamptz,
  created_at  timestamptz not null default now()
);

create table if not exists audit_logs (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  actor_id    uuid references members(id) on delete set null,
  actor_name  text,
  action      text not null,
  entity      text,
  entity_id   uuid,
  before      jsonb,
  after       jsonb,
  created_at  timestamptz not null default now()
);

create table if not exists ai_runs (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references organisations(id) on delete cascade,
  prompt        text not null,
  answer        text,
  provider      text,
  mode          text not null default 'model',
  model         text,
  latency_ms    int,
  credits_used  int not null default 1,
  created_by    uuid references members(id) on delete set null,
  created_at    timestamptz not null default now()
);

create table if not exists custom_fields (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null references organisations(id) on delete cascade,
  entity          text not null,
  key             text not null,
  label           text not null,
  type            text not null,
  options         jsonb not null default '[]',
  required        boolean not null default false,
  position        int not null default 0,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create table if not exists integrations (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null references organisations(id) on delete cascade,
  provider        text not null,
  status          text not null default 'disconnected',
  scopes          text[] not null default '{}',
  config          jsonb not null default '{}',
  connected_by    uuid references members(id) on delete set null,
  connected_at    timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create table if not exists document_sequences (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  doc_type    text not null,
  prefix      text not null,
  next_number int not null default 1,
  padding     int not null default 4,
  unique (org_id, doc_type)
);

-- ============================================================================
-- 03_seed.sql (Default Seed Data)
-- ============================================================================

do $$
declare
  v_email   text := 'you@yourcompany.com';
  v_org     text := 'Your Company';
  v_slug    text := 'your-company';
  v_user    uuid;
  v_org_id  uuid;
  v_role    uuid;
begin
  if exists (select 1 from organisations where slug = v_slug) then
    raise notice 'Workspace % already exists — nothing to do', v_slug;
    return;
  end if;

  select id into v_user from users where lower(email) = lower(v_email) limit 1;
  if v_user is null then
    return;
  end if;

  insert into organisations (name, slug, currency, timezone)
  values (v_org, v_slug, 'INR', 'Asia/Kolkata')
  returning id into v_org_id;

  insert into workspaces (org_id, name, slug, is_default)
  values (v_org_id, 'Main', 'main', true);

  insert into roles (org_id, key, name, description, permissions) values
      (v_org_id, 'owner', 'Owner', 'Full access including billing, roles and deletion', '{*}'::text[]),
      (v_org_id, 'admin', 'Org admin', 'Everything except ownership transfer', '{*}'::text[]);

  select id into v_role from roles where org_id = v_org_id and key = 'owner';
  insert into members (org_id, user_id, role_id, status, title)
  values (v_org_id, v_user, v_role, 'active', 'Owner');

  insert into pipelines (org_id, name, is_default)
  values (v_org_id, 'Sales pipeline', true);

  insert into stages (org_id, pipeline_id, name, position, probability, is_won, is_lost)
  select v_org_id, p.id, s.name, s.position, s.probability, s.is_won, s.is_lost
    from pipelines p,
         (values ('Discovery', 1, 20, false, false),
                 ('Site survey', 2, 35, false, false),
                 ('Proposal sent', 3, 55, false, false),
                 ('Negotiation', 4, 75, false, false),
                 ('Closed won', 5, 100, true, false),
                 ('Closed lost', 6, 0, false, true)) as s(name, position, probability, is_won, is_lost)
   where p.org_id = v_org_id;

  insert into document_sequences (org_id, doc_type, prefix)
  values (v_org_id, 'quotation', 'QTN'),
         (v_org_id, 'invoice', 'INV')
  on conflict do nothing;
end $$;
