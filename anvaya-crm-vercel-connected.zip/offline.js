/* ============================================================================
   Anvaya CRM — offline layer
   ---------------------------------------------------------------------------
   Local storage stops being a second database and becomes a backup:

     cache   every GET the app makes, so a screen still opens with no network
     outbox  changes made while offline, replayed in order when it returns

   Rules that keep it safe:
     • the server is always the source of truth once one has been reached
     • a cached read is used only when the request actually failed
     • a queued change is marked "sending" before it is sent, so a crash
       mid-flight can never replay it twice — it surfaces for review instead
     • a queued edit is dropped if the server row changed after the edit was
       made, rather than overwriting someone else's work

   The module is pure: storage and fetch are injected, so the rules can be
   tested without a browser.
   ========================================================================== */
(function (root) {
  'use strict';

  const CACHE_KEY = 'anvaya.cache.v1';
  const OUTBOX_KEY = 'anvaya.outbox.v1';
  const MODE_KEY = 'anvaya.mode.v1';

  function createStore(storage) {
    const read = (k, fallback) => {
      try { const raw = storage.getItem(k); return raw ? JSON.parse(raw) : fallback; }
      catch { return fallback; }
    };
    const write = (k, v) => {
      try { storage.setItem(k, JSON.stringify(v)); return true; }
      catch { return false; }        // quota or private mode: degrade, never throw
    };
    return { read, write };
  }

  function createOffline(opts) {
    const store = createStore(opts.storage || root.localStorage);
    const maxCacheEntries = opts.maxCacheEntries || 400;

    const api = {
      /* ----------------------------------------------------------- mode --- */
      rememberedMode() { return store.read(MODE_KEY, null); },
      rememberMode(mode) { store.write(MODE_KEY, mode); },

      /* ---------------------------------------------------------- cache --- */
      cacheGet(path) {
        const all = store.read(CACHE_KEY, {});
        const hit = all[path];
        return hit ? hit.body : null;
      },

      cachePut(path, body) {
        const all = store.read(CACHE_KEY, {});
        all[path] = { body, at: Date.now() };
        const keys = Object.keys(all);
        if (keys.length > maxCacheEntries) {
          keys.sort((a, b) => (all[a].at || 0) - (all[b].at || 0));
          for (const k of keys.slice(0, keys.length - maxCacheEntries)) delete all[k];
        }
        store.write(CACHE_KEY, all);
      },

      cacheAge(path) {
        const all = store.read(CACHE_KEY, {});
        return all[path] ? Date.now() - all[path].at : null;
      },

      clearCache() { store.write(CACHE_KEY, {}); },

      /* --------------------------------------------------------- outbox --- */
      outbox() { return store.read(OUTBOX_KEY, []); },

      enqueue(entry) {
        const list = api.outbox();
        const item = {
          id: `q${Date.now()}${Math.random().toString(36).slice(2, 6)}`,
          path: entry.path,
          method: entry.method,
          body: entry.body || null,
          label: entry.label || entry.path,
          // what the row looked like when the edit was made, for conflict checks
          baseUpdatedAt: entry.baseUpdatedAt || null,
          queuedAt: Date.now(),
          state: 'pending'          // pending | sending | uncertain
        };
        list.push(item);
        store.write(OUTBOX_KEY, list);
        return item;
      },

      markSending(id) {
        const list = api.outbox();
        const item = list.find((i) => i.id === id);
        if (item) item.state = 'sending';
        store.write(OUTBOX_KEY, list);
      },

      remove(id) {
        store.write(OUTBOX_KEY, api.outbox().filter((i) => i.id !== id));
      },

      /** An item left in "sending" means the app died mid-request. */
      markUncertain() {
        const list = api.outbox();
        let changed = false;
        for (const item of list) {
          if (item.state === 'sending') { item.state = 'uncertain'; changed = true; }
        }
        if (changed) store.write(OUTBOX_KEY, list);
        return list.filter((i) => i.state === 'uncertain');
      },

      pending() { return api.outbox().filter((i) => i.state === 'pending'); },
      uncertain() { return api.outbox().filter((i) => i.state === 'uncertain'); },
      clearOutbox() { store.write(OUTBOX_KEY, []); },

      /* ---------------------------------------------------------- replay --- */
      /**
       * Send queued changes in order.
       * send(item) must resolve to the server's response body, and reject with
       * err.status for an HTTP error or no status for a network failure.
       */
      async flush(send, { onConflict } = {}) {
        const done = [];
        const failed = [];
        const conflicts = [];

        for (const item of api.pending()) {
          api.markSending(item.id);
          try {
            const body = await send(item);
            api.remove(item.id);
            done.push({ item, body });
          } catch (err) {
            if (err && err.status === 409) {
              // Someone else changed the row after this edit was made.
              api.remove(item.id);
              conflicts.push({ item, server: err.body || null });
              if (onConflict) onConflict(item, err.body || null);
            } else if (err && err.status >= 400 && err.status < 500) {
              // The server refused it outright; retrying will not help.
              api.remove(item.id);
              failed.push({ item, error: err.message });
            } else {
              // Network or 5xx: leave it queued and stop; try again later.
              api.markSending(item.id);
              api.markPending(item.id);
              failed.push({ item, error: err.message });
              break;
            }
          }
        }
        return { done, failed, conflicts };
      },

      markPending(id) {
        const list = api.outbox();
        const item = list.find((i) => i.id === id);
        if (item) item.state = 'pending';
        store.write(OUTBOX_KEY, list);
      }
    };

    return api;
  }

  root.AnvayaOffline = { create: createOffline, createStore };
  if (typeof module !== 'undefined' && module.exports) module.exports = { createOffline, createStore };
})(typeof window !== 'undefined' ? window : globalThis);
