# Linking Anvaya to your Supabase project

## First, the key point

The **anon public key is not what the backend uses.** It is a browser key: it
lets a web page call Supabase's REST API, and it is designed to be public —
row-level security is what limits it. Your Express backend does not speak REST;
it speaks the PostgreSQL protocol, so it needs a **connection string with the
database password**.

Both are useful, for different things:

| What you have | What it is for | Used by |
|---|---|---|
| Project URL + anon key | browser → Supabase REST/JS, with a signed-in user's JWT | a no-backend build |
| Connection string (`postgresql://…`) | server → PostgreSQL directly | this Express backend |

So: to link *this* app, you need the connection string. The anon key is not
enough, and putting it in the backend would not help.

## Steps

### 1 · Get the connection string

Supabase dashboard → **Settings → Database → Connection string → URI**.

Take the **Connection pooling** string if the backend runs as a short-lived
process (serverless, or a host that sleeps). Take the direct one (port 5432) for
a long-running server. It looks like:

```
postgresql://postgres.doodplqtltknbgryxkpq:<YOUR-DB-PASSWORD>@aws-0-ap-south-1.pooler.supabase.com:6543/postgres
```

The password is the one you set when the project was created. If it contains
`@`, `#` or `/`, percent-encode it (`@` → `%40`), or the URL will parse wrong.

### 2 · Make sure the schema is in place

If you have not run it yet, paste **`supabase/anvaya-supabase.sql`** into the
SQL editor and run it. Then create your account (Authentication → Users) and run
it once more so the seed attaches the workspace to you.

### 3 · Point the backend at it

In `backend/.env`:

```
DATABASE_URL=postgresql://postgres.doodplqtltknbgryxkpq:<password>@aws-0-ap-south-1.pooler.supabase.com:6543/postgres
DB_USER_ROLE=authenticated
ENCRYPTION_KEY=<openssl rand -base64 48>
NODE_ENV=production
```

`DB_USER_ROLE=authenticated` matters: every request runs as that role so
row-level security applies. Without it the backend would connect as the table
owner and policies would not protect anything.

Do **not** run `npm run migrate` against Supabase. Those numbered migrations
create a self-hosted `app_user` role; the Supabase file already replaces them.

### 4 · Verify the link

```bash
cd backend
node scripts/check-supabase.mjs
```

Seven checks, each naming its own fix:

```
PASS  connected to PostgreSQL
PASS  schema present (51 tables)
PASS  row-level security policies (182)
PASS  identity helpers exist
PASS  authenticated role has table privileges
PASS  workspace seeded (1 org, 1 user)
PASS  a signed-in user sees their own workspace through RLS
```

Exit code 0 means the backend can use that database. Anything red tells you
which step above was skipped.

### 5 · Start the app

```bash
npm start        # http://localhost:4000
```

The header chip reads **Live data** once the app is talking to a server, and the
data you see is now in Supabase.

## Keys and safety

- The **anon key** is safe to put in a web page. With the policies in this
  schema it can read nothing until a user signs in, and then only their own
  organisation.
- The **service_role key** bypasses every policy. It must never appear in a
  browser, a repo, or a chat message. If one has been shared anywhere, rotate it
  in Settings → API.
- The **database password** belongs in the backend environment only. Never in
  the frontend, never in git.
- Turn on **Database → Backups** before real customer data goes in.

## If you would rather have no backend at all

That is the other architecture: the browser talks to Supabase directly with the
anon key plus Supabase Auth, and the Express server disappears. It is a real
option, but it is a rewrite of the data layer — every screen currently calls
`/api/…`, and it would call `supabase.from(…)` instead, with Supabase Auth
replacing the cookie session. Say the word and I will scope it; do not start it
by half-swapping the client, because a half-swapped app has two sources of truth.
