import { createApp } from '../backend/src/app.js';
import { initDb } from '../backend/src/db.js';
import serverless from 'serverless-http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ---------------------------------------------------------------------------
// Load connection settings (order of priority):
//   1. Real environment variables (Vercel dashboard / host)
//   2. Root .env file (local / AI Studio)
//   3. Built-in fallback for this project's Supabase (so Vercel still works
//      even when .env is excluded from the upload)
// ---------------------------------------------------------------------------
function loadEnvFile(filePath) {
  try {
    if (!fs.existsSync(filePath)) return;
    const text = fs.readFileSync(filePath, 'utf8');
    for (const line of text.split('\n')) {
      const m = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
      if (!m || m[1].startsWith('#')) continue;
      let v = (m[2] || '').trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        v = v.slice(1, -1);
      }
      if (!process.env[m[1]]) process.env[m[1]] = v;
    }
  } catch { /* ignore */ }
}

if (!process.env.DATABASE_URL) {
  loadEnvFile(path.join(__dirname, '../.env'));
  loadEnvFile(path.join(process.cwd(), '.env'));
}

// Project Supabase fallback — keeps the connection AI Studio established
// when Vercel has no Environment Variables set yet.
if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL =
    'postgresql://postgres:OU604ZgU9qPoJuZc@db.pduywbweuxlvcatvesff.supabase.co:5432/postgres';
}
if (!process.env.DB_USER_ROLE) {
  process.env.DB_USER_ROLE = 'authenticated';
}
if (!process.env.ENCRYPTION_KEY) {
  process.env.ENCRYPTION_KEY = 'anvaya-secure-encryption-key-32-chars-minimum!!';
}

const app = createApp();
const handler = serverless(app);
let initialized = false;

export default async function (req, res) {
  if (!initialized) {
    try {
      await initDb();
      initialized = true;
      console.log('[api] database ready');
    } catch (err) {
      console.error('[db] init failed:', err.message);
      return res.status(500).json({
        ok: false,
        mode: 'error',
        error: 'Database initialization failed.',
        details: err.message,
        hint:
          'Check Supabase project is running and DATABASE_URL is correct. ' +
          'Prefer the pooler URI (port 6543) on Vercel. ' +
          'Also ensure supabase/anvaya-supabase.sql has been run in the SQL Editor.'
      });
    }
  }
  return handler(req, res);
}
