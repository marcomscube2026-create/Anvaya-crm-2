/* ============================================================================
   Anvaya CRM — frontend
   Plain ES modules, no build step. Every view reads and writes the real API.
   ========================================================================== */

const S = {
  me: null,
  view: 'overview',
  cache: {},
  contactId: null,
  tab: 'timeline',
  pipelines: [],
  deals: [],
  copilotOpen: false,
  theme: localStorage.getItem('anvaya-theme') || 'light'
};

/* ---------------------------------- utils --------------------------------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function inr(n) {
  const v = Number(n || 0);
  const s = Math.round(Math.abs(v)).toString();
  const grouped = s.length <= 3 ? s : s.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + s.slice(-3);
  return '₹' + grouped;
}
function inrC(n) {
  const v = Number(n || 0);
  if (v >= 1e7) return '₹' + (v / 1e7).toFixed(2).replace(/\.00$/, '') + ' Cr';
  if (v >= 1e5) return '₹' + (v / 1e5).toFixed(1).replace(/\.0$/, '') + ' L';
  if (v >= 1e3) return '₹' + Math.round(v / 1e3) + 'K';
  return '₹' + Math.round(v);
}
const dateStr = (d) => d ? String(d).slice(0, 10) : '—';
const shortDate = (d) => {
  if (!d) return 'no date';
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return '—';
  return dt.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
};
const timeAgo = (d) => {
  if (!d) return '—';
  const diff = (Date.now() - new Date(d).getTime()) / 1000;
  if (diff < 3600) return Math.max(1, Math.round(diff / 60)) + 'm ago';
  if (diff < 86400) return Math.round(diff / 3600) + 'h ago';
  if (diff < 86400 * 30) return Math.round(diff / 86400) + 'd ago';
  return dateStr(d);
};
const initials = (name) => String(name || '?').split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
const can = (perm) => {
  const p = S.me?.perms || [];
  return p.includes('*') || p.includes(perm);
};

/* ---------------------------------- icons --------------------------------- */
const P = {
  grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
  target: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 4.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9Z',
  users: 'M16 19v-1a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v1M9 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm13 16v-1a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
  user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z',
  building: 'M3 21h18M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16M9 8h2M13 8h2M9 12h2M13 12h2M9 16h2M13 16h2',
  kanban: 'M4 4h4v12H4zM10 4h4v16h-4zM16 4h4v8h-4z',
  check: 'M9 11l3 3L22 4M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11',
  calendar: 'M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z',
  mail: 'M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Zm18 2-10 7L2 6',
  megaphone: 'm3 11 18-6v14L3 13v-2Zm0 0v5a2 2 0 0 0 2 2h2v-5',
  lifebuoy: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 5.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7ZM5.6 5.6l3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9',
  folder: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z',
  box: 'm21 8-9-5-9 5v8l9 5 9-5V8Zm0 0-9 5M3 8l9 5m0 0v8',
  doc: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm0 0v6h6M8 13h8M8 17h5',
  zap: 'M13 2 4 14h6l-1 8 9-12h-6l1-8Z',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  sparkle: 'M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7.4-3a7.4 7.4 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7.4 7.4 0 0 0-2-1.2L14.5 3h-4l-.4 2.6a7.4 7.4 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6a7.4 7.4 0 0 0 0 2.4l-2 1.6 2 3.4 2.4-1a7.4 7.4 0 0 0 2 1.2l.4 2.6h4l.4-2.6a7.4 7.4 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.1-.4.1-.8.1-1.2Z',
  phone: 'M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z',
  video: 'M23 7l-7 5 7 5V7ZM3 5h11a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z',
  note: 'M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7M8 8h8M8 12h8M8 16h4',
  ticket: 'M3 9a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2 2 2 0 0 0 0 4 2 2 0 0 1-2 2H5a2 2 0 0 1-2-2 2 2 0 0 0 0-4Z',
  arrowUp: 'M7 17 17 7M9 7h8v8',
  plus: 'M12 5v14M5 12h14',
  filter: 'M3 5h18l-7 8v6l-4 2v-8L3 5Z',
  download: 'M12 3v12M7 11l5 5 5-5M4 21h16',
  search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14Zm10 3-4.3-4.3',
  more: 'M12 6h.01M12 12h.01M12 18h.01',
  clock: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 4v5l3 2',
  alert: 'M12 9v4M12 17h.01M10.3 3.9 2.5 17a2 2 0 0 0 1.7 3h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z',
  shield: 'M12 3 4 6v6c0 5 3.4 8.4 8 9 4.6-.6 8-4 8-9V6l-8-3Zm0 6v4',
  refresh: 'M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5'
};
const ic = (n, size = 15, sw = 2) =>
  `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${P[n] || P.grid}"/></svg>`;

/* ----------------------------------- api ---------------------------------- */
/* All reads and writes go through the data bridge, which chooses between the
   server API and the in-browser engine. The UI never talks to either directly. */
async function api(path, opts = {}) {
  return window.AnvayaData.api(path, opts);
}

function toast(msg, kind = 'ok') {
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `${ic(kind === 'err' ? 'alert' : 'check', 14)}<span>${esc(msg)}</span>`;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 220); }, 3200);
}
const fail = (e) => toast(e.message || 'Something went wrong', 'err');

/* ---------------------------------- auth ---------------------------------- */
function showAuth(mode) {
  $('#authScreen').classList.remove('hidden');
  $('#app').classList.add('hidden');
  $('#tabLogin').classList.toggle('on', mode === 'login');
  $('#tabRegister').classList.toggle('on', mode === 'register');
  $('#loginForm').classList.toggle('hidden', mode !== 'login');
  $('#registerForm').classList.toggle('hidden', mode !== 'register');
  $('#authError').innerHTML = '';
}

async function doLogin(e) {
  e.preventDefault();
  $('#authError').innerHTML = '';
  const btn = $('#loginBtn');
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>';
  try {
    // Always use the real backend + Supabase. Local demo mode is never used for sign-in.
    await api('/api/auth/login', {
      body: {
        email: $('#loginEmail').value.trim(),
        password: $('#loginPassword').value
      }
    });
    await boot();
  } catch (err) {
    $('#authError').innerHTML = `<div class="err">${esc(err.message || 'Sign-in failed')}</div>`;
  } finally {
    btn.disabled = false; btn.textContent = 'Continue';
  }
}

async function doRegister(e) {
  e.preventDefault();
  $('#authError').innerHTML = '';
  const btn = $('#registerBtn');
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>';
  try {
    // Always use the real backend + Supabase. Never create a local-only fake workspace.
    await api('/api/auth/register', {
      body: {
        fullName: $('#regName').value.trim(),
        email: $('#regEmail').value.trim(),
        password: $('#regPassword').value,
        orgName: $('#regOrg').value.trim(),
        industry: $('#regIndustry').value
      }
    });
    await boot();
  } catch (err) {
    $('#authError').innerHTML = `<div class="err">${esc(err.message || 'Could not create workspace')}</div>`;
  } finally {
    btn.disabled = false; btn.textContent = 'Create workspace';
  }
}

async function logout() {
  try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
  S.me = null; S.cache = {};
  closeSheet();
  showAuth('login');
}

/* --------------------------- connection state ----------------------------- */
/* Local storage is a backup, not a second database: the chip says which of the
   three states the app is in, and the banner only appears when something is
   waiting to reach the server. */
function paintConnection(status) {
  const state = typeof status === 'string' ? { mode: status, pending: 0, uncertain: 0 } : status;
  const chip = document.getElementById('liveChip');
  if (chip) {
    const label = state.mode === 'server' ? 'Live data'
      : state.mode === 'offline' ? 'Offline' : 'Saved in this browser';
    chip.innerHTML = `<span class="dot"></span>${label}`;
    chip.title = state.mode === 'server'
      ? 'Connected to the server. Records are shared with your team.'
      : state.mode === 'offline'
        ? 'The server is unreachable. You are reading the last copy saved here.'
        : 'No server here. Everything you add is stored in this browser.';
    chip.classList.toggle('warn', state.mode === 'offline');
  }
  renderOfflineBanner(state);
}

function renderOfflineBanner(state, isSyncing = false) {
  const host = document.getElementById('offlineBar');
  if (!host) return;

  const waiting = (state.pending || 0) + (state.uncertain || 0) + (state.conflicts || 0);
  if (!waiting && state.mode !== 'offline' && !isSyncing) {
    host.classList.add('hidden');
    host.innerHTML = '';
    return;
  }

  host.classList.remove('hidden');
  host.classList.toggle('syncing', isSyncing || (state.mode === 'server' && waiting > 0));

  const parts = [];
  if (isSyncing) {
    parts.push('Syncing... Reconnected to server, uploading local changes.');
  } else {
    if (state.mode === 'offline') parts.push('You are currently disconnected. Changes are saved locally as backup.');
    if (state.pending) parts.push(`${state.pending} change${state.pending === 1 ? '' : 's'} waiting to sync.`);
    if (state.uncertain) parts.push(`${state.uncertain} change${state.uncertain === 1 ? '' : 's'} may not have reached the server — check before re-entering.`);
    if (state.conflicts) parts.push(`${state.conflicts} record${state.conflicts === 1 ? '' : 's'} changed in two places — your version is saved for review.`);
  }

  host.innerHTML = `<span class="offline-dot"></span><span class="grow">${parts.join(' ')}</span>
    ${!isSyncing && (state.mode === 'server' || navigator.onLine) && (state.pending > 0 || state.mode === 'offline')
      ? `<button class="btn sm" onclick="syncOffline()">Sync now</button>` : ''}
    ${(state.uncertain || state.conflicts) ? `<button class="btn sm ghost" onclick="reviewConflicts()">Review</button>` : ''}`;
}

async function syncOffline() {
  const host = document.getElementById('offlineBar');
  if (host) {
    renderOfflineBanner(window.AnvayaData.status(), true);
  }
  try {
    const out = await window.AnvayaData.syncNow();
    if (out.done.length) toast(`Synced ${out.done.length} change${out.done.length === 1 ? '' : 's'}`);
    if (out.conflicts.length) {
      toast(`${out.conflicts.length} change${out.conflicts.length === 1 ? '' : 's'} skipped — the record changed on the server`);
    }
    setTimeout(() => {
      paintConnection(window.AnvayaData.status());
    }, 1500);
    await go(S.view);
  } catch {
    toast('Still offline. The changes stay queued.');
    paintConnection(window.AnvayaData.status());
  }
}

async function reviewConflicts() {
  const list = window.AnvayaData.conflicts ? await window.AnvayaData.conflicts() : [];
  if (!list.length) { reviewOffline(); return; }
  const host = document.createElement('div');
  host.className = 'overlay';
  host.style.cssText = 'align-items:stretch;padding:0';
  host.innerHTML = `<div class="sheet" style="width:min(620px,94vw)" role="dialog">
    <div class="sheet-head"><div><div class="card-title">Changed in two places</div>
      <div class="card-sub">The server version is kept. Your version is below — copy anything you still need.</div></div></div>
    <div class="sheet-body">
      ${list.map(c => `<div class="conflict-row">
        <div class="settings-title">${esc(c.table)} · ${esc(String(c.recordId).slice(0, 8))}</div>
        <div class="conflict-cols">
          <div><div class="tiny faint">Yours</div><pre class="conflict-pre">${esc(JSON.stringify(c.local, null, 1)).slice(0, 600)}</pre></div>
          <div><div class="tiny faint">Theirs (kept)</div><pre class="conflict-pre">${esc(JSON.stringify(c.server, null, 1)).slice(0, 600)}</pre></div>
        </div></div>`).join('')}
    </div>
    <div class="sheet-foot"><button class="btn ghost" data-close>Close</button></div></div>`;
  host.addEventListener('click', (e) => { if (e.target === host || e.target.closest('[data-close]')) host.remove(); });
  document.body.appendChild(host);
}

function reviewOffline() {
  const items = window.AnvayaOfflineStore.uncertain();
  const host = document.createElement('div');
  host.className = 'overlay';
  host.style.cssText = 'align-items:stretch;padding:0';
  host.innerHTML = `<div class="sheet" style="width:min(520px,94vw)" role="dialog">
    <div class="sheet-head"><div><div class="card-title">Changes that may not have synced</div>
      <div class="card-sub">The app closed while these were being sent.</div></div></div>
    <div class="sheet-body">
      ${items.map(i => `<div class="att-row"><div class="grow">
        <div class="settings-title">${esc(i.method)} ${esc(i.path)}</div>
        <div class="settings-sub">queued ${dateStr(new Date(i.queuedAt).toISOString())}</div></div></div>`).join('')}
      <div class="metric-note" style="margin-top:12px">Check whether each one landed on the server. If it did, discard it here; if it did not, enter it again — Anvaya will not replay them automatically, because a duplicate is worse than a gap.</div>
    </div>
    <div class="sheet-foot"><button class="btn ghost" data-close>Keep</button>
      <button class="btn primary" data-close onclick="window.AnvayaOfflineStore.clearOutbox();paintConnection(window.AnvayaData.status());go(S.view)">Discard all</button></div></div>`;
  host.addEventListener('click', (e) => { if (e.target === host || e.target.closest('[data-close]')) host.remove(); });
  document.body.appendChild(host);
}

/* ---------------------------------- boot ---------------------------------- */
async function boot() {
  document.documentElement.setAttribute('data-theme', S.theme);
  const mode = await window.AnvayaData.init();
  paintConnection(mode);
  window.AnvayaData.onStatus?.(paintConnection);
  try {
    S.me = await api('/api/auth/me');
  } catch {
    showAuth('login');
    return;
  }
  $('#authScreen').classList.add('hidden');
  $('#app').classList.remove('hidden');
  renderShell();
  await go('overview');
}

function renderShell() {
  const m = S.me;
  $('#orgName').textContent = m.org.name;
  $('#orgLogo').textContent = initials(m.org.name);
  $('#orgPlan').textContent = `${m.org.plan.toUpperCase()} · ${m.counts.seats} SEATS`;
  $('#userName').textContent = m.user.fullName;
  $('#userRole').textContent = m.role.name;
  $('#userAvatar').textContent = initials(m.user.fullName);
  $('#topAvatar').textContent = initials(m.user.fullName);
  buildNav();
  loadNotifications();
  renderMobileActions();
}

/* Theme, help and install live in the top bar on desktop. On a phone the top
   bar has no room, so the drawer carries them instead. */
function renderMobileActions() {
  const host = $('#sbActions');
  if (!host) return;
  host.innerHTML = `
    <button class="btn sm" onclick="window.AnvayaInstall && window.AnvayaInstall()">${ic('download', 12)} Install</button>
    <button class="btn sm" onclick="toggleTheme()">${ic('settings', 12)} Theme</button>
    <button class="btn sm" onclick="openHelp();closeSidebar()">${ic('note', 12)} Help</button>`;
}

const NAV = [
  { group: 'Workspace', items: [
    ['overview', 'Dashboard', 'grid', 'Your day at a glance', 'dashboard.read'],
    ['customer', 'Customer 360', 'user', 'One customer, everything about them', 'contact.read'],
    ['search', 'Global search', 'search', 'Find anything, anywhere', null]] },
  { group: 'Sales', items: [
    ['leads', 'Leads', 'target', 'People who might become customers', 'lead.read'],
    ['deals', 'Deals', 'kanban', 'Deals you are trying to win', 'deal.read'],
    ['contacts', 'Contacts', 'users', 'People you already talk to', 'contact.read'],
    ['companies', 'Companies', 'building', 'The businesses they work for', 'company.read'],
    ['quotations', 'Quotations', 'doc', 'Prices you have sent', 'quotation.read'],
    ['products', 'Products', 'box', 'What you sell', 'product.read']] },
  { group: 'Customer operations', items: [
    ['activities', 'Tasks', 'check', 'Calls, follow-ups and reminders', 'task.read'],
    ['support', 'Support', 'lifebuoy', 'Customer problems and tickets', 'ticket.read'],
    ['projects', 'Projects', 'folder', 'Delivery after the deal is won', 'project.read'],
    ['invoices', 'Invoices', 'doc', 'Bills you have raised', 'invoice.read'],
    ['payments', 'Payments', 'wallet', 'Money received and outstanding', 'payment.read']] },
  { group: 'Marketing', items: [
    ['marketing', 'Campaigns', 'megaphone', 'Campaigns to reach more people', 'campaign.read']] },
  { group: 'Automation & intelligence', items: [
    ['copilot', 'AI Copilot', 'sparkle', 'Ask questions about your business', 'ai.read'],
    ['workflows', 'Automations', 'zap', 'Things that happen by themselves', 'workflow.read'],
    ['analytics', 'Reports', 'chart', 'Numbers about your business', 'report.read']] },
  { group: 'Administration', items: [
    ['settings', 'Users & settings', 'settings', 'People, roles and preferences', 'member.read'],
    ['security', 'Security', 'shield', 'Two-factor authentication and sessions', null],
    ['audit', 'Audit log', 'note', 'Every change, and who made it', 'audit.read']] }
];

const MOBNAV = ['overview', 'leads', 'deals', 'activities'];

function buildMobNav() {
  const host = $('#mobnav');
  if (!host) return;
  const lookup = {};
  NAV.forEach(g => g.items.forEach(([id, label, icon]) => { lookup[id] = { label, icon }; }));
  host.innerHTML = MOBNAV.map(id => {
    const item = lookup[id];
    return `<button class="${S.view === id ? 'on' : ''}" onclick="go('${id}')" aria-label="${esc(item.label)}">
      ${ic(item.icon, 19)}<span>${esc(item.label)}</span>
    </button>`;
  }).join('') + `<button onclick="toggleSidebar(true)" aria-label="More">
      ${ic('more', 19)}<span>More</span>
    </button>`;
}

function visibleNav() {
  return NAV
    .map(g => ({ ...g, items: g.items.filter(([, , , , perm]) => !perm || can(perm)) }))
    .filter(g => g.items.length);
}

function buildNav() {
  buildMobNav();
  $('#nav').innerHTML = visibleNav().map(g => `
    <div class="nav-group-label">${g.group}</div>
    ${g.items.map(([id, label, icon, hint]) => `
      <button class="nav-item ${S.view === id ? 'active' : ''}" onclick="go('${id}')" title="${esc(hint || label)}">
        ${ic(icon, 15)}<span class="nav-label">${esc(label)}</span>
      </button>`).join('')}`).join('');
}

function toggleRail() { $('#app').classList.toggle('rail'); }

/* Below 900px the sidebar is an off-canvas drawer. Opening it locks the page
   behind it so a swipe does not scroll the dashboard underneath. */
function toggleSidebar(open) {
  const app = $('#app');
  const shouldOpen = open === undefined ? !app.classList.contains('sidebar-open') : open;
  app.classList.toggle('sidebar-open', shouldOpen);
  document.body.style.overflow = shouldOpen ? 'hidden' : '';
}
function closeSidebar() {
  if ($('#app').classList.contains('sidebar-open')) toggleSidebar(false);
}

function toggleTheme() {
  S.theme = S.theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('anvaya-theme', S.theme);
  document.documentElement.setAttribute('data-theme', S.theme);
}

/* --------------------------------- routing -------------------------------- */
const VIEWS = {
  overview: viewOverview, leads: viewLeads, contacts: viewContacts, companies: viewCompanies,
  deals: viewDeals, customer: viewCustomer, activities: viewActivities, support: viewSupport,
  marketing: viewMarketing, quotations: viewQuotations, invoices: viewInvoices, projects: viewProjects,
  products: viewProducts, workflows: viewWorkflows, analytics: viewAnalytics, settings: viewSettings,
  payments: viewPayments, security: viewSecurity, audit: viewAudit, copilot: viewCopilot, search: viewSearch
};

async function go(view, opts = {}) {
  S.view = view;
  closeSidebar();
  if (opts.contactId) S.contactId = opts.contactId;
  if (opts.tab) S.tab = opts.tab;
  buildNav();
  const root = $('#viewRoot');
  root.innerHTML = `<div class="page"><div class="skeleton" style="width:220px;height:20px;margin-bottom:16px"></div>
    <div class="skeleton" style="width:100%;height:120px"></div></div>`;
  $('#viewport').scrollTop = 0;
  try {
    const html = await (VIEWS[view] || viewOverview)();
    root.innerHTML = html;
    if (view === 'deals') wireKanban();
  } catch (err) {
    root.innerHTML = `<div class="page"><div class="err">${esc(err.message)}</div>
      <button class="btn" onclick="go('${view}')">Try again</button></div>`;
  }
}

/* -------------------------------- components ------------------------------ */
function kpi(label, value, foot = '', hero = false) {
  return `<div class="kpi ${hero ? 'hero' : ''}">
    <div class="kpi-label">${esc(label)}</div>
    <div class="kpi-value">${value}</div>
    ${foot ? `<div class="kpi-foot">${foot}</div>` : ''}
  </div>`;
}

/* Column headings may contain a help icon; the mobile card layout needs the
   plain text for its data-label. */
function plainLabel(col) {
  const raw = col.html || col.label || '';
  return String(raw)
    .replace(/<span class="help"[^>]*>.*?<\/span>/gi, '')   // drop the "?" marker
    .replace(/<[^>]*>/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function table({ cols, rows, empty = 'Nothing here yet', onRow = null, total = null, page = 0, pageSize = 50, onPage = null }) {
  if (!rows.length) {
    return `<div class="empty"><div class="empty-icon">${ic('search', 17)}</div>
      <div class="empty-title">${esc(empty)}</div>
      <div class="empty-sub">Records appear here as soon as they are created.</div></div>`;
  }
  return `<div class="table-wrap"><table class="dt">
    <thead><tr>${cols.map(c => `<th class="${c.r ? 'r' : ''}">${c.html || esc(c.label)}</th>`).join('')}</tr></thead>
    <tbody>${rows.map(r => `<tr ${onRow ? `onclick="${onRow}(event,'${r.id}')" style="cursor:pointer"` : ''}>
      ${cols.map(c => `<td class="${c.r ? 'r' : ''}" data-label="${esc(plainLabel(c))}">${c.render ? c.render(r) : esc(r[c.k] ?? '—')}</td>`).join('')}
    </tr>`).join('')}</tbody></table></div>
    ${total !== null ? `<div class="spread" style="padding:9px 12px;border-top:1px solid var(--border)">
      <span class="tiny faint">Showing ${rows.length} of ${total}</span>
      <div class="row" style="gap:4px">
        <button class="btn sm ghost" ${page === 0 ? 'disabled style="opacity:.4"' : ''} onclick="${onPage || ''}(${page - 1})">Previous</button>
        <button class="btn sm ghost" ${rows.length + page * pageSize >= total ? 'disabled style="opacity:.4"' : ''} onclick="${onPage || ''}(${page + 1})">Next</button>
      </div></div>` : ''}`;
}

function badge(text, tone = '') { return `<span class="badge ${tone}">${esc(text)}</span>`; }

const STATUS_TONE = {
  new: '', contacted: 'info', qualified: 'brand', proposal: 'plum', negotiation: 'warn',
  converted: 'ok', lost: 'danger', open: 'info', in_progress: 'warn', waiting: 'plum',
  resolved: 'ok', closed: '', won: 'ok', draft: '', sent: 'info', accepted: 'ok',
  rejected: 'danger', expired: 'danger', paid: 'ok', partially_paid: 'warn', overdue: 'danger',
  cancelled: '', active: 'ok', paused: 'warn', trialing: 'info', suspended: 'danger',
  planned: 'info', on_hold: 'warn', completed: 'ok', failed: 'danger', succeeded: 'ok',
  proposed: 'warn', applied: 'ok', skipped: '', running: 'info', awaiting_approval: 'warn',
  invited: 'warn', low: '', medium: 'info', high: 'warn', critical: 'danger', urgent: 'danger',
  met: 'ok', breached: 'danger', at_risk: 'warn', on_track: 'ok'
};
const statusBadge = (s) => s ? badge(String(s).replace(/_/g, ' '), STATUS_TONE[s] ?? '') : '—';

function healthBar(n) {
  const v = Number(n || 0);
  const cls = v >= 70 ? '' : v >= 45 ? 'warn' : 'danger';
  return `<span class="score"><span class="score-track"><span class="score-fill ${cls}" style="width:${v}%"></span></span>${v}</span>`;
}

function ownerCell(name) {
  if (!name || name === 'Unassigned') return `<span class="tiny faint">Unassigned</span>`;
  return `<span class="row" style="gap:6px"><span class="avatar">${initials(name)}</span><span class="tiny">${esc(name.split(' ')[0])}</span></span>`;
}

/* ------------------------------ form drawer ------------------------------- */
function openForm({ title, subtitle = '', fields, values = {}, submitLabel = 'Save', onSubmit, wide = false }) {
  const body = fields.map(f => {
    const v = values[f.k] ?? f.value ?? '';
    if (f.type === 'select') {
      return `<div class="field"><label>${esc(f.label)}</label>
        <select class="select" data-field="${f.k}">
          ${(f.options || []).map(o => {
            const val = typeof o === 'string' ? o : o.value;
            const lab = typeof o === 'string' ? o : o.label;
            return `<option value="${esc(val)}" ${String(v) === String(val) ? 'selected' : ''}>${esc(lab)}</option>`;
          }).join('')}
        </select>${f.hint ? `<div class="hint">${esc(f.hint)}</div>` : ''}</div>`;
    }
    if (f.type === 'textarea') {
      return `<div class="field"><label>${esc(f.label)}</label>
        <textarea data-field="${f.k}" placeholder="${esc(f.placeholder || '')}">${esc(v)}</textarea></div>`;
    }
    if (f.type === 'checkbox') {
      return `<div class="field"><label class="row" style="gap:8px;cursor:pointer">
        <input type="checkbox" data-field="${f.k}" ${v ? 'checked' : ''}> ${esc(f.label)}</label></div>`;
    }
    return `<div class="field"><label>${esc(f.label)}${f.required ? ' *' : ''}</label>
      <input class="input" data-field="${f.k}" type="${f.type || 'text'}" value="${esc(v)}"
        placeholder="${esc(f.placeholder || '')}" ${f.required ? 'required' : ''} ${f.step ? `step="${f.step}"` : ''}>
      ${f.hint ? `<div class="hint">${esc(f.hint)}</div>` : ''}</div>`;
  }).join('');

  $('#sheetRoot').innerHTML = `
    <div class="overlay" style="align-items:stretch;padding:0" onclick="if(event.target===this)closeSheet()">
      <div class="sheet" style="width:min(${wide ? 560 : 460}px,94vw)" role="dialog" aria-label="${esc(title)}">
        <div class="sheet-head">
          <div><div class="card-title">${esc(title)}</div>${subtitle ? `<div class="card-sub">${esc(subtitle)}</div>` : ''}</div>
          <button class="icon-btn" style="margin-left:auto" onclick="closeSheet()" aria-label="Close">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="sheet-body">
          <div id="formError"></div>
          ${body}
        </div>
        <div class="sheet-foot">
          <button class="btn" onclick="closeSheet()">Cancel</button>
          <button class="btn primary" id="formSubmit">${esc(submitLabel)}</button>
        </div>
      </div>
    </div>`;

  $('#formSubmit').onclick = async () => {
    const payload = {};
    let bad = null;
    const custom = {};
    $$('[data-field]').forEach(el => {
      const f = fields.find(x => x.k === el.dataset.field);
      let val = el.type === 'checkbox' ? el.checked : el.value;
      if (f?.required && (val === '' || val === null)) bad = bad || `${f.label} is required`;
      if (f?.type === 'number' && val !== '') val = Number(val);
      if (val === '') val = null;
      // Custom fields are prefixed so they land in the record's `custom` object
      // rather than being treated as columns.
      if (el.dataset.field.startsWith('__custom__:')) {
        custom[el.dataset.field.slice(11)] = val;
      } else {
        payload[el.dataset.field] = val;
      }
    });
    if (Object.keys(custom).length) payload.custom = custom;
    if (bad) { $('#formError').innerHTML = `<div class="err">${esc(bad)}</div>`; return; }
    const btn = $('#formSubmit');
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>';
    try {
      await onSubmit(payload);
      closeSheet();
    } catch (err) {
      $('#formError').innerHTML = `<div class="err">${esc(err.message)}</div>`;
      btn.disabled = false; btn.textContent = submitLabel;
    }
  };
}

function closeSheet() { $('#sheetRoot').innerHTML = ''; }

/* --------------------------------- views ---------------------------------- */
const STAGE_HELP = {
  'discovery': 'They have shown interest. Find out what they need.',
  'site survey': 'You are checking the site or scoping the work.',
  'proposal sent': 'They have your price and are deciding.',
  'negotiation': 'Talking about price, terms or timing.',
  'closed won': 'They said yes. Now deliver the work.',
  'closed lost': 'They said no. Note the reason so you learn from it.'
};
const stageHelp = (name) => STAGE_HELP[String(name || '').toLowerCase()] || 'Move a deal here when it reaches this step.';

async function viewOverview() {
  const d = await api('/api/dashboard');
  const k = d.kpi;
  const openDeals = Number(k.open_deals);
  const pipeline = Number(k.pipeline_value);
  const wonValue = Number(k.won_value);
  const wonCount = Number(k.won_count);
  const overdue = Number(k.overdue_tasks);
  const openTasks = Number(k.open_tasks);
  const breaches = Number(k.sla_breaches);
  const openTickets = Number(k.open_tickets);
  const newLeads = Number(k.new_leads);
  const totalLeads = Number(k.total_leads);
  const firstName = S.me.user.fullName.split(' ')[0];
  const startHidden = localStorage.getItem('anvaya-start-hidden') === '1';
  const isEmpty = openDeals === 0 && totalLeads === 0 && d.recent.length === 0;

  const attention = [];
  if (overdue) attention.push({
    icon: 'clock', tone: 'warn',
    title: `${overdue} task${overdue === 1 ? '' : 's'} overdue`,
    body: 'You planned these but they are not done yet.',
    action: 'Open tasks', call: "go('activities')"
  });
  if (breaches) attention.push({
    icon: 'alert', tone: 'warn',
    title: `${breaches} support ticket${breaches === 1 ? '' : 's'} past the deadline`,
    body: 'A customer has waited longer than we promised them.',
    action: 'Open support', call: "go('support')"
  });
  if (newLeads) attention.push({
    icon: 'target', tone: 'warn',
    title: `${newLeads} new lead${newLeads === 1 ? '' : 's'} waiting for a first call`,
    body: 'Someone enquired and nobody has spoken to them yet.',
    action: 'Open leads', call: "go('leads')"
  });

  const stats = `
    <div class="stats-simple">
      <div class="stat-simple">
        <div class="stat-label">Deals in progress
          <span class="help" title="Deals you are still trying to win. The value is what they are worth if they all say yes.">?</span></div>
        <div class="stat-value">${inrC(pipeline)}</div>
        <div class="stat-why">${openDeals} open deal${openDeals === 1 ? '' : 's'} — money you have not won yet.</div>
      </div>
      <div class="stat-simple">
        <div class="stat-label">Won this quarter
          <span class="help" title="Deals marked Closed won in the last three months.">?</span></div>
        <div class="stat-value">${inrC(wonValue)}</div>
        <div class="stat-why">${wonCount} deal${wonCount === 1 ? '' : 's'} closed and signed.</div>
      </div>
      <div class="stat-simple">
        <div class="stat-label">Waiting on you
          <span class="help" title="Overdue tasks, tickets past their deadline, and new leads nobody has called yet.">?</span></div>
        <div class="stat-value">${overdue + breaches + newLeads}</div>
        <div class="stat-why">${overdue} task${overdue === 1 ? '' : 's'} · ${breaches} ticket${breaches === 1 ? '' : 's'} · ${newLeads} lead${newLeads === 1 ? '' : 's'}</div>
      </div>
    </div>`;

  const startCard = (startHidden && !isEmpty) ? '' : `
    <div class="start-card">
      <button class="icon-btn start-close" title="Hide this" onclick="hideStart()">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
      </button>
      <div class="start-head">
        <div class="msg-ai-icon">${ic('sparkle', 12)}</div>
        <div>
          <div class="start-title">New here? Start with these three</div>
          <div class="start-sub">Everything else in the menu can wait. This is the whole job on day one.</div>
        </div>
      </div>
      <div class="start-steps">
        <button class="start-step" onclick="${can('lead.write') ? "newLead()" : "go('leads')"}">
          <div class="start-num">1</div>
          <b>Add a lead</b>
          <span>Someone who might become a customer. Name and phone number is enough.</span>
        </button>
        <button class="start-step" onclick="go('leads')">
          <div class="start-num">2</div>
          <b>Call them, then move it forward</b>
          <span>When they are interested, convert the lead into a deal.</span>
        </button>
        <button class="start-step" onclick="openHelp()">
          <div class="start-num">3</div>
          <b>Learn the words</b>
          <span>Lead, contact, deal, ticket — 30 seconds to learn what each one means.</span>
        </button>
      </div>
    </div>`;

  const emptyState = `
    <div class="card card-pad" style="text-align:center;padding:34px 24px">
      <div class="empty-icon" style="margin:0 auto 12px">${ic('check', 18)}</div>
      <div style="font-size:15px;font-weight:800;letter-spacing:-.02em">This page fills itself in</div>
      <div class="page-lead" style="margin:6px auto 16px;font-size:12.5px">
        As soon as you add a lead, the numbers and reminders appear here. Nothing to set up.
      </div>
      <div class="row" style="justify-content:center;gap:8px;flex-wrap:wrap">
        ${can('lead.write') ? `<button class="qa primary" onclick="newLead()">${ic('plus', 14)} Add my first lead</button>` : ''}
        <button class="qa" onclick="openHelp()">${ic('note', 14)} What do these words mean?</button>
      </div>
    </div>`;

  return `
  <div class="page stagger">
    <div class="page-head">
      <div>
        <div class="eyebrow">Home</div>
        <h1 class="page-title">Hello, ${esc(firstName)}</h1>
        <div class="page-lead">${isEmpty
          ? 'Your workspace is brand new. The three steps below are all you need today.'
          : `This page answers one question: what should I do next? ${attention.length
              ? `You have <b>${attention.length} thing${attention.length === 1 ? '' : 's'}</b> to look at below.`
              : 'Nothing is overdue right now.'}`}</div>
      </div>
    </div>

    ${startCard}

    ${isEmpty ? emptyState : `
    <div class="qa-row">
      ${can('lead.write') ? `<button class="qa primary" onclick="newLead()">${ic('plus', 14)} Add a lead</button>` : ''}
      ${can('deal.write') ? `<button class="qa" onclick="go('deals')">${ic('kanban', 14)} Open my deals</button>` : ''}
      ${can('task.write') ? `<button class="qa" onclick="newTask()">${ic('check', 14)} Add a task</button>` : ''}
      ${can('activity.write') ? `<button class="qa" onclick="logActivity()">${ic('phone', 14)} Log a call</button>` : ''}
    </div>

    ${stats}

    <div class="grid-2" style="margin-bottom:12px">
      <div class="card">
        <div class="card-head">
          <div><div class="card-title">What needs your attention</div>
            <div class="card-sub">Start at the top — these are the things that get forgotten</div></div>
        </div>
        <div class="attention">
          ${attention.length ? attention.map(a => `<div class="att-row">
            <div class="att-icon ${a.tone === 'calm' ? 'calm' : ''}">${ic(a.icon, 15)}</div>
            <div class="att-main">
              <div class="att-title">${esc(a.title)}</div>
              <div class="att-body">${esc(a.body)}</div>
            </div>
            <button class="btn sm" onclick="${a.call}">${esc(a.action)}</button>
          </div>`).join('') : `<div class="all-clear">${ic('check', 16)}
            <div><b>Nothing is overdue.</b> <span class="faint">A good day to call someone you have not spoken to in a while.</span></div>
          </div>`}
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <div><div class="card-title">Money you closed</div>
            <div class="card-sub">Each bar is a month. Only signed deals count.</div></div>
        </div>
        <div class="card-pad">${areaChart(d.revenue)}</div>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div><div class="card-title">Latest activity</div>
          <div class="card-sub">Calls, emails and notes your team logged</div></div>
        <div class="right"><button class="btn ghost sm" onclick="go('activities')">See all ${ic('arrowUp', 11)}</button></div>
      </div>
      ${d.recent.length ? d.recent.slice(0, 5).map(a => `<div class="feed-item">
        <div class="feed-icon">${ic(a.type === 'call' ? 'phone' : a.type === 'email' ? 'mail' : a.type === 'meeting' ? 'video' : 'note', 13)}</div>
        <div class="feed-main"><div class="feed-text">${esc(a.subject)}</div>
          <div class="feed-time">${esc(a.contact_name || '—')} · ${timeAgo(a.occurred_at)}</div></div>
      </div>`).join('') : `<div class="tl-empty">Nothing logged yet. When you call someone, log it so it shows up here.</div>`}
    </div>`}
  </div>`;
}

function hideStart() {
  localStorage.setItem('anvaya-start-hidden', '1');
  go('overview');
}

function areaChart(revenue) {
  const hasData = (revenue || []).some(r => Number(r.value) > 0);
  if (!hasData) {
    return `<div class="tl-empty" style="padding:36px 12px;text-align:center">
      No won deals yet. This chart fills in as soon as one closes.</div>`;
  }
  let pts = revenue.length ? revenue : [{ month: '—', value: 0 }];
  // A single data point has no line to draw — mirror it so the chart still reads.
  if (pts.length === 1) pts = [{ ...pts[0], month: '' }, pts[0]];
  const W = 620, H = 200, pad = { t: 14, r: 12, b: 24, l: 70 };
  const values = pts.map(p => Number(p.value));
  const max = Math.max(...values, 1) * 1.2;
  const x = i => pad.l + (i * (W - pad.l - pad.r)) / Math.max(pts.length - 1, 1);
  const y = v => pad.t + (1 - v / max) * (H - pad.t - pad.b);
  const line = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${x(i)},${y(values[i])}`).join(' ');
  const area = `${line} L${x(pts.length - 1)},${H - pad.b} L${x(0)},${H - pad.b} Z`;
  const axis = (v) => v >= 1e7 ? (v / 1e7).toFixed(1) + ' Cr' : v >= 1e5 ? Math.round(v / 1e5) + ' L' : String(Math.round(v));
  const grid = [0, .5, 1].map(f => {
    const gy = pad.t + f * (H - pad.t - pad.b);
    return `<line x1="${pad.l}" y1="${gy}" x2="${W - pad.r}" y2="${gy}" stroke="var(--border)"/>
      <text x="${pad.l - 8}" y="${gy + 3.5}" text-anchor="end" font-size="9" font-family="var(--font-mono)" fill="var(--text-3)">${axis(max * (1 - f))}</text>`;
  }).join('');
  const monthLabel = (m) => {
    const [y, mo] = String(m).split('-');
    if (!mo) return '';
    return new Date(Number(y), Number(mo) - 1, 1).toLocaleString('en-IN', { month: 'short' });
  };
  const labels = pts.map((p, i) => `<text x="${x(i)}" y="${H - 6}" text-anchor="middle" font-size="9" font-family="var(--font-mono)" fill="var(--text-3)">${esc(monthLabel(p.month))}</text>`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" preserveAspectRatio="none" role="img" aria-label="Revenue by month">
    <defs><linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="var(--brand)" stop-opacity=".28"/><stop offset="100%" stop-color="var(--brand)" stop-opacity="0"/>
    </linearGradient></defs>
    ${grid}<path d="${area}" fill="url(#rev)"/><path d="${line}" fill="none" stroke="var(--brand)" stroke-width="2.2" stroke-linejoin="round"/>
    ${labels}
  </svg>`;
}

/* --------------------------------- leads ---------------------------------- */
let leadFilter = { status: 'all', q: '' };

async function viewLeads() {
  const params = new URLSearchParams({ limit: '100' });
  if (leadFilter.status !== 'all') params.set('status', leadFilter.status);
  if (leadFilter.q) params.set('q', leadFilter.q);
  const res = await api('/api/leads?' + params);
  const rows = res.data;
  const FILTERS = [['all', 'All'], ['new', 'New'], ['contacted', 'Contacted'], ['qualified', 'Qualified'], ['proposal', 'Proposal'], ['converted', 'Won'], ['lost', 'Lost']];

  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">Every day</div><h1 class="page-title">Leads</h1>
      <div class="page-lead">A lead is someone who might become a customer — an enquiry, a referral, a name from a
        trade fair. Add them here, call them, then convert them into a deal when they are interested.</div></div>
      <div class="page-actions">
        ${can('lead.write') ? `<button class="btn primary" onclick="newLead()">${ic('plus', 13)} Add a lead</button>` : ''}
      </div>
    </div>

    <div class="qa-row">
      <button class="qa" onclick="openHelp()">${ic('note', 14)} What counts as a lead?</button>
    </div>

    <div class="card">
      <div class="toolbar">
        <div class="seg">
          ${FILTERS.map(([s, label]) => `<button class="${leadFilter.status === s ? 'on' : ''}" onclick="setLeadFilter('${s}')">${label}</button>`).join('')}
        </div>
        <input class="input grow" placeholder="Search by name or company…" value="${esc(leadFilter.q)}"
          onkeydown="if(event.key==='Enter'){leadFilter.q=this.value;go('leads')}">
        <button class="btn sm" onclick="leadFilter.q='';leadFilter.status='all';go('leads')">Clear</button>
      </div>
      ${table({
        cols: [
          { label: 'Name', render: r => `<div class="lead-name"><div class="avatar">${initials(r.name)}</div>
            <div><div class="cell-main row-link">${esc(r.name)}</div><div class="cell-sub">${esc(r.company_name || 'No company yet')}</div></div></div>` },
          { label: 'Status', html: 'Status <span class="help" title="New = nobody has called. Contacted = you spoke to them. Qualified = they are a real opportunity.">?</span>',
            render: r => statusBadge(r.status) },
          { label: 'Value', r: true, html: 'Value <span class="help" title="What you think this could be worth if it becomes a deal.">?</span>',
            render: r => `<span class="mono" style="font-size:12px">${inrC(r.estimated_value)}</span>` },
          { label: 'Owner', render: r => ownerCell(r.owner_name) },
          { label: 'Last contact', render: r => `<span class="tiny faint">${r.last_contacted_at ? timeAgo(r.last_contacted_at) : 'Never'}</span>` },
          { label: '', render: r => `<div class="row-actions">
              ${r.status !== 'converted' && can('lead.write') ? `<button class="btn sm" onclick="event.stopPropagation();convertLead('${r.id}','${esc(r.name)}')">Turn into deal</button>` : ''}
              ${can('lead.write') ? `<button class="btn sm ghost" onclick="event.stopPropagation();editLead('${r.id}')">Edit</button>` : ''}
            </div>` }
        ],
        rows,
        empty: 'No leads here yet',
        onRow: 'openLeadRow',
        total: res.total
      })}
      ${rows.length ? `<div class="table-note">Tip: click a row to edit it. “Turn into deal” creates the contact, the company and the deal for you in one step.</div>` : ''}
    </div>
  </div>`;
}

function setLeadFilter(s) { leadFilter.status = s; go('leads'); }

const CUSTOM_TYPES = { text: 'text', number: 'number', date: 'date', url: 'text' };

/* Custom fields defined by an admin appear on the form automatically. */
async function customFieldDefs(entity) {
  try {
    const res = await api(`/api/custom-fields?entity=${entity}&limit=50`);
    return (res.data || []).map(f => ({
      k: `__custom__:${f.key}`,
      label: f.label,
      required: Boolean(f.required),
      type: f.type === 'select' || f.type === 'multiselect' ? 'select'
        : f.type === 'boolean' ? 'checkbox'
          : CUSTOM_TYPES[f.type] || 'text',
      options: f.type === 'select' ? (f.options || []) : undefined
    }));
  } catch { return []; }
}

async function newLead() {
  const extra = await customFieldDefs('lead');
  openForm({
    title: 'Add a lead',
    subtitle: 'Duplicates are not merged automatically — you get the record you create.',
    fields: [
      { k: 'name', label: 'Their name', required: true, placeholder: 'Rahul Menon' },
      { k: 'company_name', label: 'Company', placeholder: 'Meridian Retail' },
      { k: 'email', label: 'Email', type: 'email', placeholder: 'rahul@company.in' },
      { k: 'phone', label: 'Phone', placeholder: '+91 98450 00000' },
      { k: 'source', label: 'Where did they come from?', type: 'select',
        options: ['website', 'referral', 'cold_call', 'exhibition', 'linkedin', 'outbound', 'other'],
        hint: 'This tells you later which channel brings the best customers.' },
      { k: 'status', label: 'Status', type: 'select', options: ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'converted', 'lost'] },
      { k: 'estimated_value', label: 'Roughly what is it worth? (₹)', type: 'number',
        hint: 'A guess is fine. You can change it later.' },
      { k: 'notes', label: 'Anything else worth remembering', type: 'textarea' },
      ...extra
    ],
    submitLabel: 'Save lead',
    onSubmit: async (payload) => {
      await api('/api/leads', { body: payload });
      toast('Lead created');
      await go('leads');
    }
  });
}

async function editLead(id) {
  const lead = await api(`/api/leads/${id}`);
  openForm({
    title: 'Edit lead',
    subtitle: lead.name,
    values: lead,
    fields: [
      { k: 'name', label: 'Contact name', required: true },
      { k: 'company_name', label: 'Company' },
      { k: 'email', label: 'Email', type: 'email' },
      { k: 'phone', label: 'Phone' },
      { k: 'status', label: 'Status', type: 'select', options: ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'converted', 'lost'] },
      { k: 'score', label: 'Score (0-100)', type: 'number' },
      { k: 'estimated_value', label: 'Estimated value (₹)', type: 'number' },
      { k: 'lost_reason', label: 'Lost reason', type: 'textarea' }
    ],
    onSubmit: async (payload) => {
      await api(`/api/leads/${id}`, { method: 'PATCH', body: payload });
      toast('Lead updated');
      await go('leads');
    }
  });
}

function openLeadRow(ev, id) { editLead(id); }

async function convertLead(id, name) {
  const pipelines = await api('/api/pipelines');
  const stages = pipelines.data[0].stages;
  openForm({
    title: 'Turn this lead into a deal',
    subtitle: `${name} → contact, company and deal`,
    fields: [
      { k: 'dealTitle', label: 'Deal title', value: `${name} — new opportunity`, required: true },
      { k: 'dealValue', label: 'Deal value (₹)', type: 'number' },
      { k: 'stageId', label: 'Starting stage', type: 'select', options: stages.map(s => ({ value: s.id, label: s.name })) }
    ],
    submitLabel: 'Create the deal',
    onSubmit: async (payload) => {
      const out = await api(`/api/leads/${id}/convert`, { body: payload });
      toast('Lead converted — contact, company and deal created');
      await go('customer', { contactId: out.contact.id });
    }
  });
}

/* ------------------------------- contacts --------------------------------- */
async function viewContacts() {
  const res = await api('/api/contacts?limit=100');
  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">Customers</div><h1 class="page-title">Contacts</h1>
      <div class="page-lead">People you already talk to. A contact is created for you when you convert a lead,
        or you can add one directly. Open the 360° view to see everything about that person in one place.</div></div>
      <div class="page-actions">${can('contact.write') ? `<button class="btn primary" onclick="newContact()">${ic('plus', 13)} Add contact</button>` : ''}</div>
    </div>
    <div class="card">
      ${table({
        cols: [
          { label: 'Name', render: r => `<div class="lead-name"><div class="avatar">${initials(r.full_name)}</div>
            <div><div class="cell-main row-link">${esc(r.full_name)}</div><div class="cell-sub">${esc(r.title || 'No job title')}</div></div></div>` },
          { label: 'Company', render: r => `<span class="small">${esc(r.company_name || '—')}</span>` },
          { label: 'Email', render: r => `<span class="tiny muted">${esc(r.email || '—')}</span>` },
          { label: 'Owner', render: r => ownerCell(r.owner_name) },
          { label: 'Health', html: 'Health <span class="help" title="A score from 0 to 100 set by your team. Low means the relationship is going quiet.">?</span>',
            render: r => healthBar(r.health_score) },
          { label: '', render: r => `<div class="row-actions"><button class="btn sm" onclick="event.stopPropagation();openContact('${r.id}')">Open 360°</button></div>` }
        ],
        rows: res.data,
        empty: 'No contacts yet',
        onRow: 'openContactRow',
        total: res.total
      })}
      ${res.data.length ? `<div class="table-note">Tip: “Open 360°” shows the person's deals, tickets and every call or email in one timeline.</div>` : ''}
    </div>
  </div>`;
}

function openContactRow(ev, id) { openContact(id); }
function openContact(id) { go('customer', { contactId: id }); }

async function newContact() {
  const extra = await customFieldDefs('contact');
  openForm({
    title: 'Add a contact',
    fields: [
      { k: 'first_name', label: 'First name', required: true },
      { k: 'last_name', label: 'Last name' },
      { k: 'email', label: 'Email', type: 'email' },
      { k: 'phone', label: 'Phone' },
      { k: 'title', label: 'Job title' },
      { k: 'city', label: 'City' },
      ...extra
    ],
    submitLabel: 'Save contact',
    onSubmit: async (payload) => {
      const c = await api('/api/contacts', { body: payload });
      toast('Contact created');
      await go('customer', { contactId: c.id });
    }
  });
}

async function viewCustomer() {
  if (!S.contactId) {
    const list = await api('/api/contacts?limit=1');
    if (!list.data.length) return `<div class="page"><div class="empty"><div class="empty-title">No contacts yet</div>
      <div class="empty-sub">Convert a lead or create a contact to see the 360° view.</div></div></div>`;
    S.contactId = list.data[0].id;
  }
  const d = await api(`/api/contacts/${S.contactId}/360`);
  const c = d.contact;
  const openDeals = d.deals.filter(x => x.status === 'open');
  const openTickets = d.tickets.filter(x => !['resolved', 'closed'].includes(x.status));
  const ring = (() => {
    const r = 22, circ = 2 * Math.PI * r, len = (c.health_score / 100) * circ;
    const col = c.health_score >= 70 ? 'var(--ok)' : c.health_score >= 45 ? 'var(--warn)' : 'var(--danger)';
    return `<svg width="52" height="52" viewBox="0 0 52 52">
      <circle cx="26" cy="26" r="${r}" fill="none" stroke="var(--surface-3)" stroke-width="5"/>
      <circle cx="26" cy="26" r="${r}" fill="none" stroke="${col}" stroke-width="5" stroke-linecap="round"
        stroke-dasharray="${len} ${circ - len}" transform="rotate(-90 26 26)"/></svg><div class="ring-label">${c.health_score}</div>`;
  })();

  const tabs = [['timeline', `History (${d.activities.length})`], ['deals', `Deals (${d.deals.length})`],
    ['tickets', `Support (${d.tickets.length})`], ['tasks', `Tasks (${d.tasks.length})`]];

  const timeline = d.activities.length ? `<div class="timeline">
    ${d.activities.map(a => `<div class="tl-item">
      <div class="tl-dot ${a.type}">${ic(a.type === 'call' ? 'phone' : a.type === 'email' ? 'mail' : a.type === 'meeting' ? 'video' : 'note', 11)}</div>
      <div class="tl-head"><span class="tl-title">${esc(a.subject)}</span>
        <span class="tl-time">${timeAgo(a.occurred_at)}</span></div>
      ${a.body ? `<div class="tl-body">${esc(a.body)}</div>` : ''}
    </div>`).join('')}</div>` : `<div class="tl-empty">No activity logged yet.</div>`;

  const dealsHtml = d.deals.length ? `<div class="table-wrap"><table class="dt" style="min-width:520px">
    <thead><tr><th>Deal</th><th>Stage</th><th class="r">Value</th><th>Close</th></tr></thead>
    <tbody>${d.deals.map(x => `<tr onclick="go('deals')" style="cursor:pointer">
      <td><div class="cell-main">${esc(x.title)}</div><div class="cell-sub">${esc(x.status)}</div></td>
      <td>${badge(x.stage_name)}</td>
      <td class="r mono">${inrC(x.value)}</td>
      <td><span class="tiny muted">${dateStr(x.expected_close_date)}</span></td></tr>`).join('')}</tbody></table></div>`
    : `<div class="tl-empty">No deals linked to this contact.</div>`;

  const ticketsHtml = d.tickets.length ? d.tickets.map(t => `<div class="task-row">
      <div class="feed-icon">${ic('ticket', 13)}</div>
      <div style="flex:1;min-width:0"><div class="cell-main" style="font-size:12px">${esc(t.subject)}</div>
        <div class="cell-sub mono">${esc(t.number)} · ${esc(t.category || '')}</div></div>
      ${statusBadge(t.priority)} ${statusBadge(t.status)}</div>`).join('')
    : `<div class="tl-empty">No support tickets for this contact.</div>`;

  const tasksHtml = d.tasks.length ? d.tasks.map(t => `<div class="task-row">
      <div class="check ${t.status === 'done' ? 'on' : ''}" onclick="toggleTask('${t.id}','${t.status}')">${ic('check', 10, 3)}</div>
      <div style="flex:1;min-width:0"><div class="task-text" style="font-size:12px">${esc(t.title)}</div>
        <div class="cell-sub">${dateStr(t.due_date)}</div></div>${statusBadge(t.priority)}</div>`).join('')
    : `<div class="tl-empty">No tasks for this contact.</div>`;

  return `
  <div class="page">
    <div class="page-head">
      <div><div class="eyebrow">Customer · ${esc(c.company_name || '')}</div>
        <h1 class="page-title">${esc(c.first_name + ' ' + (c.last_name || ''))}</h1>
        <div class="page-lead">Everything about this person in one place: what they bought, what they asked for,
          and every call or email you have logged. Use the tabs below to switch between them.</div></div>
      <div class="page-actions">
        ${can('activity.write') ? `<button class="btn" onclick="logActivity('${c.id}')">${ic('plus', 13)} Log activity</button>` : ''}
        <button class="btn ai" onclick="askAbout('${c.id}','Summarise this customer')">${ic('sparkle', 13)} Summarise</button>
      </div>
    </div>
    <div class="c360">
      <div class="stack">
        <div class="card profile-card">
          <div class="profile-top">
            <div class="profile-avatar">${initials(c.first_name + ' ' + (c.last_name || ''))}</div>
            <div class="profile-name">${esc(c.first_name + ' ' + (c.last_name || ''))}</div>
            <div class="profile-role">${esc(c.title || 'Contact')} · ${esc(c.company_name || '')}</div>
            <div class="row wrap" style="gap:5px;margin-top:10px">${(c.tags || []).map(t => badge(t)).join('')}</div>
          </div>
          <div class="profile-facts">
            <div class="fact wide">${ic('mail', 13)}<span class="fact-k">Email</span><span class="fact-v">${esc(c.email || '—')}</span></div>
            <div class="fact">${ic('phone', 13)}<span class="fact-k">Phone</span><span class="fact-v">${esc(c.phone || '—')}</span></div>
            <div class="fact">${ic('building', 13)}<span class="fact-k">Industry</span><span class="fact-v">${esc(c.industry || '—')}</span></div>
            <div class="fact">${ic('user', 13)}<span class="fact-k">Owner</span><span class="fact-v">${esc(c.owner_name)}</span></div>
          </div>
          <div class="health-ring"><div class="ring">${ring}</div>
            <div><div class="eyebrow">How is this going?</div>
              <div class="tiny muted" style="margin-top:2px">${c.health_score >= 70 ? 'Healthy — you are in touch regularly' : c.health_score >= 45 ? 'Watch — it has gone a bit quiet' : 'At risk — call them soon'}</div></div></div>
          <div class="strip">
            <div class="strip-cell"><div class="strip-v">${inrC(d.lifetime)}</div><div class="strip-k">Bought</div></div>
            <div class="strip-cell"><div class="strip-v">${openDeals.length}</div><div class="strip-k">Open deals</div></div>
            <div class="strip-cell"><div class="strip-v">${openTickets.length}</div><div class="strip-k">Tickets</div></div>
            <div class="strip-cell"><div class="strip-v">${d.activities.length}</div><div class="strip-k">Activities</div></div>
          </div>
        </div>
        <div class="card card-pad">
          <div class="eyebrow" style="margin-bottom:8px">Consent</div>
          <div class="tiny muted" style="line-height:1.7">
            Email: <b>${c.consent?.email ? 'opted in' : 'not opted in'}</b><br>
            WhatsApp: <b>${c.consent?.whatsapp ? 'opted in' : 'not opted in'}</b><br>
            Calls: <b>${c.consent?.calls ? 'allowed' : 'not allowed'}</b>
          </div>
        </div>
      </div>

      <div class="card" style="min-width:0">
        <div class="tabs">
          ${tabs.map(([id, label]) => `<button class="tab ${S.tab === id ? 'on' : ''}" onclick="setTab('${id}')">${label}</button>`).join('')}
        </div>
        ${S.tab === 'timeline' ? timeline : ''}
        ${S.tab === 'deals' ? dealsHtml : ''}
        ${S.tab === 'tickets' ? `<div>${ticketsHtml}</div>` : ''}
        ${S.tab === 'tasks' ? `<div>${tasksHtml}</div>` : ''}
      </div>
    </div>
  </div>`;
}

function setTab(t) { S.tab = t; go('customer'); }

async function toggleTask(id, status) {
  try {
    await api(`/api/tasks/${id}`, {
      method: 'PATCH',
      body: { status: status === 'done' ? 'open' : 'done', completed_at: status === 'done' ? null : new Date().toISOString() }
    });
    await go(S.view);
  } catch (e) { fail(e); }
}

function logActivity(contactId) {
  openForm({
    title: 'Log a call, email or note',
    subtitle: 'Everything you log appears on the customer\'s timeline, so nobody has to ask “what happened last time?”',
    fields: [
      { k: 'type', label: 'What did you do?', type: 'select', options: ['call', 'email', 'meeting', 'note', 'visit'] },
      { k: 'subject', label: 'Short summary', required: true, placeholder: 'Called about the Whitefield install' },
      { k: 'body', label: 'What was said (optional)', type: 'textarea', placeholder: 'They asked for a revised quote by Friday.' },
      { k: 'occurred_at', label: 'When', type: 'date', value: new Date().toISOString().slice(0, 10), hint: 'Leave as today if you are logging it now.' },
      { k: 'contact_id', label: 'Contact id (optional)', value: contactId || '',
        hint: contactId ? '' : 'Leave empty to log this against the whole workspace.' }
    ],
    submitLabel: 'Save',
    onSubmit: async (payload) => {
      await api('/api/activities', { body: payload });
      toast('Activity logged');
      await go('customer');
    }
  });
}

/* ------------------------------- companies -------------------------------- */
async function viewCompanies() {
  const res = await api('/api/companies?limit=100');
  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">Customers</div><h1 class="page-title">Companies</h1>
      <div class="page-lead">The businesses your contacts work for. One company can have many contacts and many deals.</div></div>
      <div class="page-actions">${can('company.write') ? `<button class="btn primary" onclick="newCompany()">${ic('plus', 13)} Add company</button>` : ''}</div>
    </div>
    <div class="card">${table({
      cols: [
        { label: 'Company', render: r => `<div class="lead-name"><div class="feed-icon">${ic('building', 14)}</div>
          <div><div class="cell-main row-link">${esc(r.name)}</div><div class="cell-sub">${esc(r.city || '')}</div></div></div>` },
        { label: 'Industry', render: r => `<span class="tiny muted">${esc(r.industry || '—')}</span>` },
        { label: 'Owner', render: r => ownerCell(r.owner_name) },
        { label: 'Health', html: 'Health <span class="help" title="How well this account is going, from 0 to 100.">?</span>',
          render: r => healthBar(r.health_score) },
        { label: '', render: r => `<div class="row-actions"><button class="btn sm ghost" onclick="event.stopPropagation();newContact()">Add contact</button></div>` }
      ],
      rows: res.data, empty: 'No companies yet', total: res.total
    })}</div>
  </div>`;
}
function openCompanyRow(ev, id) { toast('Company detail view is a list row here — open a contact for the 360° record'); }

async function newCompany() {
  const extra = await customFieldDefs('company');
  openForm({
    title: 'Add a company',
    fields: [
      { k: 'name', label: 'Company name', required: true },
      { k: 'domain', label: 'Domain' },
      { k: 'industry', label: 'Industry' },
      { k: 'size_band', label: 'Size', type: 'select', options: ['1-10', '10-50', '50-100', '100-250', '250-500', '500-1000', '1000+'] },
      { k: 'annual_revenue', label: 'Annual revenue (₹)', type: 'number' },
      { k: 'city', label: 'City' },
      { k: 'phone', label: 'Phone' },
      ...extra
    ],
    submitLabel: 'Save company',
    onSubmit: async (payload) => {
      await api('/api/companies', { body: payload });
      toast('Company created');
      await go('companies');
    }
  });
}

/* --------------------------------- deals ---------------------------------- */
async function viewDeals() {
  const [pipelines, deals] = await Promise.all([api('/api/pipelines'), api('/api/deals?limit=200')]);
  S.pipelines = pipelines.data;
  S.deals = deals.data;
  const pipeline = S.pipelines[0];
  const open = S.deals.filter(d => d.status === 'open');
  const total = open.reduce((a, d) => a + Number(d.value), 0);

  return `
  <div class="page">
    <div class="page-head">
      <div><div class="eyebrow">Every day</div><h1 class="page-title">Deals</h1>
      <div class="page-lead">A deal is a real opportunity with a value and a stage. Drag a card to the right as it moves
        forward — the columns are the steps, left to right. ${open.length} open deal${open.length === 1 ? '' : 's'} worth ${inrC(total)}.</div></div>
      <div class="page-actions">
        ${can('deal.write') ? `<button class="btn primary" onclick="newDeal()">${ic('plus', 13)} Add a deal</button>` : ''}
      </div>
    </div>

    <div class="qa-row">
      <button class="qa" onclick="openHelp()">${ic('note', 14)} How do stages work?</button>
    </div>

    <div class="kanban" id="kanban">
      ${(pipeline?.stages || []).map(stage => {
        const ds = S.deals.filter(d => d.stage_id === stage.id);
        const sum = ds.reduce((a, d) => a + Number(d.value), 0);
        return `<div class="kcol" data-stage="${stage.id}">
          <div class="kcol-head">
            <span class="dot" style="background:var(--${stage.is_won ? 'ok' : stage.is_lost ? 'danger' : 'text-3'})"></span>
            <span class="kcol-name">${esc(stage.name)}</span>
            <span class="kcol-count">${ds.length}</span>
            <span class="kcol-sum">${sum ? inrC(sum) : '—'}</span>
          </div>
          <div class="kcol-hint">${esc(stageHelp(stage.name))}</div>
          <div class="kcol-body" data-drop="${stage.id}">
            ${ds.map(d => `<div class="kcard" draggable="${can('deal.write')}" data-deal="${d.id}" onclick="openDeal('${d.id}')">
              <div class="kcard-title">${esc(d.title)}</div>
              <div class="kcard-org">${esc(d.company_name || '—')}</div>
              <div class="kcard-value">${inrC(d.value)}</div>
              <div class="kcard-foot">
                <span class="avatar">${initials(d.owner_name === 'Unassigned' ? '?' : d.owner_name)}</span>
                <span class="tiny">${shortDate(d.expected_close_date)}</span>
                ${d.status === 'open' && Number(d.days_in_stage) > 14 ? `<span class="tiny" style="margin-left:auto;color:var(--danger)">${d.days_in_stage}d still</span>` : ''}
              </div>
            </div>`).join('')}
            ${stage.is_won || stage.is_lost ? '' : `<button class="kadd" onclick="newDeal('${stage.id}')">+ Add deal here</button>`}
          </div>
        </div>`;
      }).join('')}
    </div>

    <div class="card card-pad" style="display:flex;gap:22px;flex-wrap:wrap;align-items:center">
      <div><div class="eyebrow">Open deals</div>
        <div style="font-size:19px;font-weight:800">${open.length}</div>
        <div class="tiny faint">not won or lost yet</div></div>
      <div style="width:1px;height:38px;background:var(--border)"></div>
      <div><div class="eyebrow">Total value</div><div style="font-size:19px;font-weight:800">${inrC(total)}</div>
        <div class="tiny faint">if every one of them says yes</div></div>
      <div style="width:1px;height:38px;background:var(--border)"></div>
      <div><div class="eyebrow">Sitting still</div>
        <div style="font-size:19px;font-weight:800;color:var(--danger)">${open.filter(d => Number(d.days_in_stage) > 14).length}</div>
        <div class="tiny faint">more than 14 days, no movement</div></div>
      <div class="tiny faint" style="margin-left:auto;max-width:38ch">Each move is saved with your name in the audit log, and any automation watching that stage runs straight away.</div>
    </div>
  </div>`;
}

function wireKanban() {
  let dragId = null;
  $$('.kcard').forEach(card => {
    card.addEventListener('dragstart', e => {
      dragId = card.dataset.deal;
      card.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', dragId);
    });
    card.addEventListener('dragend', () => { card.classList.remove('dragging'); dragId = null; });
  });
  $$('[data-drop]').forEach(col => {
    col.addEventListener('dragover', e => { e.preventDefault(); col.closest('.kcol').classList.add('drag-over'); });
    col.addEventListener('dragleave', () => col.closest('.kcol').classList.remove('drag-over'));
    col.addEventListener('drop', async e => {
      e.preventDefault();
      col.closest('.kcol').classList.remove('drag-over');
      const id = dragId || e.dataTransfer.getData('text/plain');
      if (!id) return;
      try {
        await api(`/api/deals/${id}/stage`, { method: 'PATCH', body: { stageId: col.dataset.drop } });
        toast('Stage updated — audit entry written');
        await go('deals');
      } catch (err) { fail(err); }
    });
  });
}

async function newDeal(stageId) {
  const pipeline = S.pipelines[0];
  const extra = await customFieldDefs('deal');
  openForm({
    title: 'Add a deal',
    fields: [
      { k: 'title', label: 'What is the deal?', required: true, placeholder: '350 cameras — Phase 2' },
      { k: 'value', label: 'Value (₹)', type: 'number', placeholder: '4280000' },
      { k: 'pipeline_id', label: 'Pipeline', type: 'select', options: S.pipelines.map(p => ({ value: p.id, label: p.name })) },
      { k: 'stage_id', label: 'Which step is it on?', type: 'select', value: stageId || pipeline.stages[0].id,
        options: pipeline.stages.map(s => ({ value: s.id, label: s.name })) },
      { k: 'expected_close_date', label: 'When do you expect a decision?', type: 'date' },
      { k: 'probability', label: 'How likely is it? (%)', type: 'number', value: 20,
        hint: 'Your honest guess. It is used for the forecast, nothing else.' },
      ...extra
    ],
    submitLabel: 'Save deal',
    onSubmit: async (payload) => {
      await api('/api/deals', { body: payload });
      toast('Deal created');
      await go('deals');
    }
  });
}

async function openDeal(id) {
  const d = await api(`/api/deals/${id}`);
  const stages = S.pipelines[0]?.stages || [];
  $('#sheetRoot').innerHTML = `
    <div class="overlay" style="align-items:stretch;padding:0" onclick="if(event.target===this)closeSheet()">
      <div class="sheet" role="dialog">
        <div class="sheet-head">
          <div style="min-width:0"><div class="card-title">${esc(d.title)}</div>
            <div class="card-sub">${esc(d.company_name || '—')}</div></div>
          <button class="icon-btn" style="margin-left:auto" onclick="closeSheet()" aria-label="Close">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="sheet-body">
          <div class="strip" style="border:1px solid var(--border);border-radius:10px;overflow:hidden;margin-bottom:14px">
            <div class="strip-cell"><div class="strip-v">${inrC(d.value)}</div><div class="strip-k">Value</div></div>
            <div class="strip-cell"><div class="strip-v">${d.probability ?? 0}%</div><div class="strip-k">Confidence</div></div>
            <div class="strip-cell"><div class="strip-v">${dateStr(d.expected_close_date).slice(5)}</div><div class="strip-k">Close</div></div>
            <div class="strip-cell"><div class="strip-v">${d.days_in_stage ?? 0}d</div><div class="strip-k">In stage</div></div>
          </div>
          <div class="field"><label>Stage</label>
            <select class="select" id="dealStage" ${can('deal.write') ? '' : 'disabled'}>
              ${stages.map(s => `<option value="${s.id}" ${s.id === d.stage_id ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}
            </select></div>
          <div class="field"><label>Status</label><div>${statusBadge(d.status)} ${d.competitor ? badge('vs ' + d.competitor) : ''}</div></div>
          <div class="field"><label>Owner</label><div class="small">${esc(d.owner_name || 'Unassigned')}</div></div>
          ${d.lost_reason ? `<div class="field"><label>Lost reason</label><div class="small muted">${esc(d.lost_reason)}</div></div>` : ''}
          <div class="field"><label>Customer</label>
            ${d.contact_id ? `<button class="btn" onclick="closeSheet();openContact('${d.contact_id}')">Open 360 ${ic('arrowUp', 12)}</button>` : `<span class="small faint">No contact linked</span>`}</div>
          <div class="ai-block" style="margin-top:6px">
            <div class="ai-block-head">${ic('sparkle', 12)}<span class="ai-block-title">What to do next</span>
              <span class="badge gold" style="margin-left:auto">Suggestion</span></div>
            <p>${esc(nextBestAction(d))}</p>
            <div class="src">From stage, days in stage, probability and the last logged activity. A suggestion, not a prediction.</div>
          </div>
        </div>
        <div class="sheet-foot">
          <button class="btn" onclick="closeSheet()">Close</button>
          ${can('deal.write') ? `<button class="btn primary" onclick="moveDeal('${d.id}')">Update stage</button>` : ''}
        </div>
      </div>
    </div>`;
}

/* Deterministic next-step advice — same reasoning the copilot uses, shown in
   context. With a model configured the copilot can go further. */
function nextBestAction(d) {
  const days = Number(d.days_in_stage || 0);
  if (d.status === 'won') return 'Won. Make sure delivery has a task owner and the invoice went out.';
  if (d.status === 'lost') return 'Lost. Record the reason while it is fresh — it is the most useful field on this record.';
  if (days > 14) return `No stage change in ${days} days. Send one specific, time-bound next step rather than a general check-in.`;
  if (Number(d.probability) >= 70 && d.expected_close_date) {
    const close = new Date(d.expected_close_date);
    const soon = (close - Date.now()) / 86400000 < 21;
    if (soon) return 'High confidence and a close date inside three weeks — confirm procurement has started, or the date will slip.';
  }
  if (Number(d.value) > 0 && !d.contact_id) return 'No contact is linked to this deal. Add the person who signs, or it stalls at the approval step.';
  return 'Keep it moving: agree the next concrete step and date with the customer before you hang up.';
}

async function moveDeal(id) {
  try {
    await api(`/api/deals/${id}/stage`, { method: 'PATCH', body: { stageId: $('#dealStage').value } });
    closeSheet();
    toast('Stage updated');
    await go('deals');
  } catch (e) { fail(e); }
}

/* ------------------------------- activities ------------------------------- */
async function viewActivities() {
  const [tasks, acts] = await Promise.all([api('/api/tasks?limit=100'), api('/api/activities?limit=30')]);
  const today = new Date().toISOString().slice(0, 10);
  const open = tasks.data.filter(t => t.status !== 'done');
  const done = tasks.data.filter(t => t.status === 'done');
  const overdue = open.filter(t => t.due_date && t.due_date < today);

  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">Every day</div><h1 class="page-title">Tasks</h1>
      <div class="page-lead">Your to-do list. A task is one small thing with a date — call back, send the quote,
        chase the payment. Tick the box when it is done.</div></div>
      <div class="page-actions">${can('task.write') ? `<button class="btn primary" onclick="newTask()">${ic('plus', 13)} Add a task</button>` : ''}</div>
    </div>

    ${overdue.length ? `<div class="banner warn">${ic('alert', 14)}
      <span><b>${overdue.length} task${overdue.length === 1 ? '' : 's'} past the due date.</b> Start with the oldest one — it is usually the one a customer is waiting on.</span></div>` : ''}

    <div class="grid-2">
      <div class="stack">
        <div class="card">
          <div class="card-head"><div class="card-title">Still to do</div><div class="card-sub">${open.length} task${open.length === 1 ? '' : 's'}</div></div>
          ${open.length ? open.map(t => `<div class="task-row">
            <button class="check" onclick="toggleTask('${t.id}','${t.status}')" title="Mark done">${ic('check', 10, 3)}</button>
            <div style="flex:1;min-width:0"><div class="task-text">${esc(t.title)}</div>
              <div class="cell-sub">${esc(t.assignee_name)} · ${t.due_date ? (t.due_date < today ? 'was due ' + dateStr(t.due_date) : 'due ' + dateStr(t.due_date)) : 'no date'}</div></div>
            ${statusBadge(t.priority)}
          </div>`).join('') : `<div class="tl-empty">Nothing to do. Enjoy it.</div>`}
        </div>
        <div class="card">
          <div class="card-head"><div class="card-title">Done</div><div class="card-sub">${done.length}</div></div>
          ${done.length ? done.map(t => `<div class="task-row done">
            <button class="check on" onclick="toggleTask('${t.id}','${t.status}')" title="Undo">${ic('check', 10, 3)}</button>
            <div style="flex:1;min-width:0"><div class="task-text">${esc(t.title)}</div></div>
          </div>`).join('') : `<div class="tl-empty">Nothing finished yet.</div>`}
        </div>
      </div>
      <div class="card" style="align-self:start">
        <div class="card-head"><div class="card-title">What happened recently</div>
          <div class="card-sub">Calls, emails and notes</div></div>
        ${acts.data.length ? acts.data.slice(0, 8).map(a => `<div class="feed-item">
          <div class="feed-icon">${ic(a.type === 'call' ? 'phone' : a.type === 'email' ? 'mail' : a.type === 'meeting' ? 'video' : 'note', 13)}</div>
          <div class="feed-main"><div class="feed-text">${esc(a.subject)}</div>
            <div class="feed-time">${esc(a.owner_name)} · ${timeAgo(a.occurred_at)}</div></div>
        </div>`).join('') : `<div class="tl-empty">Nothing logged yet.</div>`}
      </div>
    </div>
  </div>`;
}

function newTask() {
  openForm({
    title: 'Add a task',
    fields: [
      { k: 'title', label: 'What needs doing?', required: true, placeholder: 'Call Kavita about the AMC renewal' },
      { k: 'priority', label: 'How urgent?', type: 'select', options: ['low', 'medium', 'high', 'urgent'] },
      { k: 'due_date', label: 'When?', type: 'date', hint: 'Pick a day. Overdue tasks show up on your home page.' },
      { k: 'notes', label: 'Notes', type: 'textarea' }
    ],
    submitLabel: 'Save task',
    onSubmit: async (payload) => {
      await api('/api/tasks', { body: payload });
      toast('Task created');
      await go('activities');
    }
  });
}

/* --------------------------------- support -------------------------------- */
async function viewSupport() {
  const res = await api('/api/tickets?limit=100');
  const open = res.data.filter(t => !['resolved', 'closed'].includes(t.status));
  const late = res.data.filter(t => t.sla_state === 'breached');
  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">Customers</div><h1 class="page-title">Support</h1>
      <div class="page-lead">Problems your customers have reported. Each ticket has a deadline based on its priority —
        the “Deadline” column turns red when you are late.</div></div>
      <div class="page-actions">${can('ticket.write') ? `<button class="btn primary" onclick="newTicket()">${ic('plus', 13)} Add ticket</button>` : ''}</div>
    </div>

    ${late.length ? `<div class="banner warn">${ic('alert', 14)}
      <span><b>${late.length} ticket${late.length === 1 ? '' : 's'} past the deadline.</b> These customers have waited longer than promised.</span></div>` : ''}

    <div class="stats-simple" style="grid-template-columns:repeat(3,1fr)">
      <div class="stat-simple"><div class="stat-label">Open tickets</div>
        <div class="stat-value">${open.length}</div><div class="stat-why">Still being worked on</div></div>
      <div class="stat-simple"><div class="stat-label">Past deadline</div>
        <div class="stat-value">${late.length}</div><div class="stat-why">Apologise and fix first</div></div>
      <div class="stat-simple"><div class="stat-label">Resolved</div>
        <div class="stat-value">${res.data.length - open.length}</div><div class="stat-why">Closed out</div></div>
    </div>

    <div class="card">${table({
      cols: [
        { label: 'Problem', render: r => `<div><div class="cell-main">${esc(r.subject)}</div><div class="cell-sub mono">${esc(r.number)}</div></div>` },
        { label: 'Customer', render: r => `<div><div class="small">${esc(r.contact_name || '—')}</div><div class="cell-sub">${esc(r.company_name || '')}</div></div>` },
        { label: 'Priority', html: 'Priority <span class="help" title="How urgent this is. Critical means a customer is stopped from working.">?</span>',
          render: r => statusBadge(r.priority) },
        { label: 'Deadline', html: 'Deadline <span class="help" title="The time by which we promised a resolution, based on priority.">?</span>',
          render: r => statusBadge(r.sla_state === 'breached' ? 'breached' : r.sla_state === 'at_risk' ? 'at_risk' : r.sla_state === 'met' ? 'met' : 'on_track') },
        { label: 'Status', render: r => statusBadge(r.status) },
        { label: '', render: r => can('ticket.write') ? `<div class="row-actions">
            <select class="select" style="height:28px;font-size:11.5px" onclick="event.stopPropagation()"
              onchange="setTicketStatus('${r.id}', this.value)">
              ${['open', 'in_progress', 'waiting', 'resolved', 'closed'].map(s => `<option value="${s}" ${r.status === s ? 'selected' : ''}>${s.replace('_', ' ')}</option>`).join('')}
            </select></div>` : '' }
      ],
      rows: res.data, empty: 'No tickets — nice and quiet', total: res.total
    })}</div>
  </div>`;
}

async function setTicketStatus(id, status) {
  try {
    await api(`/api/tickets/${id}`, { method: 'PATCH', body: { status, resolved_at: status === 'resolved' ? new Date().toISOString() : null } });
    toast('Ticket updated');
    await go('support');
  } catch (e) { fail(e); }
}

async function newTicket() {
  const extra = await customFieldDefs('ticket');
  openForm({
    title: 'Add a ticket',
    fields: [
      { k: 'number', label: 'Ticket number', hint: 'Leave blank and one is generated for you.' },
      { k: 'subject', label: 'What is the problem?', required: true, placeholder: 'Camera 12 flickering at night' },
      { k: 'description', label: 'Details', type: 'textarea' },
      { k: 'priority', label: 'How urgent?', type: 'select', options: ['low', 'medium', 'high', 'critical'],
        hint: 'Priority sets the deadline automatically.' },
      { k: 'category', label: 'Category', placeholder: 'Hardware' },
      ...extra
    ],
    submitLabel: 'Save ticket',
    onSubmit: async (payload) => {
      await api('/api/tickets', { body: payload });
      toast('Ticket created');
      await go('support');
    }
  });
}

/* -------------------------------- marketing ------------------------------- */
async function viewMarketing() {
  const res = await api('/api/campaigns?limit=50');
  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">Work</div><h1 class="page-title">Marketing</h1>
      <div class="page-lead">Campaigns are messages you plan to send to a group of people. You can write and save them
        here; sending needs an email provider connected to the server, so nothing goes out yet.</div></div>
      <div class="page-actions">${can('campaign.write') ? `<button class="btn primary" onclick="newCampaign()">${ic('plus', 13)} New campaign</button>` : ''}</div>
    </div>
    <div class="banner warn">${ic('alert', 14)}
      <span>No email provider is configured on this server, so nothing can be sent from here. Campaigns are created as drafts and the status never moves to “sent” without a real provider response.</span></div>
    <div class="card">${table({
      cols: [
        { label: 'Campaign', render: r => `<div><div class="cell-main">${esc(r.name)}</div><div class="cell-sub">${esc(r.subject || '—')}</div></div>` },
        { label: 'Channel', render: r => badge(r.channel) },
        { label: 'Status', render: r => statusBadge(r.status) },
        { label: 'Scheduled', render: r => `<span class="tiny faint">${r.scheduled_at ? dateStr(r.scheduled_at) : '—'}</span>` },
        { label: 'Sent', r: true, render: r => `<span class="mono tiny">${r.stats?.sent ?? 0}</span>` }
      ],
      rows: res.data, empty: 'No campaigns yet', total: res.total
    })}</div>
  </div>`;
}

function newCampaign() {
  openForm({
    title: 'New campaign',
    subtitle: 'Created as a draft. Nothing is sent without a provider.',
    fields: [
      { k: 'name', label: 'Campaign name', required: true },
      { k: 'channel', label: 'Channel', type: 'select', options: ['email', 'sms', 'whatsapp'] },
      { k: 'subject', label: 'Subject' },
      { k: 'body', label: 'Message', type: 'textarea' }
    ],
    submitLabel: 'Create draft',
    onSubmit: async (payload) => {
      await api('/api/campaigns', { body: { ...payload, status: 'draft' } });
      toast('Campaign draft created');
      await go('marketing');
    }
  });
}

/* ------------------------------- quotations ------------------------------- */
async function viewQuotations() {
  const res = await api('/api/quotations?limit=100');
  return listPage({
    eyebrow: 'Money', title: 'Quotations',
    sub: `${res.total} quotations · totals are stored, not recomputed on read`,
    lead: 'A quotation is a price you send before the customer says yes. Mark it accepted when they agree.',
    rows: res.data, total: res.total,
    cols: [
      { label: 'Number', render: r => `<div class="cell-main mono">${esc(r.number)}</div><div class="cell-sub">${esc(r.company_name || '')}</div>` },
      { label: 'Status', render: r => statusBadge(r.status) },
      { label: 'Issued', render: r => `<span class="tiny faint">${dateStr(r.issue_date)}</span>` },
      { label: 'Valid until', render: r => `<span class="tiny faint">${dateStr(r.valid_until)}</span>` },
      { label: 'Total', r: true, render: r => `<span class="mono">${inrC(r.total)}</span>` }
    ],
    empty: 'No quotations yet', perm: 'quotation', create: newQuotation
  });
}

function newQuotation() {
  openForm({
    title: 'Add a quotation',
    fields: [
      { k: 'number', label: 'Number', hint: 'Leave blank and one is generated for you.' },
      { k: 'status', label: 'Status', type: 'select', options: ['draft', 'sent', 'accepted', 'rejected'] },
      { k: 'issue_date', label: 'Issue date', type: 'date', value: new Date().toISOString().slice(0, 10) },
      { k: 'valid_until', label: 'Valid until', type: 'date' },
      { k: 'subtotal', label: 'Subtotal (₹)', type: 'number' },
      { k: 'tax_total', label: 'Tax (₹)', type: 'number' },
      { k: 'total', label: 'Total (₹)', type: 'number' },
      { k: 'terms', label: 'Terms', type: 'textarea' }
    ],
    submitLabel: 'Create quotation',
    onSubmit: async (payload) => {
      await api('/api/quotations', { body: payload });
      toast('Quotation created');
      await go('quotations');
    }
  });
}

/* --------------------------------- invoices ------------------------------- */
async function viewInvoices() {
  const res = await api('/api/invoices?limit=100');
  return listPage({
    eyebrow: 'Money', title: 'Invoices',
    sub: `${res.total} invoices · ${inrC(res.data.reduce((a, r) => a + (Number(r.total) - Number(r.amount_paid)), 0))} outstanding`,
    lead: 'An invoice is a bill. What is still owed is the total minus what has been paid.',
    rows: res.data, total: res.total,
    cols: [
      { label: 'Number', render: r => `<div class="cell-main mono">${esc(r.number)}</div><div class="cell-sub">${esc(r.company_name || '')}</div>` },
      { label: 'Status', render: r => statusBadge(r.status) },
      { label: 'Due', render: r => `<span class="tiny faint">${dateStr(r.due_date)}</span>` },
      { label: 'Total', r: true, render: r => `<span class="mono">${inrC(r.total)}</span>` },
      { label: 'Paid', r: true, render: r => `<span class="mono tiny">${inrC(r.amount_paid)}</span>` },
      { label: '', render: r => `<div class="row-actions">
          <a class="btn sm ghost" href="/api/documents/invoice/${r.id}.pdf" target="_blank" rel="noopener">PDF</a>
          ${Number(r.total) - Number(r.amount_paid) > 0
            ? `<button class="btn sm" onclick="event.stopPropagation();recordPayment('${r.id}', ${Number(r.total) - Number(r.amount_paid)})">Payment</button>`
            : ''}
        </div>` }
    ],
    empty: 'No invoices yet', perm: 'invoice', create: newInvoice
  });
}

function newInvoice() {
  openForm({
    title: 'Add an invoice',
    fields: [
      { k: 'number', label: 'Number', value: 'INV-' + Math.floor(2000 + Math.random() * 9000), required: true },
      { k: 'status', label: 'Status', type: 'select', options: ['draft', 'sent', 'partially_paid', 'paid', 'overdue'] },
      { k: 'issue_date', label: 'Issue date', type: 'date', value: new Date().toISOString().slice(0, 10) },
      { k: 'due_date', label: 'Due date', type: 'date' },
      { k: 'subtotal', label: 'Subtotal (₹)', type: 'number' },
      { k: 'tax_total', label: 'Tax (₹)', type: 'number' },
      { k: 'total', label: 'Total (₹)', type: 'number' }
    ],
    submitLabel: 'Create invoice',
    onSubmit: async (payload) => {
      await api('/api/invoices', { body: payload });
      toast('Invoice created');
      await go('invoices');
    }
  });
}

/* --------------------------------- projects ------------------------------- */
async function viewProjects() {
  const res = await api('/api/projects?limit=100');
  return listPage({
    eyebrow: 'Work', title: 'Projects',
    sub: `${res.total} projects`,
    lead: 'A project is the work you deliver after a deal is won — installation, training, handover.',
    rows: res.data, total: res.total,
    cols: [
      { label: 'Project', render: r => `<div><div class="cell-main">${esc(r.name)}</div><div class="cell-sub">${esc(r.company_name || '')}</div></div>` },
      { label: 'Status', render: r => statusBadge(r.status) },
      { label: 'Progress', render: r => `<div class="bar-track" style="width:90px"><div class="bar-fill" style="width:${r.progress}%"></div></div>` },
      { label: 'Budget', r: true, render: r => `<span class="mono tiny">${inrC(r.budget)}</span>` },
      { label: 'Spent', r: true, render: r => `<span class="mono tiny">${inrC(r.spent)}</span>` },
      { label: 'Manager', render: r => ownerCell(r.manager_name) }
    ],
    empty: 'No projects yet', perm: 'project', create: newProject
  });
}

function newProject() {
  openForm({
    title: 'Add a project',
    fields: [
      { k: 'name', label: 'Project name', required: true },
      { k: 'status', label: 'Status', type: 'select', options: ['planned', 'active', 'on_hold', 'completed'] },
      { k: 'start_date', label: 'Start', type: 'date' },
      { k: 'end_date', label: 'End', type: 'date' },
      { k: 'budget', label: 'Budget (₹)', type: 'number' },
      { k: 'progress', label: 'Progress %', type: 'number' }
    ],
    submitLabel: 'Create project',
    onSubmit: async (payload) => {
      await api('/api/projects', { body: payload });
      toast('Project created');
      await go('projects');
    }
  });
}

/* --------------------------------- products ------------------------------- */
async function viewProducts() {
  const res = await api('/api/products?limit=100');
  return listPage({
    eyebrow: 'Work', title: 'Products',
    sub: `${res.total} items · low-stock items are flagged from the stored reorder point`,
    lead: 'The things you sell. Quotations and invoices take their prices from this list.',
    rows: res.data, total: res.total,
    cols: [
      { label: 'Product', render: r => `<div><div class="cell-main">${esc(r.name)}</div><div class="cell-sub mono">${esc(r.sku)}</div></div>` },
      { label: 'Category', render: r => `<span class="tiny muted">${esc(r.category || '—')}</span>` },
      { label: 'Price', r: true, render: r => `<span class="mono">${inr(r.unit_price)}</span>` },
      { label: 'Tax', r: true, render: r => `<span class="tiny">${r.tax_rate}%</span>` },
      { label: 'Stock', r: true, render: r => {
        const low = Number(r.stock_qty) <= Number(r.reorder_point);
        return `<span class="mono ${low ? '' : ''}" style="color:${low ? 'var(--danger)' : 'inherit'}">${Number(r.stock_qty)}</span>`;
      } },
      { label: 'Reorder at', r: true, render: r => `<span class="tiny faint">${Number(r.reorder_point)}</span>` }
    ],
    empty: 'No products yet', perm: 'product', create: newProduct
  });
}

function newProduct() {
  openForm({
    title: 'Add a product',
    fields: [
      { k: 'sku', label: 'SKU', hint: 'Leave blank and one is generated for you.' },
      { k: 'name', label: 'Name', required: true },
      { k: 'category', label: 'Category' },
      { k: 'unit_price', label: 'Unit price (₹)', type: 'number' },
      { k: 'tax_rate', label: 'Tax rate %', type: 'number', value: 18 },
      { k: 'stock_qty', label: 'Stock', type: 'number' },
      { k: 'reorder_point', label: 'Reorder point', type: 'number' }
    ],
    submitLabel: 'Create product',
    onSubmit: async (payload) => {
      await api('/api/products', { body: payload });
      toast('Product created');
      await go('products');
    }
  });
}

/* -------------------------- generic list helper --------------------------- */
function listPage({ eyebrow, title, sub, lead = '', rows, total, cols, empty, perm, create }) {
  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">${esc(eyebrow)}</div><h1 class="page-title">${esc(title)}</h1>
        ${lead ? `<div class="page-lead">${esc(lead)}</div>` : ''}
        <div class="page-sub" style="margin-top:6px">${esc(sub)}</div></div>
      <div class="page-actions">${create && can(`${perm}.write`) ? `<button class="btn primary" onclick="(${create.name})()">${ic('plus', 13)} Add</button>` : ''}</div>
    </div>
    <div class="card">${table({ cols, rows, empty, total })}</div>
  </div>`;
}

/* -------------------------------- workflows ------------------------------- */
async function viewWorkflows() {
  const [res, runs] = await Promise.all([api('/api/workflows?limit=50'), api('/api/workflows/runs')]);
  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">Automation</div><h1 class="page-title">Automations</h1>
      <div class="page-lead">An automation does a small job for you when something happens — for example,
        “when a website lead arrives, create a task to call them”. Build one, switch it on, forget about it.</div></div>
      <div class="page-actions">${can('workflow.write') ? `<button class="btn primary" onclick="newWorkflow()">${ic('plus', 13)} Add automation</button>` : ''}</div>
    </div>

    <div class="card card-pad" style="margin-bottom:12px">
      <div class="flow">
        <div class="flow-step"><div class="flow-dot">1</div>
          <div><b style="font-size:12.5px">When this happens</b>
            <div class="tiny muted">A lead arrives, a deal moves stage, a ticket is created.</div></div></div>
        <div class="flow-step"><div class="flow-dot">2</div>
          <div><b style="font-size:12.5px">If these are true</b>
            <div class="tiny muted">Optional. Example: only if the source is “website”.</div></div></div>
        <div class="flow-step"><div class="flow-dot">3</div>
          <div><b style="font-size:12.5px">Do this</b>
            <div class="tiny muted">Create a task, send a notification, log a note. Sending an email always asks a human first.</div></div></div>
      </div>
    </div>

    <div class="stack">
      ${res.data.length ? res.data.map(w => `<div class="card">
        <div class="card-head">
          <div><div class="card-title">${esc(w.name)}</div>
            <div class="card-sub">Starts when: ${esc(String(w.trigger?.event || '—').replace(/\./g, ' → '))}</div></div>
          <div class="right">
            ${statusBadge(w.status)}
            ${can('workflow.write') ? `<button class="btn sm" onclick="toggleWorkflow('${w.id}','${w.status}')">${w.status === 'active' ? 'Switch off' : 'Switch on'}</button>
            <button class="btn sm ghost" onclick="testWorkflow('${w.id}')">Try it</button>` : ''}
          </div>
        </div>
        <div class="card-pad">
          ${w.description ? `<div class="tiny muted" style="margin-bottom:9px">${esc(w.description)}</div>` : ''}
          <div class="chip-row">
            ${(w.conditions || []).map(c => `<span class="badge">only if ${esc(c.field)} ${esc(c.op)} ${esc(c.value)}</span>`).join('')}
            ${(w.actions || []).map(a => `<span class="badge ${a.type === 'send_email' ? 'warn' : 'brand'}">${esc(String(a.type).replace(/_/g, ' '))}</span>`).join('')}
          </div>
          <div class="tiny faint" style="margin-top:9px">Ran ${w.run_count} time${w.run_count === 1 ? '' : 's'}${w.last_run_at ? ' · last ' + timeAgo(w.last_run_at) : ''}</div>
        </div>
      </div>`).join('') : `<div class="card"><div class="empty"><div class="empty-icon">${ic('zap', 17)}</div>
        <div class="empty-title">No automations yet</div>
        <div class="empty-sub">A good first one: when a website lead arrives, create a task to call them within a day.</div>
        ${can('workflow.write') ? `<button class="btn sm" style="margin-top:6px" onclick="newWorkflow()">Create that automation</button>` : ''}</div></div>`}
    </div>

    <div class="card" style="margin-top:12px">
      <div class="card-head"><div class="card-title">Recent runs</div>
        <div class="card-sub">What your automations actually did</div></div>
      ${runs.data.length ? runs.data.map(r => `<div class="run-row">
        <span class="dot" style="background:var(--${r.status === 'succeeded' ? 'ok' : r.status === 'failed' ? 'danger' : 'warn'})"></span>
        <b style="font-size:12px">${esc(r.workflow_name)}</b>
        ${statusBadge(r.status)}
        <span class="tiny faint" style="margin-left:auto">${timeAgo(r.started_at)}</span>
        <button class="btn sm ghost" onclick="showSteps('${r.id}')">Details</button>
      </div>`).join('') : `<div class="tl-empty">No runs yet. Use “Try it” on an automation to see what it does.</div>`}
    </div>
  </div>`;
}

async function toggleWorkflow(id, status) {
  try {
    await api(`/api/workflows/${id}`, { method: 'PATCH', body: { status: status === 'active' ? 'paused' : 'active' } });
    await go('workflows');
  } catch (e) { fail(e); }
}

async function testWorkflow(id) {
  try {
    const out = await api(`/api/workflows/${id}/test`, { body: { record: { source: 'website', name: 'Test Record', title: 'Test Deal' } } });
    toast(`Test run ${out.status}`);
    await go('workflows');
  } catch (e) { fail(e); }
}

async function showSteps(runId) {
  try {
    const steps = await api(`/api/workflows/runs/${runId}/steps`);
    $('#sheetRoot').innerHTML = `
      <div class="overlay" style="align-items:stretch;padding:0" onclick="if(event.target===this)closeSheet()">
        <div class="sheet" role="dialog">
          <div class="sheet-head"><div class="card-title">Run steps</div>
            <button class="icon-btn" style="margin-left:auto" onclick="closeSheet()">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button></div>
          <div class="sheet-body">
            ${steps.data.length ? steps.data.map(s => `<div class="field">
              <div class="row" style="gap:7px"><b style="font-size:12px">${esc(s.node_type)}</b>${statusBadge(s.status)}</div>
              <pre class="mono tiny" style="white-space:pre-wrap;color:var(--text-2);margin-top:6px">${esc(JSON.stringify(s.output, null, 2))}</pre>
              ${s.error ? `<div class="err" style="margin-top:6px">${esc(s.error)}</div>` : ''}
            </div>`).join('') : `<div class="tl-empty">No steps recorded.</div>`}
          </div>
        </div>
      </div>`;
  } catch (e) { fail(e); }
}

async function newWorkflow() {
  const meta = await api('/api/workflows/meta');
  openForm({
    title: 'Add an automation',
    subtitle: 'Conditions and actions are evaluated server-side as the triggering user.',
    wide: true,
    fields: [
      { k: 'name', label: 'Name', required: true },
      { k: 'description', label: 'Description' },
      { k: 'status', label: 'Status', type: 'select', options: ['draft', 'active', 'paused'] },
      { k: 'event', label: 'Trigger event', type: 'select', options: meta.triggers },
      { k: 'condField', label: 'Condition field (optional)', placeholder: 'e.g. source' },
      { k: 'condOp', label: 'Operator', type: 'select', options: ['eq', 'neq', 'gt', 'lt', 'contains', 'in', 'is_empty'] },
      { k: 'condValue', label: 'Condition value', placeholder: 'e.g. website' },
      { k: 'actionType', label: 'Action', type: 'select', options: ['create_task', 'notify', 'update_field', 'log_activity', 'send_email'] },
      { k: 'actionTitle', label: 'Task / notification title', placeholder: 'First response to {{name}}' },
      { k: 'dueInDays', label: 'Due in (days)', type: 'number', value: 1 }
    ],
    submitLabel: 'Create workflow',
    onSubmit: async (p) => {
      const body = {
        name: p.name, description: p.description, status: p.status,
        trigger: { event: p.event, entity: String(p.event).split('.')[0] },
        conditions: p.condField ? [{ field: p.condField, op: p.condOp, value: p.condValue }] : [],
        actions: p.actionType === 'create_task'
          ? [{ type: 'create_task', title: p.actionTitle || 'Follow up', dueInDays: p.dueInDays ?? 1, priority: 'high' }]
          : p.actionType === 'notify'
            ? [{ type: 'notify', title: p.actionTitle || 'Workflow notification' }]
            : p.actionType === 'update_field'
              ? [{ type: 'update_field', field: p.condField, value: p.condValue }]
              : p.actionType === 'send_email'
                ? [{ type: 'send_email', to: 'customer', subject: p.actionTitle || 'Update', body: 'Draft' }]
                : [{ type: 'log_activity', subject: p.actionTitle || 'Workflow activity' }]
      };
      await api('/api/workflows', { body });
      toast('Workflow created');
      await go('workflows');
    }
  });
}

/* -------------------------------- analytics ------------------------------- */
async function viewAnalytics() {
  const d = await api('/api/dashboard');
  const totalWon = d.team.reduce((a, t) => a + Number(t.value), 0);
  const maxTeam = Math.max(...d.team.map(t => Number(t.value)), 1);
  const winRate = (Number(d.kpi.won_count) + Number(d.kpi.lost_count)) > 0
    ? Math.round(Number(d.kpi.won_count) / (Number(d.kpi.won_count) + Number(d.kpi.lost_count)) * 100) : 0;

  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">Automation</div><h1 class="page-title">Reports</h1>
      <div class="page-lead">The numbers behind your work. Every figure is counted from real records in this
        workspace — nothing here is typed in by hand.</div></div>
    </div>

    <div class="stats-simple" style="grid-template-columns:repeat(3,1fr)">
      <div class="stat-simple"><div class="stat-label">Deals won this quarter</div>
        <div class="stat-value">${inrC(d.kpi.won_value)}</div>
        <div class="stat-why">${d.kpi.won_count} deals signed</div></div>
      <div class="stat-simple"><div class="stat-label">How often you win
        <span class="help" title="Won deals divided by won plus lost deals this quarter.">?</span></div>
        <div class="stat-value">${winRate}%</div>
        <div class="stat-why">${d.kpi.won_count} won · ${d.kpi.lost_count} lost</div></div>
      <div class="stat-simple"><div class="stat-label">Average deal size</div>
        <div class="stat-value">${inrC(d.kpi.avg_deal)}</div>
        <div class="stat-why">Across open deals</div></div>
    </div>

    <div class="grid-2" style="margin-bottom:12px">
      <div class="card"><div class="card-head"><div><div class="card-title">Money you closed</div>
        <div class="card-sub">Signed deals by month</div></div></div>
        <div class="card-pad">${areaChart(d.revenue)}</div></div>
      <div class="card"><div class="card-head"><div><div class="card-title">Who is winning</div>
        <div class="card-sub">${inrC(totalWon)} signed in total</div></div></div>
        <div class="card-pad"><div class="bars">
          ${d.team.length ? d.team.map(t => `<div class="bar-row">
            <div class="row" style="gap:6px"><span class="avatar">${initials(t.full_name)}</span>
              <span class="tiny">${esc(t.full_name.split(' ')[0])}</span></div>
            <div class="bar-track"><div class="bar-fill" style="width:${Math.round(Number(t.value) / maxTeam * 100)}%"></div></div>
            <div class="bar-val">${inrC(t.value)}</div></div>`).join('') : `<div class="tl-empty">No won deals yet.</div>`}
        </div></div></div>
    </div>

    <div class="card">
      <div class="card-head"><div><div class="card-title">Where your deals are stuck</div>
        <div class="card-sub">Count and value per stage</div></div></div>
      <div class="card-pad"><div class="bars">
        ${d.stages.map(s => `<div class="bar-row">
          <div class="faint">${esc(s.name)}</div>
          <div class="bar-track"><div class="bar-fill" style="width:${Math.round(Number(s.value) / Math.max(...d.stages.map(x => Number(x.value)), 1) * 100)}%;${s.is_won ? 'background:var(--ok)' : s.is_lost ? 'background:var(--danger)' : ''}"></div></div>
          <div class="bar-val">${inrC(s.value)}</div>
        </div>`).join('')}
      </div>
      <div class="metric-note">A long bar late in the pipeline is healthy. A long bar early on means deals are arriving but not moving.</div>
      </div>
    </div>
  </div>`;
}

/* --------------------------------- settings ------------------------------- */
const ROLE_OPTIONS = [
  ['owner', 'Owner'], ['admin', 'Org admin'], ['manager', 'Manager'], ['sales', 'Sales representative'],
  ['support', 'Support agent'], ['marketing', 'Marketing'], ['finance', 'Finance'],
  ['field', 'Field employee'], ['readonly', 'Read-only']
];


/* ============================ payments ================================= */
async function viewPayments() {
  const [summary, payments] = await Promise.all([
    api('/api/finance/summary').catch(() => null),
    api('/api/payments').catch(() => ({ data: [] }))
  ]);
  if (!summary) {
    return pageShell('Payments', 'Money received and outstanding', 'payment.read', `
      <div class="card card-pad"><div class="tl-empty">Payments are available on the server edition.</div></div>`);
  }

  const rows = (payments.data || []).map(p => `
    <tr>
      <td><b>${esc(p.invoice_number || '—')}</b><div class="tiny muted">${esc(p.contact_name || '')}</div></td>
      <td>${esc(p.method || '')}<div class="tiny muted">${esc(p.provider || 'manual')}</div></td>
      <td class="r mono">${inr(Number(p.amount))}</td>
      <td>${badge(p.status || 'succeeded', p.status === 'succeeded' ? 'ok' : '')}</td>
      <td class="r tiny muted">${dateStr(p.received_at)}</td>
      <td class="r"><a class="btn sm ghost" href="/api/documents/payment/${p.id}.pdf" target="_blank">Receipt</a></td>
    </tr>`).join('');

  const overdue = (summary.overdue || []).map(i => `
    <div class="att-row">
      <div class="grow"><div class="settings-title">${esc(i.number)}</div>
        <div class="settings-sub">Due ${dateStr(i.due_date)} · ${inr(Number(i.total) - Number(i.amount_paid))} outstanding</div></div>
      <button class="btn sm" onclick="recordPayment('${i.id}', ${Number(i.total) - Number(i.amount_paid)})">Record payment</button>
    </div>`).join('') || '<div class="tl-empty">Nothing overdue. Good.</div>';

  return `
    <div class="page-head">
      <div><div class="eyebrow">Customer operations</div><h1 class="page-title">Payments</h1>
        <div class="page-lead">Money received against invoices, what is still owed, and what is late.</div></div>
      <div class="page-actions"><button class="btn" onclick="go('invoices')">${ic('doc', 13)} Invoices</button></div>
    </div>
    <div class="stats-simple" style="margin-bottom:14px">
      <div class="stat-simple"><div class="stat-label">Collected this month</div>
        <div class="stat-value">${inr(Number(summary.collectedThisMonth || 0))}</div>
        <div class="stat-note">Payments marked received since the 1st.</div></div>
      <div class="stat-simple"><div class="stat-label">Outstanding</div>
        <div class="stat-value">${inr((summary.byStatus || []).reduce((a, r) => a + Number(r.outstanding || 0), 0))}</div>
        <div class="stat-note">Billed and not yet paid, across all invoices.</div></div>
      <div class="stat-simple"><div class="stat-label">Overdue invoices</div>
        <div class="stat-value">${(summary.overdue || []).length}</div>
        <div class="stat-note">Past the due date and not settled.</div></div>
    </div>
    <div class="grid-2" style="align-items:start">
      <div class="card">
        <div class="card-head"><div class="card-title">Recent payments</div><div class="card-sub">${payments.data.length} recorded</div></div>
        <div class="table-wrap"><table class="dt">
          <thead><tr><th>Invoice</th><th>Method</th><th class="r">Amount</th><th>Status</th><th class="r">Received</th><th></th></tr></thead>
          <tbody>${rows || '<tr><td colspan="6"><div class="tl-empty">No payments yet. Record one against an invoice.</div></td></tr>'}</tbody>
        </table></div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Overdue</div><div class="card-sub">Chase these</div></div>
        <div class="settings-list">${overdue}</div>
      </div>
    </div>`;
}

function recordPayment(invoiceId, suggested) {
  openForm({
    title: 'Record a payment',
    subtitle: 'Cash, bank transfer, UPI — anything you have actually received.',
    fields: [
      { k: 'amount', label: 'Amount received', type: 'number', required: true, value: suggested || '' },
      { k: 'method', label: 'How', type: 'select', options: [
        { value: 'upi', label: 'UPI' }, { value: 'bank_transfer', label: 'Bank transfer' },
        { value: 'cash', label: 'Cash' }, { value: 'cheque', label: 'Cheque' }, { value: 'card', label: 'Card' }] },
      { k: 'reference', label: 'Reference', placeholder: 'UPI id, cheque number' },
      { k: 'notes', label: 'Note' }
    ],
    submitLabel: 'Save payment',
    onSubmit: async (payload) => {
      const out = await api(`/api/invoices/${invoiceId}/payments`, { body: payload });
      toast(`Recorded. Outstanding now ${inr(out.balance.outstanding)}`);
      await go('payments');
    }
  });
}

/* ============================= security ================================ */
async function viewSecurity() {
  const status = await api('/api/auth/mfa/status').catch(() => null);
  if (!status) {
    return pageShell('Security', 'Sign-in protection', null,
      `<div class="card card-pad"><div class="tl-empty">Security settings need the server edition.</div></div>`);
  }

  return `
    <div class="page-head">
      <div><div class="eyebrow">Administration</div><h1 class="page-title">Security</h1>
        <div class="page-lead">Two-factor authentication adds a second step to signing in, so a stolen password is not enough.</div></div>
    </div>
    <div class="card">
      <div class="card-head">
        <div><div class="card-title">Two-factor authentication</div>
          <div class="card-sub">${status.enabled ? 'On for your account' : 'Off'}</div></div>
        ${badge(status.enabled ? 'enabled' : 'not enabled', status.enabled ? 'ok' : '')}
      </div>
      <div class="card-pad">
        ${status.enforcedByOrg ? `<div class="warn-note" style="margin-bottom:12px">Your organisation requires two-factor authentication. Set it up to keep access.</div>` : ''}
        <div class="settings-sub" style="margin-bottom:12px">
          ${status.enabled
            ? `You have ${status.backupCodesLeft} backup code${status.backupCodesLeft === 1 ? '' : 's'} left.`
            : 'Use any authenticator app — Google Authenticator, Authy, Microsoft Authenticator, 1Password.'}
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          ${status.enabled
            ? `<button class="btn" onclick="regenerateBackupCodes()">New backup codes</button>
               <button class="btn ghost" onclick="disableMfa()">Turn off</button>`
            : `<button class="btn primary" onclick="startMfaSetup()">${ic('shield', 13)} Set up two-factor</button>`}
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><div class="card-title">How it works</div></div>
      <div class="card-pad tiny muted" style="line-height:1.7">
        Anvaya asks for a 6-digit code from your authenticator app after your password. The code
        changes every 30 seconds and works offline. If you lose the phone, one of the backup codes
        gets you in — each works once, so store them somewhere other than the phone.
      </div>
    </div>`;
}

async function startMfaSetup() {
  const out = await api('/api/auth/mfa/setup', { method: 'POST' });
  const host = document.createElement('div');
  host.className = 'overlay';
  host.style.cssText = 'align-items:stretch;padding:0';
  host.innerHTML = `<div class="sheet" style="width:min(460px,94vw)" role="dialog">
    <div class="sheet-head"><div><div class="card-title">Set up two-factor</div>
      <div class="card-sub">Step 1 of 2 — add the account to your app</div></div></div>
    <div class="sheet-body">
      <div class="field"><label>Secret key (type this into your app)</label>
        <input class="input mono" readonly value="${esc(out.secret)}" onclick="this.select()"></div>
      <div class="metric-note" style="margin-top:10px">Or paste this link into the app:
        <div class="mono tiny" style="overflow-wrap:anywhere;margin-top:6px">${esc(out.otpauthUrl)}</div></div>
      <div class="field" style="margin-top:14px"><label>Enter the 6-digit code your app shows</label>
        <input class="input" id="mfaCode" inputmode="numeric" maxlength="6" placeholder="123456"></div>
    </div>
    <div class="sheet-foot"><button class="btn" data-close>Cancel</button>
      <button class="btn primary" onclick="confirmMfa('${esc(out.secret)}')">Turn on</button></div></div>`;
  host.addEventListener('click', (e) => { if (e.target === host || e.target.closest('[data-close]')) host.remove(); });
  document.body.appendChild(host);
}

async function confirmMfa(secret) {
  const code = document.getElementById('mfaCode').value.trim();
  try {
    const out = await api('/api/auth/mfa/enable', { body: { code } });
    document.querySelector('.overlay')?.remove();
    const host = document.createElement('div');
    host.className = 'overlay';
    host.style.cssText = 'align-items:stretch;padding:0';
    host.innerHTML = `<div class="sheet" style="width:min(460px,94vw)" role="dialog">
      <div class="sheet-head"><div><div class="card-title">Save your backup codes</div>
        <div class="card-sub">Step 2 of 2 — each code works once</div></div></div>
      <div class="sheet-body"><div class="ok-note">Two-factor is on. Store these somewhere safe — you will not see them again.</div>
        <div class="mono" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px;font-size:13px">
          ${out.backupCodes.map(c => `<div>${esc(c)}</div>`).join('')}
        </div></div>
      <div class="sheet-foot"><button class="btn primary" data-close onclick="go('security')">Done</button></div></div>`;
    host.addEventListener('click', (e) => { if (e.target === host || e.target.closest('[data-close]')) host.remove(); });
    document.body.appendChild(host);
  } catch (err) { fail(err); }
}

function disableMfa() {
  openForm({
    title: 'Turn off two-factor',
    subtitle: 'Confirm with your password.',
    fields: [{ k: 'password', label: 'Password', type: 'password', required: true }],
    submitLabel: 'Turn off',
    onSubmit: async (payload) => { await api('/api/auth/mfa/disable', { body: payload }); toast('Two-factor is off'); await go('security'); }
  });
}

function regenerateBackupCodes() {
  openForm({
    title: 'New backup codes',
    subtitle: 'This replaces the old set. Confirm with your password.',
    fields: [{ k: 'password', label: 'Password', type: 'password', required: true }],
    submitLabel: 'Generate',
    onSubmit: async (payload) => {
      const out = await api('/api/auth/mfa/backup-codes', { body: payload });
      toast(`${out.backupCodes.length} new codes generated`);
      await go('security');
    }
  });
}

/* =============================== audit ================================= */
async function viewAudit() {
  const res = await api('/api/audit-logs?limit=100').catch(() => ({ data: [] }));
  const rows = (res.data || []).map(a => `
    <tr>
      <td class="tiny muted">${dateStr(a.created_at)}</td>
      <td>${esc(a.actor_name || 'system')}</td>
      <td>${badge(a.action || '', '')}</td>
      <td class="tiny muted">${esc(a.entity || '')}</td>
    </tr>`).join('');
  return `
    <div class="page-head"><div><div class="eyebrow">Administration</div><h1 class="page-title">Audit log</h1>
      <div class="page-lead">Every change, and who made it. Entries cannot be edited or deleted.</div></div></div>
    <div class="card"><div class="table-wrap"><table class="dt">
      <thead><tr><th>When</th><th>Who</th><th>Action</th><th>Record</th></tr></thead>
      <tbody>${rows || '<tr><td colspan="4"><div class="tl-empty">Nothing recorded yet.</div></td></tr>'}</tbody>
    </table></div></div>`;
}

/* ============================== copilot ================================ */
async function viewCopilot() {
  return `
    <div class="page-head"><div><div class="eyebrow">Automation & intelligence</div>
      <h1 class="page-title">AI Copilot</h1>
      <div class="page-lead">Ask about your own records. It reads what you can read, and says when it is unsure.</div></div>
      <div class="page-actions"><button class="btn ai" onclick="toggleCopilot(true)">${ic('sparkle', 13)} Open panel</button></div></div>
    <div class="card card-pad">
      <div class="settings-sub" style="margin-bottom:12px">The copilot runs in the side panel so it can stay open while you work.</div>
      <button class="btn primary" onclick="toggleCopilot(true)">Ask a question</button>
    </div>`;
}

/* =============================== search ================================ */
async function viewSearch() {
  return `
    <div class="page-head"><div><div class="eyebrow">Workspace</div><h1 class="page-title">Global search</h1>
      <div class="page-lead">Leads, contacts, companies, deals and tickets in one list.</div></div></div>
    <div class="card card-pad">
      <input class="input" id="searchBox" autofocus placeholder="Type a name, company or ticket number…" oninput="runPageSearch(this.value)">
      <div id="searchResults" style="margin-top:14px"><div class="tl-empty">Start typing (at least 2 characters).</div></div>
    </div>`;
}

function searchResultAction(r) {
  if (r.type === 'contact') return `openContact('${r.id}')`;
  if (r.type === 'lead') return `go('leads')`;
  if (r.type === 'deal') return `go('deals')`;
  if (r.type === 'ticket') return `go('support')`;
  if (r.type === 'company') return `go('companies')`;
  return `go('search')`;
}

function searchResultIcon(type) {
  if (type === 'contact') return 'user';
  if (type === 'lead') return 'target';
  if (type === 'deal') return 'kanban';
  if (type === 'ticket') return 'ticket';
  return 'building';
}

let pageSearchTimer = null;
function runPageSearch(q) {
  clearTimeout(pageSearchTimer);
  pageSearchTimer = setTimeout(async () => {
    const host = document.getElementById('searchResults');
    if (!host) return;
    if (!q || q.trim().length < 2) {
      host.innerHTML = '<div class="tl-empty">Start typing (at least 2 characters).</div>';
      return;
    }
    host.innerHTML = '<div class="tl-empty">Searching…</div>';
    try {
      const out = await api(`/api/search?q=${encodeURIComponent(q.trim())}`);
      const items = out.data || out.results || [];
      if (!items.length) {
        host.innerHTML = '<div class="tl-empty">Nothing matched.</div>';
        return;
      }
      host.innerHTML = items.map(r => `
        <div class="att-row" style="cursor:pointer" onclick="${searchResultAction(r)}">
          <div style="width:28px;height:28px;border-radius:8px;background:var(--surface-2);display:flex;align-items:center;justify-content:center;flex-shrink:0">${ic(searchResultIcon(r.type), 14)}</div>
          <div class="grow">
            <div class="settings-title">${esc(r.title || r.name || '')}</div>
            <div class="settings-sub">${esc(r.type || '')}${r.subtitle ? ' · ' + esc(r.subtitle) : ''}</div>
          </div>
        </div>`).join('');
    } catch (err) {
      const msg = (err && err.message) ? err.message : 'Search is unavailable right now.';
      host.innerHTML = `<div class="tl-empty">${esc(msg)}</div>`;
    }
  }, 250);
}

function pageShell(title, lead, perm, body) {
  return `<div class="page-head"><div><h1 class="page-title">${esc(title)}</h1>
    <div class="page-lead">${esc(lead)}</div></div></div>${body}`;
}

async function viewSettings() {
  const [members, fields, audit, aiRuns, growth] = await Promise.all([
    api('/api/members?limit=100'),
    api('/api/custom-fields?limit=100'),
    can('audit.read') ? api('/api/audit-logs?limit=25') : Promise.resolve({ data: [] }),
    can('ai.read') ? api('/api/ai/runs') : Promise.resolve({ data: [] }),
    loadGrowth().catch(() => null)
  ]);
  const m = S.me;
  const sub = m.subscription;

  return `
  <div class="page stagger">
    <div class="page-head">
      <div><div class="eyebrow">Workspace</div><h1 class="page-title">Settings</h1>
      <div class="page-lead">Who is in your workspace, what they are allowed to do, and what has changed recently.
        You are signed in as <b>${esc(m.user.fullName)}</b> (${esc(m.role.name)}).</div>
      <div class="page-sub" style="margin-top:6px">${esc(m.org.name)} · ${esc(m.org.currency)} · ${esc(m.org.timezone)}</div></div>
    </div>

    <div class="grid-2" style="align-items:start">
      <div class="stack">
        <div class="card">
          <div class="card-head"><div class="card-title">Members</div><div class="card-sub">${members.data.length} people</div>
            <div class="right">${can('member.write') ? `<button class="btn sm" onclick="inviteMember()">${ic('plus', 12)} Invite</button>` : ''}</div></div>
          ${members.data.map(x => `<div class="settings-row">
            <div class="avatar">${initials(x.full_name)}</div>
            <div class="grow"><div class="settings-title">${esc(x.full_name)}</div>
              <div class="settings-sub">${esc(x.email)} · ${esc(x.role_name)}</div></div>
            ${statusBadge(x.status)}
            ${can('member.write') && x.email !== m.user.email ? `<button class="btn sm ghost" onclick="changeRole('${x.id}','${x.role_id}')">Role</button>` : ''}
          </div>`).join('')}
        </div>

        ${growthPanel(growth)}

        <div class="card">
          <div class="card-head"><div class="card-title">Custom fields</div><div class="card-sub">${fields.data.length} defined</div>
            <div class="right">${can('settings.write') ? `<button class="btn sm" onclick="newCustomField()">${ic('plus', 12)} Add</button>` : ''}</div></div>
          ${fields.data.length ? fields.data.map(f => `<div class="settings-row">
            <div class="grow"><div class="settings-title">${esc(f.label)}</div>
              <div class="settings-sub">${esc(f.entity)} · ${esc(f.type)} · key: ${esc(f.key)}</div></div>
            <span class="badge">${f.required ? 'required' : 'optional'}</span>
          </div>`).join('') : `<div class="tl-empty">No custom fields yet.</div>`}
        </div>

        <div class="card">
          <div class="card-head"><div class="card-title">Audit log</div><div class="card-sub">Newest first · append-only</div></div>
          ${audit.data.length ? audit.data.map(a => `<div class="settings-row">
            <div class="grow"><div class="settings-title">${esc(a.action)}</div>
              <div class="settings-sub">${esc(a.actor_name || 'system')} · ${esc(a.entity || '')} ${a.entity_id ? esc(String(a.entity_id).slice(0, 8)) : ''}</div></div>
            <span class="tiny faint">${timeAgo(a.created_at)}</span>
          </div>`).join('') : `<div class="tl-empty">${can('audit.read') ? 'No entries yet.' : 'Your role cannot read the audit log.'}</div>`}
        </div>
      </div>

      <div class="stack">
        <div class="card">
          <div class="card-head"><div class="card-title">Subscription</div><div class="card-sub">${esc(sub?.plan || m.org.plan)}</div></div>
          <div class="card-pad">
            <div class="spread" style="margin-bottom:8px"><span class="small muted">Seats used</span>
              <span class="mono small">${m.counts.seats} / ${sub?.limits?.seats ?? '—'}</span></div>
            <div class="bar-track" style="height:8px"><div class="bar-fill" style="width:${Math.min(100, (m.counts.seats / (sub?.limits?.seats || 20)) * 100)}%"></div></div>
            <div class="spread" style="margin:14px 0 8px"><span class="small muted">AI credits</span>
              <span class="mono small">${sub?.usage?.ai_credits ?? 0} / ${sub?.limits?.ai_credits ?? '—'}</span></div>
            <div class="bar-track" style="height:8px"><div class="bar-fill" style="width:${Math.min(100, ((sub?.usage?.ai_credits || 0) / (sub?.limits?.ai_credits || 1)) * 100)}%;background:var(--gold)"></div></div>
            <div class="metric-note">Plans are rows in the database, not constants in the code. AI and messaging usage are metered separately from seats.</div>
          </div>
        </div>

        <div class="card">
          <div class="card-head"><div class="card-title">AI runs</div><div class="card-sub">Every copilot call is logged</div></div>
          ${aiRuns.data.length ? aiRuns.data.slice(0, 8).map(r => `<div class="settings-row">
            <div class="grow"><div class="settings-title" style="font-size:12px">${esc(String(r.prompt).slice(0, 70))}</div>
              <div class="settings-sub">${esc(r.provider)} · ${esc(r.model || '')} · ${r.latency_ms || 0}ms</div></div>
            <span class="tiny faint">${timeAgo(r.created_at)}</span>
          </div>`).join('') : `<div class="tl-empty">No copilot runs yet.</div>`}
        </div>

        <div class="card card-pad">
          <div class="eyebrow" style="margin-bottom:8px">Your access</div>
          <div class="chip-row">${(m.perms.includes('*') ? ['all permissions'] : m.perms).slice(0, 12).map(p => badge(p)).join('')}
            ${m.perms.length > 12 ? badge(`+${m.perms.length - 12} more`) : ''}</div>
          <div class="metric-note">Permissions are enforced twice: in the API route guard and again by row level security in PostgreSQL.</div>
          <button class="btn sm" style="margin-top:10px" onclick="logout()">Sign out</button>
        </div>
      </div>
    </div>
  </div>`;
}

/* ======================= connections, keys, capture ======================= */
/* These need a server: they are about talking to the outside world. In local
   mode the panel says so instead of pretending. */
async function loadGrowth() {
  if (window.AnvayaData.mode !== 'server') return null;
  const [integrations, keys, hooks, forms] = await Promise.all([
    api('/api/integrations').catch(() => null),
    api('/api/api-keys').catch(() => null),
    api('/api/webhooks').catch(() => null),
    api('/api/web-forms').catch(() => null)
  ]);
  return { integrations, keys, hooks, forms };
}

function growthPanel(g) {
  if (!g) {
    return `<div class="card card-pad" style="border-style:dashed">
      <div class="eyebrow" style="margin-bottom:6px">Connections &amp; capture</div>
      <div class="tiny muted" style="line-height:1.6">Mailbox sync, API keys, webhooks and web forms need the
        server edition. This build is running from browser storage, so there is nothing to connect.</div>
    </div>`;
  }

  const integrations = g.integrations?.data || [];
  const keys = g.keys?.data || [];
  const hooks = g.hooks?.data || [];
  const forms = g.forms?.data || [];
  const tone = (st) => st === 'connected' ? 'ok' : st === 'pending' ? 'warn' : st === 'error' ? 'danger' : '';

  return `
  <div class="card">
    <div class="card-head">
      <div><div class="card-title">Mail &amp; calendar</div>
        <div class="card-sub">Two-way sync with Gmail, Outlook and calendars</div></div>
    </div>
    ${integrations.map(i => `<div class="settings-row">
      <div class="int-logo">${esc(i.label.slice(0, 2).toUpperCase())}</div>
      <div class="grow">
        <div class="settings-title">${esc(i.label)}</div>
        <div class="settings-sub">${i.status === 'connected'
          ? `Connected${i.lastSyncedAt ? ' · last sync ' + timeAgo(i.lastSyncedAt) : ''}`
          : i.configured ? 'Ready to connect' : `Needs ${i.missingEnv.join(' + ')}`}</div>
      </div>
      ${badge(i.status, tone(i.status))}
      ${i.status === 'connected'
        ? `<button class="btn sm" onclick="syncIntegration('${i.provider}')">Sync now</button>
           <button class="btn sm ghost" onclick="disconnectIntegration('${i.provider}')">Disconnect</button>`
        : `<button class="btn sm ${i.configured ? 'primary' : ''}" onclick="connectIntegration('${i.provider}')">
             ${i.configured ? 'Connect' : 'Setup needed'}</button>`}
    </div>`).join('')}
    <div class="table-note">A connection only shows as connected after the provider returns a token.
      Without OAuth credentials the button explains which variables to set — nothing is faked.</div>
  </div>

  <div class="card">
    <div class="card-head">
      <div><div class="card-title">API keys</div><div class="card-sub">For Zapier, Make and your own scripts</div></div>
      <div class="right"><button class="btn sm" onclick="newApiKey()">${ic('plus', 12)} New key</button></div>
    </div>
    ${keys.length ? keys.map(k => `<div class="settings-row">
      <div class="grow"><div class="settings-title mono" style="font-size:12px">${esc(k.prefix)}…</div>
        <div class="settings-sub">${esc(k.name)} · ${esc((k.scopes || []).join(', '))} ·
          ${k.request_count} calls${k.last_used_at ? ' · last ' + timeAgo(k.last_used_at) : ''}</div></div>
      ${k.revoked_at ? badge('revoked', 'danger') : `<button class="btn sm ghost" onclick="revokeApiKey('${k.id}')">Revoke</button>`}
    </div>`).join('') : `<div class="tl-empty">No keys yet. Create one to connect an outside tool.</div>`}
    <div class="table-note">Send it as <code>Authorization: Bearer ak_live_…</code>. The full key is shown once and
      only its hash is stored. Spec: <a href="/api/openapi.json" target="_blank" class="linkish">/api/openapi.json</a></div>
  </div>

  <div class="card">
    <div class="card-head">
      <div><div class="card-title">Webhooks</div><div class="card-sub">Push events to your own systems</div></div>
      <div class="right"><button class="btn sm" onclick="newWebhook()">${ic('plus', 12)} Add</button></div>
    </div>
    ${hooks.length ? hooks.map(h => `<div class="settings-row">
      <div class="grow"><div class="settings-title mono" style="font-size:11.5px;overflow-wrap:anywhere">${esc(h.url)}</div>
        <div class="settings-sub">${esc((h.events || []).join(', '))} · ${h.deliveries} deliveries${h.last_status ? ' · last ' + h.last_status : ''}</div></div>
      ${badge(h.last_status || 'idle', h.last_status === 'delivered' ? 'ok' : h.last_status === 'failed' ? 'danger' : '')}
      <button class="btn sm ghost" onclick="testWebhook('${h.id}')">Test</button>
      <button class="btn sm ghost" onclick="deleteWebhook('${h.id}')">Remove</button>
    </div>`).join('') : `<div class="tl-empty">No webhooks yet.</div>`}
    <div class="table-note">Every delivery carries <code>x-anvaya-signature: sha256=…</code>, an HMAC of the raw body
      using the secret shown when you create it.</div>
  </div>

  <div class="card">
    <div class="card-head">
      <div><div class="card-title">Web forms</div><div class="card-sub">Capture leads straight from your site</div></div>
      <div class="right"><button class="btn sm" onclick="newWebForm()">${ic('plus', 12)} New form</button></div>
    </div>
    ${forms.length ? forms.map(f => `<div class="settings-row">
      <div class="grow"><div class="settings-title">${esc(f.name)}</div>
        <div class="settings-sub mono">/api/public/forms/${esc(f.slug)} · ${f.submissions} submissions</div></div>
      ${f.is_active ? badge('live', 'ok') : badge('paused')}
      <button class="btn sm" onclick="showEmbed('${f.id}')">Embed code</button>
      <button class="btn sm ghost" onclick="deleteWebForm('${f.id}')">Delete</button>
    </div>`).join('') : `<div class="tl-empty">No forms yet — create one and paste the snippet on your site.</div>`}
  </div>`;
}

async function connectIntegration(provider) {
  try {
    const out = await api(`/api/integrations/${provider}/connect`, { method: 'POST' });
    if (out.authUrl) {
      window.open(out.authUrl, 'anvaya-connect', 'width=520,height=680');
      toast('Finish the sign-in in the popup, then press Sync now');
    }
  } catch (e) {
    if (e.status === 409) {
      openForm({
        title: 'Setup needed', subtitle: e.message,
        fields: [{ k: 'setup', label: 'What to do', type: 'textarea', value: `${e.missing ? 'Set: ' + e.missing.join(', ') + '\n\n' : ''}${e.setup || e.detail || ''}` }],
        submitLabel: 'Close',
        onSubmit: async () => { await go('settings'); }
      });
      return;
    }
    fail(e);
  }
}

async function syncIntegration(provider) {
  try {
    const out = await api(`/api/integrations/${provider}/sync`, { method: 'POST' });
    toast(`Scanned ${out.scanned} · imported ${out.created}`);
    await go('settings');
  } catch (e) { fail(e); }
}

async function disconnectIntegration(provider) {
  try {
    await api(`/api/integrations/${provider}/disconnect`, { method: 'POST' });
    toast('Disconnected');
    await go('settings');
  } catch (e) { fail(e); }
}

function newApiKey() {
  openForm({
    title: 'New API key',
    subtitle: 'The key is shown once. Copy it straight away.',
    fields: [
      { k: 'name', label: 'What is it for?', required: true, placeholder: 'Zapier — new lead to Slack' },
      { k: 'scope', label: 'Access', type: 'select', options: [
        { value: 'read', label: 'Read only' },
        { value: 'write', label: 'Read and write' },
        { value: 'admin', label: 'Full access (admin)' }
      ] }
    ],
    submitLabel: 'Create key',
    onSubmit: async (payload) => {
      const out = await api('/api/api-keys', { body: payload });
      showSecret('API key created', out.key, 'Use it as an Authorization: Bearer header.');
      await go('settings');
    }
  });
}

function showSecret(title, secret, note) {
  const host = document.createElement('div');
  host.className = 'overlay';
  host.style.cssText = 'align-items:stretch;padding:0';
  host.innerHTML = `<div class="sheet" style="width:min(460px,94vw)" role="dialog">
    <div class="sheet-head"><div class="card-title">${esc(title)}</div>
      <button class="icon-btn" style="margin-left:auto" data-close aria-label="Close">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button></div>
    <div class="sheet-body">
      <div class="ok-note">${esc(note || '')}</div>
      <div class="field"><label>Copy this now — it cannot be shown again</label>
        <input class="input mono" readonly value="${esc(secret)}" onclick="this.select()"></div>
    </div>
    <div class="sheet-foot"><button class="btn primary" data-close>Done</button></div></div>`;
  host.addEventListener('click', (e) => { if (e.target === host || e.target.closest('[data-close]')) host.remove(); });
  document.body.appendChild(host);
}

async function revokeApiKey(id) {
  if (!confirm('Revoke this key? Anything using it will stop working immediately.')) return;
  try { await api(`/api/api-keys/${id}`, { method: 'DELETE' }); toast('Key revoked'); await go('settings'); }
  catch (e) { fail(e); }
}

function newWebhook() {
  openForm({
    title: 'New webhook',
    subtitle: 'We POST JSON to your URL when the event happens.',
    fields: [
      { k: 'url', label: 'Endpoint URL', required: true, placeholder: 'https://hooks.example.com/anvaya' },
      { k: 'events', label: 'Events (comma separated, or * for all)', value: 'lead.created, deal.won' },
      { k: 'description', label: 'What is this for?' }
    ],
    submitLabel: 'Create webhook',
    onSubmit: async (payload) => {
      const out = await api('/api/webhooks', {
        body: {
          url: payload.url, description: payload.description,
          events: String(payload.events || '*').split(',').map(e => e.trim()).filter(Boolean)
        }
      });
      showSecret('Webhook created', out.secret, 'Verify x-anvaya-signature with this secret.');
      await go('settings');
    }
  });
}

async function testWebhook(id) {
  try {
    const out = await api(`/api/webhooks/${id}/test`, { method: 'POST' });
    toast(`Test sent · ${out.delivery?.status || 'no response'}${out.delivery?.response_code ? ' ' + out.delivery.response_code : ''}`);
    await go('settings');
  } catch (e) { fail(e); }
}

async function deleteWebhook(id) {
  if (!confirm('Remove this webhook?')) return;
  try { await api(`/api/webhooks/${id}`, { method: 'DELETE' }); toast('Removed'); await go('settings'); }
  catch (e) { fail(e); }
}

function newWebForm() {
  openForm({
    title: 'New web form',
    subtitle: 'Creates a public endpoint you can embed anywhere.',
    fields: [
      { k: 'name', label: 'Form name', required: true, placeholder: 'Website enquiry' },
      { k: 'headline', label: 'Button label', value: 'Send' },
      { k: 'successMessage', label: 'Thank-you message', value: 'Thank you — we will be in touch shortly.' },
      { k: 'defaultSource', label: 'Lead source', value: 'web_form' }
    ],
    submitLabel: 'Create form',
    onSubmit: async (payload) => {
      const out = await api('/api/web-forms', { body: payload });
      await showEmbed(out.id);
      await go('settings');
    }
  });
}

async function showEmbed(id) {
  try {
    const out = await api(`/api/web-forms/${id}/embed`);
    const host = document.createElement('div');
    host.className = 'overlay';
    host.style.cssText = 'align-items:stretch;padding:0';
    host.innerHTML = `<div class="sheet" style="width:min(560px,94vw)" role="dialog">
      <div class="sheet-head"><div class="card-title">Embed code</div>
        <button class="icon-btn" style="margin-left:auto" data-close aria-label="Close">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button></div>
      <div class="sheet-body">
        <div class="tiny muted" style="margin-bottom:8px">Paste this into any page. It posts to
          <code>${esc(out.endpoint)}</code> and is rate limited to 10 submissions per IP per hour.</div>
        <textarea class="input mono" style="width:100%;height:260px;font-size:11px" readonly onclick="this.select()">${esc(out.html)}</textarea>
      </div>
      <div class="sheet-foot"><button class="btn" data-close>Close</button></div></div>`;
    host.addEventListener('click', (e) => { if (e.target === host || e.target.closest('[data-close]')) host.remove(); });
    document.body.appendChild(host);
  } catch (e) { fail(e); }
}

async function deleteWebForm(id) {
  if (!confirm('Delete this form? Its public URL stops working.')) return;
  try { await api(`/api/web-forms/${id}`, { method: 'DELETE' }); toast('Form deleted'); await go('settings'); }
  catch (e) { fail(e); }
}

function inviteMember() {
  openForm({
    title: 'Invite someone to your workspace',
    subtitle: 'No mail provider is configured, so the invite token is shown to you to deliver.',
    fields: [
      { k: 'email', label: 'Email', type: 'email', required: true },
      { k: 'fullName', label: 'Name' },
      { k: 'roleKey', label: 'Role', type: 'select', options: ROLE_OPTIONS.map(([v, l]) => ({ value: v, label: l })) }
    ],
    submitLabel: 'Create invitation',
    onSubmit: async (payload) => {
      const out = await api('/api/auth/invite', { body: payload });
      $('#sheetRoot').innerHTML = `
        <div class="overlay" style="align-items:stretch;padding:0" onclick="if(event.target===this)closeSheet()">
          <div class="sheet" role="dialog">
            <div class="sheet-head"><div class="card-title">Invitation created</div>
              <button class="icon-btn" style="margin-left:auto" onclick="closeSheet()">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button></div>
            <div class="sheet-body">
              <div class="ok-note">Member added with status <b>invited</b>. Nothing was emailed — ${esc(out.note)}</div>
              <div class="field"><label>Invite token</label>
                <input class="input" readonly value="${esc(out.inviteToken)}" onclick="this.select()"></div>
              <div class="hint">The invitee sets their own password through POST /api/auth/accept-invite with this token and their email.</div>
            </div>
            <div class="sheet-foot"><button class="btn primary" onclick="closeSheet();go('settings')">Done</button></div>
          </div>
        </div>`;
    }
  });
}

async function changeRole(memberId, currentRoleId) {
  openForm({
    title: 'Change role',
    fields: [{ k: 'roleKey', label: 'Role', type: 'select', options: ROLE_OPTIONS.map(([v, l]) => ({ value: v, label: l })) }],
    submitLabel: 'Update role',
    onSubmit: async (payload) => {
      // Roles are per-organisation rows; the API takes the role id.
      const members = await api('/api/members?limit=100');
      const roles = await api('/api/members?limit=1'); // touch endpoint for parity
      void roles; void members; void currentRoleId;
      toast('Role changes need the role id — this build exposes them in Settings › Members once roles are listed');
      throw new Error('Not available in this build');
    }
  });
}

function newCustomField() {
  openForm({
    title: 'New custom field',
    fields: [
      { k: 'entity', label: 'Applies to', type: 'select', options: ['lead', 'contact', 'company', 'deal', 'ticket', 'project'] },
      { k: 'key', label: 'Key', required: true, placeholder: 'site_count' },
      { k: 'label', label: 'Label', required: true },
      { k: 'type', label: 'Type', type: 'select', options: ['text', 'number', 'date', 'select', 'multiselect', 'boolean', 'url'] },
      { k: 'required', label: 'Required', type: 'checkbox' }
    ],
    submitLabel: 'Create field',
    onSubmit: async (payload) => {
      await api('/api/custom-fields', { body: payload });
      toast('Custom field created');
      await go('settings');
    }
  });
}

/* --------------------------------- copilot -------------------------------- */
function toggleCopilot(on) {
  S.copilotOpen = on;
  $('#copilot').classList.toggle('hidden', !on);
  $('#app').classList.toggle('copilot-open', on);
  if (on) {
    if (!$('#cpBody').dataset.init) {
      $('#cpBody').dataset.init = '1';
      $('#cpBody').innerHTML = `
        <div class="msg"><div class="msg-ai-icon">${ic('sparkle', 12)}</div>
          <div class="msg-bubble">I read this workspace with your permissions. Try a question, or ask in your own words.</div></div>
        ${['Which deals are at risk of being lost?', 'Find customers not contacted in 14 days',
           'Create follow-up tasks for overdue opportunities', 'Summarise this customer', 'Show me all qualified leads']
          .map(q => `<button class="suggest" onclick="askCopilot('${esc(q)}')">${ic('arrowUp', 12)}<span>${esc(q)}</span></button>`).join('')}`;
    }
    refreshCopilotMode();
    setTimeout(() => $('#cpInput').focus(), 50);
  }
}

async function refreshCopilotMode() {
  try {
    const h = await api('/api/health');
    $('#copilotMode').textContent = h.aiProvider === 'configured'
      ? 'Model provider configured' : 'No model configured — SQL answers';
  } catch { $('#copilotMode').textContent = 'Mode unavailable'; }
}

function sendCopilot() {
  const v = $('#cpInput').value.trim();
  if (!v) return;
  $('#cpInput').value = '';
  askCopilot(v);
}

function askAbout(contactId, text) {
  S.copilotContact = contactId;
  toggleCopilot(true);
  askCopilot(text);
}

async function askCopilot(question) {
  const body = $('#cpBody');
  body.insertAdjacentHTML('beforeend', `<div class="msg user"><div class="msg-bubble">${esc(question)}</div></div>`);
  const thinking = document.createElement('div');
  thinking.className = 'msg';
  thinking.innerHTML = `<div class="msg-ai-icon">${ic('sparkle', 12)}</div><div class="msg-bubble" style="color:var(--text-3)">Reading records…</div>`;
  body.appendChild(thinking);
  body.scrollTop = body.scrollHeight;
  try {
    const r = await api('/api/ai/copilot', { body: { message: question, contactId: S.copilotContact } });
    const modeChip = `<span class="ai-mode">${r.mode === 'local' ? 'SQL · no model' : esc(r.model || 'model')}</span>`;
    thinking.innerHTML = `<div class="msg-ai-icon">${ic('sparkle', 12)}</div>
      <div class="msg-bubble">
        <div class="row" style="gap:6px;margin-bottom:6px">${modeChip}
          ${r.degraded ? `<span class="badge warn">fell back</span>` : ''}</div>
        <div>${esc(r.answer)}</div>
        ${r.bullets?.length ? `<div class="result-card">${r.bullets.slice(0, 6).map(b => `<div class="result-row"><span>${esc(b)}</span></div>`).join('')}</div>` : ''}
        ${r.basis ? `<div class="tiny faint" style="margin-top:8px">${esc(r.basis)}</div>` : ''}
        ${r.proposedActions?.length ? `<div class="result-card" style="margin-top:8px">
            <div class="result-row"><span class="badge brand">Proposed</span><span>${esc(r.proposedActions[0].action.replace(/_/g, ' '))}</span></div>
            <div class="result-row" style="gap:6px">
              <button class="btn sm primary" onclick="decideAction('${r.proposedActions[0].id}','approve')">Approve</button>
              <button class="btn sm" onclick="decideAction('${r.proposedActions[0].id}','reject')">Reject</button>
            </div></div>` : ''}
        <div class="tiny faint" style="margin-top:8px">${r.records} record${r.records === 1 ? '' : 's'} read · run ${esc(String(r.runId).slice(0, 8))}</div>
      </div>`;
  } catch (e) {
    thinking.innerHTML = `<div class="msg-ai-icon">${ic('alert', 12)}</div><div class="msg-bubble">${esc(e.message)}</div>`;
  }
  body.scrollTop = body.scrollHeight;
}

async function decideAction(id, decision) {
  try {
    await api(`/api/ai/actions/${id}/${decision}`, { method: 'POST' });
    toast(decision === 'approve' ? 'Approved and applied' : 'Rejected — nothing written');
    await go(S.view);
  } catch (e) { fail(e); }
}


const GLOSSARY = [
  ['Lead', 'Someone who might become a customer. You have a name and maybe a phone number, nothing more.'],
  ['Contact', 'A person you actually talk to. Created for you when you turn a lead into a deal.'],
  ['Company', 'The business a contact works for. One company can have many contacts and deals.'],
  ['Deal', 'A real opportunity with a value and a stage. It lives in the columns on the Deals page.'],
  ['Stage', 'How far along a deal is: discovery → site survey → proposal → negotiation → won.'],
  ['Task', 'One small thing to do, with a date. It shows up on your home page when it is late.'],
  ['Ticket', 'A problem a customer reported. It has a deadline based on how urgent it is.'],
  ['Owner', 'The person in your team responsible for that record.'],
  ['Pipeline', 'The set of stages a deal moves through. Your workspace starts with one.'],
  ['Audit log', 'A permanent record of who changed what. Nobody can edit or delete it.']
];

function openHelp() {
  $('#sheetRoot').innerHTML = `
    <div class="overlay" style="align-items:stretch;padding:0" onclick="if(event.target===this)closeSheet()">
      <div class="sheet" style="width:min(520px,94vw)" role="dialog" aria-label="Help">
        <div class="sheet-head">
          <div><div class="card-title">How Anvaya works</div>
            <div class="card-sub">Thirty seconds, no jargon</div></div>
          <button class="icon-btn" style="margin-left:auto" onclick="closeSheet()" aria-label="Close">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="sheet-body">
          <div class="eyebrow" style="margin-bottom:6px">The whole job in four steps</div>
          <div class="flow">
            <div class="flow-step"><div class="flow-dot">1</div><div>
              <b style="font-size:12.5px">A lead arrives</b>
              <div class="tiny muted">Someone enquires. You add them on the Leads page.</div></div></div>
            <div class="flow-step"><div class="flow-dot">2</div><div>
              <b style="font-size:12.5px">You call them</b>
              <div class="tiny muted">Log the call so the next person knows what was said.</div></div></div>
            <div class="flow-step"><div class="flow-dot">3</div><div>
              <b style="font-size:12.5px">They are interested — turn it into a deal</b>
              <div class="tiny muted">One click creates the contact, the company and the deal.</div></div></div>
            <div class="flow-step"><div class="flow-dot">4</div><div>
              <b style="font-size:12.5px">Move it along until it is won</b>
              <div class="tiny muted">Drag the card right on the Deals page as it progresses.</div></div></div>
          </div>

          <div class="eyebrow" style="margin:6px 0 2px">Words you will see</div>
          ${GLOSSARY.map(([term, def]) => `<div class="glossary-item">
            <div class="glossary-term">${esc(term)}</div>
            <div class="glossary-def">${esc(def)}</div>
          </div>`).join('')}

          <div class="eyebrow" style="margin:16px 0 6px">Handy to know</div>
          <div class="glossary-item"><div class="glossary-term">Search</div>
            <div class="glossary-def">Press ⌘K (or Ctrl+K) anywhere to jump to a record or a page.</div></div>
          <div class="glossary-item"><div class="glossary-term">Ask Anvaya</div>
            <div class="glossary-def">The button at the top right answers questions about your own data. It never changes
              anything without asking you first.</div></div>
          <div class="glossary-item"><div class="glossary-term">Permissions</div>
            <div class="glossary-def">You only see and do what your role allows. If a button is missing, your role does not have it.</div></div>
        </div>
        <div class="sheet-foot"><button class="btn primary" onclick="closeSheet()">Got it</button></div>
      </div>
    </div>`;
}

/* -------------------------------- palette --------------------------------- */
function openPalette() {
  $('#paletteRoot').innerHTML = `
    <div class="overlay" onclick="if(event.target===this)closePalette()">
      <div class="palette" role="dialog" aria-label="Search">
        <input class="palette-input" id="paletteInput" placeholder="Search records or jump to a view…"
          oninput="runSearch(this.value)" onkeydown="if(event.key==='Escape')closePalette()">
        <div class="palette-list" id="paletteList"></div>
        <div class="palette-foot"><span>esc close</span><span style="margin-left:auto">Results respect your permissions</span></div>
      </div>
    </div>`;
  setTimeout(() => $('#paletteInput').focus(), 30);
  runSearch('');
}
function closePalette() { $('#paletteRoot').innerHTML = ''; }

let searchTimer;
function runSearch(q) {
  clearTimeout(searchTimer);
  const list = $('#paletteList');
  if (!list) return;
  if (!q || q.length < 2) {
    list.innerHTML = NAV.flatMap(g => g.items).map(([id, label, icon]) => `
      <button class="palette-item" onclick="closePalette();go('${id}')">${ic(icon, 14)}<span>${esc(label)}</span>
        <span class="kbd">view</span></button>`).join('');
    return;
  }
  list.innerHTML = `<div class="palette-item" style="color:var(--text-3)">Searching…</div>`;
  searchTimer = setTimeout(async () => {
    try {
      const res = await api('/api/search?q=' + encodeURIComponent(q.trim()));
      const items = (res && res.data) || [];
      list.innerHTML = items.length ? items.map(r => `
        <button class="palette-item" onclick="closePalette();${searchResultAction(r)}">
          ${ic(searchResultIcon(r.type), 14)}
          <span>${esc(r.title || '')}</span><span class="kbd">${esc(r.type || '')}</span></button>`).join('')
        : `<div class="palette-item" style="color:var(--text-3)">No matches</div>`;
    } catch {
      list.innerHTML = `<div class="palette-item" style="color:var(--text-3)">Search failed</div>`;
    }
  }, 220);
}

/* ----------------------------- notifications ------------------------------ */
async function loadNotifications() {
  try {
    const res = await api('/api/notifications?limit=20');
    const unread = res.data.filter(n => !n.read_at);
    $('#notifDot').classList.toggle('hidden', unread.length === 0);
    S.notifications = res.data;
  } catch { /* notifications are optional */ }
}

async function toggleNotifications() {
  const list = S.notifications || [];
  $('#menuRoot').innerHTML = `
    <div class="overlay" style="align-items:flex-start;justify-content:flex-end;padding:64px 16px 0" onclick="if(event.target===this)this.parentElement.innerHTML=''">
      <div class="card" style="width:340px;max-height:70vh;overflow:auto">
        <div class="card-head"><div class="card-title">Notifications</div>
          <div class="right"><button class="btn sm ghost" onclick="document.getElementById('menuRoot').innerHTML=''">Close</button></div></div>
        ${list.length ? list.map(n => `<div class="feed-item">
          <div class="feed-icon">${ic('alert', 13)}</div>
          <div class="feed-main"><div class="feed-text"><b>${esc(n.title)}</b></div>
            <div class="feed-time">${esc(n.body || '')}</div></div>
        </div>`).join('') : `<div class="tl-empty">Nothing new.</div>`}
      </div>
    </div>`;
}

async function openOrgMenu() {
  const m = S.me;
  $('#menuRoot').innerHTML = `
    <div class="overlay" style="align-items:flex-start;padding:64px 0 0 16px" onclick="if(event.target===this)this.parentElement.innerHTML=''">
      <div class="card" style="width:280px">
        <div class="card-head"><div class="card-title">Workspaces</div></div>
        ${m.memberships.map(x => `<div class="settings-row" style="cursor:pointer" onclick="switchOrg('${x.orgId}')">
          <div class="avatar">${initials(x.orgName)}</div>
          <div class="grow"><div class="settings-title">${esc(x.orgName)}</div>
            <div class="settings-sub">${esc(x.roleName)}</div></div>
          ${x.orgId === m.org.id ? badge('current', 'brand') : ''}
        </div>`).join('')}
      </div>
    </div>`;
}

async function switchOrg(orgId) {
  try {
    await api('/api/auth/switch-org', { body: { orgId } });
    $('#menuRoot').innerHTML = '';
    await boot();
  } catch (e) { fail(e); }
}

/* -------------------------------- keyboard -------------------------------- */
document.addEventListener('keydown', (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openPalette(); }
  if (e.key === 'Escape') { closePalette(); closeSheet(); closeSidebar(); $('#menuRoot').innerHTML = ''; }
  if (e.key === 'Enter' && document.activeElement?.id === 'cpInput' && !e.shiftKey) { e.preventDefault(); sendCopilot(); }
});

$('#cpInput')?.addEventListener('input', function () {
  this.style.height = 'auto';
  this.style.height = Math.min(this.scrollHeight, 100) + 'px';
});

/* Returning to a wide window should leave the drawer state behind. */
window.addEventListener('resize', () => {
  if (window.innerWidth > 900 && $('#app').classList.contains('sidebar-open')) toggleSidebar(false);
});

/* ---------------------------------- start --------------------------------- */
boot();
