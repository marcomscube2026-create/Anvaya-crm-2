# Anvaya CRM — backend

Express + PostgreSQL (PGlite, in-process). Multi-tenant with row level security, session
auth, a workflow engine, an audit trail and a copilot.

```bash
npm install
npm run seed      # schema + demo workspace
npm start         # http://localhost:4000, also serves ../web
npm test          # 34 tests
```

Demo login: **sneha@brightline.in** / **AnvayaDemo2026**

## Layout

```
src/server.js       boot: migrate, listen
src/app.js          routes
src/db.js           connection, transactions, asUser (RLS context)
src/auth.js         scrypt passwords, hashed session tokens, request context
src/permissions.js  9 role templates → permission keys
src/resources.js    generic CRUD with column allow-lists
src/workflows.js    trigger → conditions → actions → approval → logs
src/intelligence.js analytics + copilot
src/audit.js        append-only audit trail
db/migrations/      001_schema.sql (38 tables), 002_rls.sql (134 policies)
db/seed.js          demo workspace
```

## Notes

- **Paths are anchored to the package**, so `npm start` works from `backend/` or from the
  repo root.
- **The database is embedded**, so this needs a writable disk. It is not serverless —
  deploy it to Railway, Render, Fly.io or a VM. See `../DEPLOY.md`.
- **`GET /api/health` returns `{ "mode": "server" }`**, which is how the web app decides
  to use the API instead of browser storage.
- **`CORS_ORIGIN`** lets a static deployment on another domain call this API.

## Environment

```
PORT=4000
DB_PATH=./.data/anvaya      # writable, persisted
CORS_ORIGIN=                # exact origin of the static site, if it is elsewhere
AI_API_KEY=                 # optional; without it the copilot answers from SQL
AI_BASE_URL=https://api.openai.com/v1
AI_MODEL=gpt-4o-mini
```
