// Role templates. Permissions are expanded to explicit `<entity>.<action>`
// keys because the database policies check for them by name.

const ENTITIES = [
  'lead', 'contact', 'company', 'deal', 'pipeline', 'activity', 'task', 'ticket',
  'campaign', 'product', 'quotation', 'invoice', 'payment', 'project', 'workflow',
  'ai', 'settings', 'billing', 'integration', 'member', 'workspace', 'notification'
];

function perms(spec) {
  const out = new Set();
  for (const [entity, actions] of Object.entries(spec)) {
    for (const a of actions) {
      if (a === 'read') out.add(`${entity}.read`);
      if (a === 'write') { out.add(`${entity}.write`); out.add(`${entity}.read`); }
      if (a === 'delete') { out.add(`${entity}.delete`); out.add(`${entity}.write`); out.add(`${entity}.read`); }
    }
  }
  return [...out].sort();
}

const all = Object.fromEntries(ENTITIES.map(e => [e, ['read', 'write', 'delete']]));

export const ROLE_TEMPLATES = {
  owner: {
    name: 'Owner', description: 'Full access including billing, roles and deletion',
    permissions: ['*']
  },
  admin: {
    name: 'Org admin', description: 'Everything except ownership transfer and workspace deletion',
    permissions: [...new Set([...perms(all), 'audit.read', 'report.read'])]
  },
  manager: {
    name: 'Manager', description: 'Team records, approvals and every report',
    permissions: perms({
      lead: ['read', 'write', 'delete'], contact: ['read', 'write', 'delete'], company: ['read', 'write', 'delete'],
      deal: ['read', 'write', 'delete'], pipeline: ['read', 'write'], activity: ['read', 'write', 'delete'],
      task: ['read', 'write', 'delete'], ticket: ['read', 'write', 'delete'], campaign: ['read', 'write'],
      quotation: ['read', 'write'], invoice: ['read', 'write'], project: ['read', 'write', 'delete'],
      product: ['read'], workflow: ['read', 'write'], ai: ['read', 'write'], member: ['read'],
      notification: ['read', 'write'], settings: ['read'], report: ['read']
    }).concat(['audit.read', 'report.read'])
  },
  sales: {
    name: 'Sales representative', description: 'Own pipeline, contacts and quotations',
    permissions: perms({
      lead: ['read', 'write'], contact: ['read', 'write'], company: ['read', 'write'],
      deal: ['read', 'write'], pipeline: ['read'], activity: ['read', 'write'], task: ['read', 'write'],
      quotation: ['read', 'write'], product: ['read'], member: ['read'], notification: ['read', 'write'],
      ai: ['read', 'write'], ticket: ['read'], project: ['read']
    }).concat(['report.read'])
  },
  support: {
    name: 'Support agent', description: 'Tickets, customer records and knowledge base',
    permissions: perms({
      ticket: ['read', 'write', 'delete'], contact: ['read', 'write'], company: ['read'],
      activity: ['read', 'write'], task: ['read', 'write'], deal: ['read'], project: ['read'],
      notification: ['read', 'write'], ai: ['read', 'write'], member: ['read']
    })
  },
  marketing: {
    name: 'Marketing', description: 'Campaigns, segments and lead capture',
    permissions: perms({
      campaign: ['read', 'write', 'delete'], contact: ['read', 'write'], lead: ['read', 'write'],
      activity: ['read', 'write'], task: ['read', 'write'], product: ['read'],
      notification: ['read', 'write'], ai: ['read', 'write'], member: ['read']
    }).concat(['report.read'])
  },
  finance: {
    name: 'Finance', description: 'Quotations, invoices and payments',
    permissions: perms({
      invoice: ['read', 'write', 'delete'], payment: ['read', 'write'], quotation: ['read', 'write'],
      deal: ['read'], company: ['read'], contact: ['read'], product: ['read'],
      notification: ['read', 'write'], member: ['read']
    }).concat(['report.read'])
  },
  field: {
    name: 'Field employee', description: 'Assigned visits, tasks and customer context',
    permissions: perms({
      activity: ['read', 'write'], task: ['read', 'write'], contact: ['read'], company: ['read'],
      deal: ['read'], ticket: ['read', 'write'], notification: ['read', 'write'], member: ['read']
    })
  },
  readonly: {
    name: 'Read-only', description: 'View and export where permitted, no writes',
    permissions: ENTITIES.map(e => `${e}.read`).concat(['report.read'])
  }
};

export const SYSTEM_ROLE_KEYS = Object.keys(ROLE_TEMPLATES);

/** Permission check used by route guards. */
export function can(ctx, perm) {
  if (!ctx || !ctx.perms) return false;
  return ctx.perms.includes('*') || ctx.perms.includes(perm);
}

/** Build a role row payload for a given template key. */
export function rolePayload(key) {
  const t = ROLE_TEMPLATES[key];
  if (!t) throw new Error(`Unknown role: ${key}`);
  return { key, name: t.name, description: t.description, permissions: t.permissions, is_system: true };
}
