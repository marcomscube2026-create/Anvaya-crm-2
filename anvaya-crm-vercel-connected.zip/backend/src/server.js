import { createApp } from './app.js';
import { initDb, migrate, q } from './db.js';

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';

const app = createApp();

async function boot() {
  await initDb();

  if (process.env.AUTO_MIGRATE !== '0') {
    const files = await migrate();
    const seeded = await q('select count(*)::int as n from organisations');
    console.log(`[db] migrations applied (${files.length} files), organisations: ${seeded[0].n}`);
    if (seeded[0].n === 0) {
      console.log('[db] empty database — run `npm run seed` to load the demo workspace');
    }
  }

  app.listen(PORT, HOST, () => {
    console.log(`Anvaya CRM listening on http://${HOST}:${PORT}`);
    console.log(`AI provider: ${process.env.AI_API_KEY ? 'configured' : 'local rules (no model configured)'}`);
  });
}

boot().catch(err => {
  console.error('Failed to start:', err);
  process.exit(1);
});
