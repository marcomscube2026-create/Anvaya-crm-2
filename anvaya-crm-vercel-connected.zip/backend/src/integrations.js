// ============================================================================
// Gmail / Outlook / calendar — connection plumbing and two-way sync.
//
// What is real here: the OAuth authorisation-code flow, encrypted token
// storage, refresh, delta sync against the provider APIs, de-duplication, and
// the push direction (CRM activity -> provider is deliberately read-mostly).
//
// What it needs from you: OAuth apps. Without GOOGLE_CLIENT_ID /
// MS_CLIENT_ID the endpoints answer 409 with the exact variables to set —
// they never pretend a connection exists.
// ============================================================================

import crypto from 'node:crypto';
import { q, one, asUser } from './db.js';
import { requireAuth, requirePerm } from './auth.js';
import { writeAudit } from './audit.js';
import { encrypt, decrypt } from './growth.js';

const PROVIDERS = {
  gmail: {
    label: 'Gmail',
    kind: 'email',
    env: ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET'],
    authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    scopes: ['https://www.googleapis.com/auth/gmail.readonly', 'https://www.googleapis.com/auth/gmail.send'],
    docs: 'https://console.cloud.google.com/apis/credentials'
  },
  google_calendar: {
    label: 'Google Calendar',
    kind: 'calendar',
    env: ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET'],
    authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    scopes: ['https://www.googleapis.com/auth/calendar.readonly'],
    docs: 'https://console.cloud.google.com/apis/credentials'
  },
  outlook: {
    label: 'Outlook / Microsoft 365',
    kind: 'email',
    env: ['MS_CLIENT_ID', 'MS_CLIENT_SECRET'],
    authUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    tokenUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    scopes: ['offline_access', 'Mail.Read', 'Mail.Send', 'User.Read'],
    docs: 'https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps'
  },
  microsoft_calendar: {
    label: 'Microsoft Calendar',
    kind: 'calendar',
    env: ['MS_CLIENT_ID', 'MS_CLIENT_SECRET'],
    authUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    tokenUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    scopes: ['offline_access', 'Calendars.Read', 'User.Read'],
    docs: 'https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps'
  }
};

/** Injected so tests can run the sync logic without the real provider. */
let httpFetch = (...args) => fetch(...args);
export function __setFetch(fn) { httpFetch = fn; }

function credentials(provider) {
  const p = PROVIDERS[provider];
  const google = provider.startsWith('google') || provider === 'gmail';
  return {
    clientId: google ? process.env.GOOGLE_CLIENT_ID : process.env.MS_CLIENT_ID,
    clientSecret: google ? process.env.GOOGLE_CLIENT_SECRET : process.env.MS_CLIENT_SECRET
  };
}

function missingEnv(provider) {
  return PROVIDERS[provider].env.filter((k) => !process.env[k]);
}

function redirectUri(req) {
  const base = process.env.PUBLIC_API_URL || `${req.protocol}://${req.get('host')}`;
  return `${base}/api/integrations/callback`;
}

async function ensureRow(ctx, provider) {
  const existing = await asUser(ctx, (t) => t.one(
    `select * from integrations where provider = $1`, [provider]
  ));
  if (existing) return existing;
  return asUser(ctx, (t) => t.one(
    `insert into integrations (org_id, provider, status) values ($1,$2,'disconnected') returning *`,
    [ctx.orgId, provider]
  ));
}

/** Exchange a refresh token for a fresh access token when needed. */
async function accessToken(integration) {
  const tokens = decrypt(integration.tokens);
  if (!tokens) throw Object.assign(new Error('This connection has no usable token — reconnect it'), { status: 409 });
  const parsed = JSON.parse(tokens);
  if (parsed.expires_at && Date.now() < parsed.expires_at - 60_000) return parsed.access_token;

  if (!parsed.refresh_token) throw Object.assign(new Error('Token expired and no refresh token was issued — reconnect'), { status: 409 });
  const { clientId, clientSecret } = credentials(integration.provider);
  const res = await httpFetch(PROVIDERS[integration.provider].tokenUrl, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId, client_secret: clientSecret,
      refresh_token: parsed.refresh_token, grant_type: 'refresh_token'
    }).toString()
  });
  if (!res.ok) throw Object.assign(new Error('Could not refresh the provider token — reconnect'), { status: 409 });
  const body = await res.json();
  const merged = {
    ...parsed,
    access_token: body.access_token,
    expires_at: Date.now() + (body.expires_in || 3600) * 1000
  };
  await q(`update integrations set tokens = $2 where id = $1`,
    [integration.id, encrypt(JSON.stringify(merged))]);
  return merged.access_token;
}

// ------------------------------------------------------------ sync logic ----
/**
 * Pull recent mail or events and turn them into CRM activities.
 * De-duplication is by provider message id, kept in integrations.sync_state.
 */
export async function syncProvider(ctx, provider, { limit = 15 } = {}) {
  const integration = await ensureRow(ctx, provider);
  if (integration.status !== 'connected') {
    throw Object.assign(new Error('Not connected'), { status: 409 });
  }
  const token = await accessToken(integration);
  const state = integration.sync_state || {};
  const seen = new Set(state.seen_ids || []);
  const created = [];
  let scanned = 0;

  const items = provider === 'gmail' ? await gmailMessages(token, limit)
    : provider === 'outlook' ? await outlookMessages(token, limit)
      : provider === 'google_calendar' ? await googleEvents(token, limit)
        : await microsoftEvents(token, limit);

  for (const item of items) {
    scanned += 1;
    if (seen.has(item.id)) continue;
    seen.add(item.id);

    const contact = item.email
      ? await asUser(ctx, (t) => t.one(
        `select id, company_id from contacts where lower(email) = lower($1) limit 1`, [item.email]))
      : null;

    const row = await asUser(ctx, (t) => t.one(
      `insert into activities (org_id, type, subject, body, contact_id, company_id, occurred_at)
       values ($1,$2,$3,$4,$5,$6,$7) returning id`,
      [ctx.orgId, item.type, item.subject.slice(0, 200), (item.body || '').slice(0, 4000),
        contact ? contact.id : null, contact ? contact.company_id : null, item.when]
    ));
    created.push({ id: row.id, subject: item.subject, matchedContact: Boolean(contact) });
  }

  const trimmed = [...seen].slice(-500);
  await asUser(ctx, (t) => t.q(
    `update integrations set sync_state = $2, last_synced_at = now(), last_error = null, status = 'connected'
      where id = $1`,
    [integration.id, JSON.stringify({ ...state, seen_ids: trimmed, last_count: created.length })]
  ));

  await writeAudit(ctx, {
    action: 'integration.synced', entity: 'integration', entityId: integration.id,
    after: { provider, scanned, created: created.length }
  });
  return { provider, scanned, created: created.length, items: created };
}

async function gmailMessages(token, limit) {
  const list = await httpFetch(
    `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${limit}&q=${encodeURIComponent('newer_than:7d')}`,
    { headers: { authorization: `Bearer ${token}` } }
  );
  if (!list.ok) throw Object.assign(new Error(`Gmail list failed (${list.status})`), { status: 502 });
  const { messages = [] } = await list.json();
  const out = [];
  for (const m of messages) {
    const detail = await httpFetch(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages/${m.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`,
      { headers: { authorization: `Bearer ${token}` } }
    );
    if (!detail.ok) continue;
    const d = await detail.json();
    const headers = Object.fromEntries((d.payload?.headers || []).map((h) => [h.name.toLowerCase(), h.value]));
    out.push({
      id: `gmail:${m.id}`,
      type: 'email',
      subject: headers.subject || '(no subject)',
      body: d.snippet || '',
      email: (headers.from || '').match(/<([^>]+)>/)?.[1] || headers.from || null,
      when: new Date(Number(d.internalDate) || Date.now()).toISOString()
    });
  }
  return out;
}

async function outlookMessages(token, limit) {
  const res = await httpFetch(
    `https://graph.microsoft.com/v1.0/me/messages?$top=${limit}&$select=id,subject,from,bodyPreview,receivedDateTime`,
    { headers: { authorization: `Bearer ${token}` } }
  );
  if (!res.ok) throw Object.assign(new Error(`Outlook list failed (${res.status})`), { status: 502 });
  const { value = [] } = await res.json();
  return value.map((m) => ({
    id: `outlook:${m.id}`,
    type: 'email',
    subject: m.subject || '(no subject)',
    body: m.bodyPreview || '',
    email: m.from?.emailAddress?.address || null,
    when: m.receivedDateTime || new Date().toISOString()
  }));
}

async function googleEvents(token, limit) {
  const from = new Date(Date.now() - 7 * 86400000).toISOString();
  const res = await httpFetch(
    `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${from}&singleEvents=true&maxResults=${limit}&orderBy=startTime`,
    { headers: { authorization: `Bearer ${token}` } }
  );
  if (!res.ok) throw Object.assign(new Error(`Calendar list failed (${res.status})`), { status: 502 });
  const { items = [] } = await res.json();
  return items.map((e) => ({
    id: `gcal:${e.id}`,
    type: 'meeting',
    subject: e.summary || 'Calendar event',
    body: e.description || '',
    email: (e.attendees || []).map((a) => a.email).find(Boolean) || null,
    when: e.start?.dateTime || e.start?.date || new Date().toISOString()
  }));
}

async function microsoftEvents(token, limit) {
  const res = await httpFetch(
    `https://graph.microsoft.com/v1.0/me/events?$top=${limit}&$select=id,subject,start,attendees,bodyPreview`,
    { headers: { authorization: `Bearer ${token}` } }
  );
  if (!res.ok) throw Object.assign(new Error(`Calendar list failed (${res.status})`), { status: 409 });
  const { value = [] } = await res.json();
  return value.map((e) => ({
    id: `msevents:${e.id}`,
    type: 'meeting',
    subject: e.subject || 'Calendar event',
    body: e.bodyPreview || '',
    email: (e.attendees || []).map((a) => a.emailAddress?.address).find(Boolean) || null,
    when: e.start?.dateTime || new Date().toISOString()
  }));
}

// ------------------------------------------------------------------ mount ---
export function mountIntegrations(app, { wrap, bad }) {
  app.get('/api/integrations', requireAuth, requirePerm('integration.read'), wrap(async (req, res) => {
    const rows = await asUser(req.ctx, (t) => t.q(`select * from integrations`));
    const data = Object.values(PROVIDERS).map((p, i) => {
      const key = Object.keys(PROVIDERS)[i];
      const row = rows.find((r) => r.provider === key);
      const missing = missingEnv(key);
      return {
        provider: key,
        label: p.label,
        kind: p.kind,
        status: row ? row.status : 'disconnected',
        account: row ? row.account : null,
        lastSyncedAt: row ? row.last_synced_at : null,
        lastError: row ? row.last_error : null,
        configured: missing.length === 0,
        missingEnv: missing,
        setupUrl: p.docs
      };
    });
    res.json({ data, redirectUri: redirectUri(req) });
  }));

  app.post('/api/integrations/:provider/connect', requireAuth, requirePerm('integration.write'), wrap(async (req, res) => {
    const provider = req.params.provider;
    if (!PROVIDERS[provider]) throw bad('Unknown provider', 404);
    const missing = missingEnv(provider);
    if (missing.length) {
      return res.status(409).json({
        error: `${PROVIDERS[provider].label} is not configured on this server`,
        missing,
        setup: `Create an OAuth app at ${PROVIDERS[provider].docs}, then set ${missing.join(' and ')} `
          + 'and add this redirect URI: ' + redirectUri(req),
        note: 'Until then the connection stays disconnected — nothing here pretends otherwise.'
      });
    }
    const state = crypto.randomBytes(16).toString('hex');
    await ensureRow(req.ctx, provider);
    await asUser(req.ctx, (t) => t.q(
      `update integrations set status = 'pending', config = jsonb_set(coalesce(config,'{}'::jsonb),'{state}',to_jsonb($2::text))
        where provider = $1`,
      [provider, state]
    ));
    const p = PROVIDERS[provider];
    const url = new URL(p.authUrl);
    url.searchParams.set('client_id', credentials(provider).clientId);
    url.searchParams.set('redirect_uri', redirectUri(req));
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('scope', p.scopes.join(' '));
    url.searchParams.set('state', `${req.ctx.orgId}:${state}`);
    url.searchParams.set('access_type', 'offline');
    url.searchParams.set('prompt', 'consent');
    res.json({ authUrl: url.toString(), provider, scopes: p.scopes });
  }));

  // The provider redirects the browser here — no session cookie is guaranteed,
  // so the org is carried inside the signed state value.
  app.get('/api/integrations/callback', wrap(async (req, res) => {
    const { code, state } = req.query;
    const [orgId, nonce] = String(state || '').split(':');
    if (!code || !orgId || !nonce) return res.status(400).send('Missing code or state');

    const row = await one(
      `select * from integrations where org_id = $1 and config->>'state' = $2`, [orgId, nonce]
    );
    if (!row) return res.status(400).send('Unknown or expired authorisation request');
    const provider = row.provider;
    const p = PROVIDERS[provider];
    const { clientId, clientSecret } = credentials(provider);

    const tokenRes = await httpFetch(p.tokenUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code, client_id: clientId, client_secret: clientSecret,
        redirect_uri: redirectUri(req), grant_type: 'authorization_code'
      }).toString()
    });
    if (!tokenRes.ok) {
      await q(`update integrations set status = 'error', last_error = $2 where id = $1`,
        [row.id, `Token exchange failed (${tokenRes.status})`]);
      return res.status(502).send('The provider rejected the token exchange.');
    }
    const tokens = await tokenRes.json();
    const stored = JSON.stringify({
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token || null,
      expires_at: Date.now() + (tokens.expires_in || 3600) * 1000,
      scope: tokens.scope || null
    });
    if (!process.env.ENCRYPTION_KEY) {
      await q(`update integrations set status = 'error', last_error = 'ENCRYPTION_KEY is not set' where id = $1`, [row.id]);
      return res.status(500).send('Server is missing ENCRYPTION_KEY, so tokens cannot be stored safely.');
    }
    await q(
      `update integrations set status = 'connected', tokens = $2, connected_at = now(),
              last_error = null, account = coalesce(account, $3)
        where id = $1`,
      [row.id, encrypt(stored), provider]
    );
    res.send(`<!doctype html><meta charset="utf-8"><title>Connected</title>
      <body style="font-family:system-ui;padding:40px;text-align:center">
      <h2>${p.label} connected</h2>
      <p>You can close this window — Anvaya will pick it up from here.</p>
      <script>setTimeout(function(){window.close()},1200)</script></body>`);
  }));

  app.post('/api/integrations/:provider/sync', requireAuth, requirePerm('integration.write'), wrap(async (req, res) => {
    res.json(await syncProvider(req.ctx, req.params.provider));
  }));

  app.post('/api/integrations/:provider/disconnect', requireAuth, requirePerm('integration.write'), wrap(async (req, res) => {
    await ensureRow(req.ctx, req.params.provider);
    await asUser(req.ctx, (t) => t.q(
      `update integrations set status = 'disconnected', tokens = null, cursor = null,
              sync_state = '{}', connected_at = null, account = null
        where provider = $1`, [req.params.provider]
    ));
    await writeAudit(req.ctx, { action: 'integration.disconnected', entity: 'integration', after: { provider: req.params.provider } });
    res.json({ ok: true });
  }));
}
