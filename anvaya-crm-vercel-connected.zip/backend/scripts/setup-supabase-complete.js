#!/usr/bin/env node
/**
 * One-shot setup for Anvaya on Supabase.
 *
 * Usage:
 *   DATABASE_URL="postgresql://..." node backend/scripts/setup-supabase-complete.js
 *
 * What it does:
 *   1. Connects to the database
 *   2. Applies the full Supabase-ready schema (supabase/anvaya-supabase.sql)
 *   3. Seeds a demo workspace (sneha@brightline.in / AnvayaDemo2026) if none exists
 *
 * Safe to re-run: schema uses IF NOT EXISTS; seed skips if the demo user is present.
 */
import pg from 'pg';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const { Pool } = pg;

// Prefer env; fall back to the project .env value for convenience.
const connectionString = process.env.DATABASE_URL
  || 'postgresql://postgres:OU604ZgU9qPoJuZc@db.pduywbweuxlvcatvesff.supabase.co:5432/postgres';

const pool = new Pool({
  connectionString,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 20000,
  max: 2
});

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$16384$8$1$${salt}$${hash}`;
}

async function main() {
  console.log('[setup] Connecting to Supabase...');
  await pool.query('select 1');
  console.log('[setup] Connected.');

  const __dirname = path.dirname(fileURLToPath(import.meta.url));
  const schemaPath = path.join(__dirname, '../../supabase/anvaya-supabase.sql');

  if (!fs.existsSync(schemaPath)) {
    throw new Error(`Schema file not found: ${schemaPath}`);
  }

  console.log('[setup] Applying supabase/anvaya-supabase.sql ...');
  const schemaSql = fs.readFileSync(schemaPath, 'utf8');
  // Split on statements that are safe to run one-by-one is complex; run as a single batch.
  // Supabase SQL editor also accepts the whole file.
  await pool.query(schemaSql);
  console.log('[setup] Schema applied.');

  // Count tables as a quick sanity check
  const t = await pool.query(
    `select count(*)::int n from information_schema.tables where table_schema = 'public'`
  );
  console.log(`[setup] public tables: ${t.rows[0].n}`);

  const email = 'sneha@brightline.in';
  const existing = await pool.query(
    'select id from users where lower(email) = lower($1)', [email]
  );

  if (existing.rows.length > 0) {
    console.log('[setup] Demo user already exists — skipping seed.');
  } else {
    console.log('[setup] Seeding demo workspace (sneha@brightline.in / AnvayaDemo2026)...');
    const passwordHash = hashPassword('AnvayaDemo2026');
    const client = await pool.connect();
    try {
      await client.query('begin');

      const userRes = await client.query(
        `insert into users (email, password_hash, full_name, email_verified_at)
         values ($1, $2, $3, now()) returning id`,
        [email, passwordHash, 'Snehasis Saha']
      );
      const userId = userRes.rows[0].id;

      const orgRes = await client.query(
        `insert into organisations (name, slug, industry, currency, timezone, plan)
         values ('Brightline Security Solutions', 'brightline-security',
                 'Security systems integrator', 'INR', 'Asia/Kolkata', 'professional')
         returning id`
      );
      const orgId = orgRes.rows[0].id;

      const wsRes = await client.query(
        `insert into workspaces (org_id, name, slug, is_default)
         values ($1, 'Brightline Security', 'default', true) returning id`,
        [orgId]
      );
      const wsId = wsRes.rows[0].id;

      // System roles — at minimum the owner role the register path also creates
      const roleRes = await client.query(
        `insert into roles (org_id, key, name, description, permissions, is_system)
         values ($1, 'owner', 'Owner', 'Full access', '{*}'::text[], true) returning id`,
        [orgId]
      );
      const roleId = roleRes.rows[0].id;

      await client.query(
        `insert into members (org_id, user_id, role_id, workspace_id, status, title, joined_at)
         values ($1, $2, $3, $4, 'active', 'Managing Director', now())`,
        [orgId, userId, roleId, wsId]
      );

      const pipelineRes = await client.query(
        `insert into pipelines (org_id, name, is_default) values ($1, 'Sales pipeline', true) returning id`,
        [orgId]
      );
      const pipelineId = pipelineRes.rows[0].id;

      const stages = [
        ['Discovery', 0, 10, false, false],
        ['Site survey', 1, 25, false, false],
        ['Proposal sent', 2, 45, false, false],
        ['Negotiation', 3, 70, false, false],
        ['Closed won', 4, 100, true, false],
        ['Closed lost', 5, 0, false, true]
      ];
      for (const [name, pos, prob, won, lost] of stages) {
        await client.query(
          `insert into stages (org_id, pipeline_id, name, position, probability, is_won, is_lost)
           values ($1,$2,$3,$4,$5,$6,$7)`,
          [orgId, pipelineId, name, pos, prob, won, lost]
        );
      }

      await client.query(
        `insert into subscriptions (org_id, plan, status, seats, trial_ends_at, current_period_end)
         values ($1, 'professional', 'trialing', 5, now() + interval '14 days', now() + interval '14 days')`,
        [orgId]
      );

      await client.query('commit');
      console.log('[setup] Demo workspace created.');
    } catch (e) {
      await client.query('rollback');
      throw e;
    } finally {
      client.release();
    }
  }

  console.log('[setup] Done. You can now sign in and create real workspaces.');
  console.log('[setup] Demo: sneha@brightline.in / AnvayaDemo2026');
  await pool.end();
}

main().catch(err => {
  console.error('[setup] FAILED:', err.message);
  process.exit(1);
});
