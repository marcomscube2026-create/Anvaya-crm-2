// Applies every .sql file in db/migrations in filename order.
// Safe to re-run: the migrations are written with IF NOT EXISTS / DROP POLICY.

import { initDb, migrate, q } from '../src/db.js';

const files = await migrate();
const tables = await q(
  `select count(*)::int as n from information_schema.tables where table_schema = 'public'`
);
const policies = await q(`select count(*)::int as n from pg_policies`);
console.log(`Applied ${files.length} migration files`);
console.log(`Tables: ${tables[0].n} · RLS policies: ${policies[0].n}`);
process.exit(0);
