-- ============================================================================
-- Anvaya CRM — 002 row level security
--
-- Requests run as the `app_user` role. Every organisation-owned table is
-- scoped to app.current_org(); writes additionally require a permission key.
-- Tenant isolation therefore holds even if application code forgets a WHERE
-- clause, and a read-only user cannot write through a direct SQL path.
-- ============================================================================

grant usage on schema public to app_user;
grant usage on schema app to app_user;
grant execute on all functions in schema app to app_user;

grant select, insert, update, delete on all tables in schema public to app_user;
alter default privileges in schema public grant select, insert, update, delete on tables to app_user;

-- ---------------------------------------------------------------- generic ---
do $$
declare spec record;
begin
  for spec in
    select * from (values
      ('companies','company',true),
      ('contacts','contact',true),
      ('leads','lead',true),
      ('deals','deal',true),
      ('pipelines','pipeline',true),
      ('stages','pipeline',true),
      ('activities','activity',true),
      ('tasks','task',true),
      ('tickets','ticket',true),
      ('ticket_comments','ticket',true),
      ('knowledge_articles','ticket',true),
      ('campaigns','campaign',true),
      ('campaign_recipients','campaign',true),
      ('products','product',true),
      ('quotations','quotation',true),
      ('quotation_items','quotation',true),
      ('invoices','invoice',true),
      ('invoice_items','invoice',true),
      ('payments','payment',false),
      ('projects','project',true),
      ('milestones','project',true),
      ('workflows','workflow',true),
      ('workflow_runs','workflow',false),
      ('workflow_steps','workflow',false),
      ('ai_runs','ai',false),
      ('ai_actions','ai',false),
      ('custom_fields','settings',true),
      ('custom_values','settings',true),
      ('integrations','integration',true),
      ('workspaces','workspace',true),
      ('roles','settings',true),
      ('members','member',true),
      ('subscriptions','billing',false)
    ) as v(tbl, perm, can_delete)
  loop
    execute format('alter table %I enable row level security', spec.tbl);
    execute format('alter table %I force row level security', spec.tbl);

    execute format('drop policy if exists %I on %I', spec.tbl || '_sel', spec.tbl);
    execute format(
      'create policy %I on %I for select using (org_id = app.current_org())',
      spec.tbl || '_sel', spec.tbl);

    execute format('drop policy if exists %I on %I', spec.tbl || '_ins', spec.tbl);
    execute format(
      'create policy %I on %I for insert with check (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_ins', spec.tbl, spec.perm || '.write');

    execute format('drop policy if exists %I on %I', spec.tbl || '_upd', spec.tbl);
    execute format(
      'create policy %I on %I for update using (org_id = app.current_org() and app.has_perm(%L)) with check (org_id = app.current_org())',
      spec.tbl || '_upd', spec.tbl, spec.perm || '.write');

    if spec.can_delete then
      execute format('drop policy if exists %I on %I', spec.tbl || '_del', spec.tbl);
      execute format(
        'create policy %I on %I for delete using (org_id = app.current_org() and app.has_perm(%L))',
        spec.tbl || '_del', spec.tbl, spec.perm || '.delete');
    end if;
  end loop;
end $$;

-- --------------------------------------------------------------- specials ---

-- organisations: a member sees only their own organisation
alter table organisations enable row level security;
alter table organisations force row level security;
drop policy if exists organisations_sel on organisations;
create policy organisations_sel on organisations for select
  using (id = app.current_org());
drop policy if exists organisations_upd on organisations;
create policy organisations_upd on organisations for update
  using (id = app.current_org() and app.has_perm('settings.write'))
  with check (id = app.current_org());

-- users: yourself, plus colleagues in the same organisation
alter table users enable row level security;
alter table users force row level security;
drop policy if exists users_sel on users;
create policy users_sel on users for select
  using (
    id = app.current_user()
    or exists (select 1 from members m where m.user_id = users.id and m.org_id = app.current_org())
  );
drop policy if exists users_upd on users;
create policy users_upd on users for update
  using (id = app.current_user())
  with check (id = app.current_user());

-- notifications: strictly your own
alter table notifications enable row level security;
alter table notifications force row level security;
drop policy if exists notifications_sel on notifications;
create policy notifications_sel on notifications for select
  using (user_id = app.current_user() and org_id = app.current_org());
drop policy if exists notifications_upd on notifications;
create policy notifications_upd on notifications for update
  using (user_id = app.current_user() and org_id = app.current_org())
  with check (user_id = app.current_user() and org_id = app.current_org());
drop policy if exists notifications_ins on notifications;
create policy notifications_ins on notifications for insert
  with check (org_id = app.current_org() and app.has_perm('notification.write'));

-- audit_logs: readable, never writable by application users.
-- Rows are written by the system connection so a user cannot forge or erase
-- their own trail.
alter table audit_logs enable row level security;
alter table audit_logs force row level security;
drop policy if exists audit_sel on audit_logs;
create policy audit_sel on audit_logs for select
  using (org_id = app.current_org() and app.has_perm('audit.read'));

-- sessions: no policy at all. Only the auth layer (system connection) reads
-- them, so a compromised request context cannot enumerate other sessions.
alter table sessions enable row level security;
alter table sessions force row level security;
